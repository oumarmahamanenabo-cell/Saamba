-- SAAMBA/MAYA — Portefeuille vendeur avec séquestre :
-- l'argent d'une vente est crédité (bloqué) au paiement, et ne devient retirable
-- que lorsque le CLIENT confirme « COLIS REÇU ». Prérequis : alter type app_role add value 'seller'.

alter table public.order_items add column if not exists seller_id uuid references public.profiles(id);
insert into public.partner_settings(key, value) values ('seller_commission_pct', '0') on conflict do nothing;

create table if not exists public.seller_ledger (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  order_id uuid not null references public.orders(id),
  order_number text,
  gross numeric not null,
  commission numeric not null default 0,
  amount numeric not null,
  status text not null default 'held' check (status in ('held','available','refunded')),
  created_at timestamptz not null default now(),
  released_at timestamptz,
  unique (order_id, seller_id)
);
create table if not exists public.seller_withdrawals (
  id uuid primary key default gen_random_uuid(),
  seller_id uuid not null references public.profiles(id),
  amount numeric not null check (amount > 0),
  method text,
  phone text,
  status text not null default 'requested' check (status in ('requested','paid','rejected')),
  note text,
  created_at timestamptz not null default now(),
  processed_by uuid references public.profiles(id),
  processed_at timestamptz
);
alter table public.seller_ledger enable row level security;
alter table public.seller_withdrawals enable row level security;
drop policy if exists seller_ledger_read on public.seller_ledger;
create policy seller_ledger_read on public.seller_ledger for select using (seller_id = auth.uid() or public.is_admin());
drop policy if exists seller_withdrawals_read on public.seller_withdrawals;
create policy seller_withdrawals_read on public.seller_withdrawals for select using (seller_id = auth.uid() or public.is_admin());
-- aucune politique d'écriture : tout passe par les fonctions ci-dessous

create or replace function public.trg_seller_ledger() returns trigger
language plpgsql security definer set search_path = '' as $$
declare pct numeric; r record;
begin
  if new.status = 'paid' and old.status is distinct from 'paid' then
    select coalesce((select value::numeric from public.partner_settings where key = 'seller_commission_pct'), 0) into pct;
    for r in select seller_id, sum(line_total) as gross from public.order_items
             where order_id = new.id and seller_id is not null group by seller_id loop
      insert into public.seller_ledger(seller_id, order_id, order_number, gross, commission, amount)
      values (r.seller_id, new.id, new.number, r.gross, round(r.gross * pct / 100, 2), r.gross - round(r.gross * pct / 100, 2))
      on conflict (order_id, seller_id) do nothing;
      perform public.notify_user(r.seller_id, 'wallet', 'Vente payée',
        'Commande ' || new.number || ' payée. Les fonds seront retirables dès que le client confirmera la réception.',
        jsonb_build_object('order_id', new.id));
    end loop;
  end if;
  -- libération UNIQUEMENT si le client lui-même a confirmé la réception
  if new.status = 'received' and old.status is distinct from 'received'
     and exists (select 1 from public.delivery_confirmations where order_id = new.id and kind = 'received') then
    for r in update public.seller_ledger set status = 'available', released_at = now()
             where order_id = new.id and status = 'held' returning seller_id, amount loop
      perform public.notify_user(r.seller_id, 'wallet', 'Fonds disponibles',
        'Le client a confirmé la réception : ' || r.amount || ' FCFA sont retirables.',
        jsonb_build_object('order_id', new.id));
    end loop;
  end if;
  return new;
end $$;
drop trigger if exists seller_ledger_on_order on public.orders;
create trigger seller_ledger_on_order after update of status on public.orders
  for each row execute function public.trg_seller_ledger();

create or replace function public.my_wallet() returns jsonb
language plpgsql security definer stable set search_path = '' as $$
declare held numeric; avail numeric; pend numeric; paid numeric;
begin
  select coalesce(sum(amount) filter (where status = 'held'), 0), coalesce(sum(amount) filter (where status = 'available'), 0)
    into held, avail from public.seller_ledger where seller_id = auth.uid();
  select coalesce(sum(amount) filter (where status = 'requested'), 0), coalesce(sum(amount) filter (where status = 'paid'), 0)
    into pend, paid from public.seller_withdrawals where seller_id = auth.uid();
  return jsonb_build_object('held', held, 'withdrawable', avail - pend - paid, 'pending_withdrawals', pend, 'paid_out', paid);
end $$;

create or replace function public.request_withdrawal(p_amount numeric, p_method text, p_phone text) returns uuid
language plpgsql security definer set search_path = '' as $$
declare w jsonb; v_id uuid;
begin
  if auth.uid() is null or not exists (select 1 from public.profiles where id = auth.uid() and role = 'seller' and active) then
    raise exception 'Réservé aux vendeurs'; end if;
  perform pg_advisory_xact_lock(hashtext(auth.uid()::text));
  w := public.my_wallet();
  if p_amount is null or p_amount <= 0 then raise exception 'Montant invalide'; end if;
  if p_amount > (w->>'withdrawable')::numeric then
    raise exception 'Solde retirable insuffisant (%). Les fonds sont débloqués quand le client confirme la réception.', w->>'withdrawable'; end if;
  insert into public.seller_withdrawals(seller_id, amount, method, phone) values (auth.uid(), p_amount, p_method, p_phone) returning id into v_id;
  perform public.notify_admins('withdrawal', 'Demande de retrait', 'Un vendeur demande un retrait de ' || p_amount || ' FCFA.', jsonb_build_object('withdrawal_id', v_id));
  return v_id;
end $$;

create or replace function public.admin_process_withdrawal(p_id uuid, p_paid boolean, p_note text default null) returns void
language plpgsql security definer set search_path = '' as $$
declare w public.seller_withdrawals;
begin
  if not public.is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  select * into w from public.seller_withdrawals where id = p_id for update;
  if not found or w.status <> 'requested' then raise exception 'Demande introuvable ou déjà traitée'; end if;
  update public.seller_withdrawals set status = case when p_paid then 'paid' else 'rejected' end, note = p_note,
    processed_by = auth.uid(), processed_at = now() where id = p_id;
  perform public.notify_user(w.seller_id, 'wallet', case when p_paid then 'Retrait effectué' else 'Retrait refusé' end,
    coalesce(p_note, case when p_paid then 'Votre retrait de ' || w.amount || ' FCFA a été payé.' else 'Votre demande a été refusée.' end), '{}'::jsonb);
end $$;

-- Litige tranché en faveur du client : les fonds bloqués de la commande sont annulés
create or replace function public.admin_refund_order_ledger(p_order_id uuid) returns integer
language plpgsql security definer set search_path = '' as $$
declare k integer;
begin
  if not public.is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  update public.seller_ledger set status = 'refunded' where order_id = p_order_id and status = 'held';
  get diagnostics k = row_count;
  return k;
end $$;

create or replace function public.admin_make_seller(p_user uuid) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  update public.profiles set role = 'seller' where id = p_user and role = 'client';
  if not found then raise exception 'Seul un compte client peut devenir vendeur'; end if;
end $$;

revoke all on function public.my_wallet(), public.request_withdrawal(numeric,text,text), public.admin_process_withdrawal(uuid,boolean,text),
  public.admin_refund_order_ledger(uuid), public.admin_make_seller(uuid) from public, anon;
grant execute on function public.my_wallet(), public.request_withdrawal(numeric,text,text), public.admin_process_withdrawal(uuid,boolean,text),
  public.admin_refund_order_ledger(uuid), public.admin_make_seller(uuid) to authenticated;
