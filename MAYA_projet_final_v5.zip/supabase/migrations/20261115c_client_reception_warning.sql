create or replace function public.trg_warn_client_reception() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status in ('handed_to_carrier','in_transit','arrived') and old.status is distinct from new.status then
    perform public.notify_user(new.client_id, 'delivery', 'Votre commande ' || new.number || ' est en route',
      'Important : ne confirmez « Colis reçu » qu''après avoir réellement reçu et vérifié votre colis. Cette confirmation paie le vendeur. En cas de problème, appuyez sur « Colis non reçu » ou signalez-le à l''administration.',
      jsonb_build_object('order_id', new.id));
  end if;
  return new;
end $$;
drop trigger if exists warn_client_reception on public.orders;
create trigger warn_client_reception after update of status on public.orders
  for each row execute function public.trg_warn_client_reception();
