-- SAAMBA/MAYA — Vérification des partenaires (grossistes + transporteurs)
-- Migration ADDITIVE et idempotente : ne supprime ni ne modifie aucune donnée existante.

create or replace function public.partner_is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin' and active = true);
$$;

-- Réglage : l'obligation de vérification n'est appliquée qu'une fois activée par l'admin
create table if not exists public.partner_settings (
  key text primary key,
  value text not null
);
insert into public.partner_settings(key, value) values ('enforce_verification', 'false') on conflict do nothing;

-- Grossistes : statut de vérification (les grossistes existants restent « pending » tant que non traités)
alter table public.suppliers add column if not exists verification_status text not null default 'pending';
alter table public.suppliers add column if not exists verified_at timestamptz;
alter table public.suppliers add column if not exists verification_reason text;
alter table public.suppliers drop constraint if exists suppliers_verification_status_chk;
alter table public.suppliers add constraint suppliers_verification_status_chk
  check (verification_status in ('pending','docs_required','in_review','verified','refused','suspended'));

-- Transporteurs
create table if not exists public.carriers (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete set null,
  owner_name text not null,
  company_name text,
  is_individual boolean not null default false,
  phone text,
  email text,
  address text,
  city text,
  zones text,
  goods_types text,
  vehicle_types text,
  capacity text,
  verification_status text not null default 'pending'
    check (verification_status in ('pending','docs_required','in_review','verified','refused','suspended')),
  verified_at timestamptz,
  verification_reason text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

-- Pièces justificatives (fichiers dans le bucket privé partner-docs)
create table if not exists public.partner_documents (
  id uuid primary key default gen_random_uuid(),
  partner_type text not null check (partner_type in ('supplier','carrier')),
  partner_id uuid not null,
  doc_type text not null,
  original_name text,
  storage_path text not null,
  expires_at date,
  uploaded_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index if not exists partner_documents_partner_idx on public.partner_documents(partner_type, partner_id);

-- Historique des décisions
create table if not exists public.partner_verification_log (
  id uuid primary key default gen_random_uuid(),
  partner_type text not null check (partner_type in ('supplier','carrier')),
  partner_id uuid not null,
  action text not null,
  from_status text,
  to_status text,
  reason text,
  actor uuid references auth.users(id),
  created_at timestamptz not null default now()
);
create index if not exists partner_log_partner_idx on public.partner_verification_log(partner_type, partner_id, created_at desc);

-- RLS : administrateurs uniquement
alter table public.partner_settings enable row level security;
alter table public.carriers enable row level security;
alter table public.partner_documents enable row level security;
alter table public.partner_verification_log enable row level security;

do $$ declare t text; begin
  foreach t in array array['partner_settings','carriers','partner_documents','partner_verification_log'] loop
    execute format('drop policy if exists %I on public.%I', t || '_admin_all', t);
    execute format('create policy %I on public.%I for all using (public.partner_is_admin()) with check (public.partner_is_admin())', t || '_admin_all', t);
  end loop;
end $$;

-- Le transporteur peut lire sa propre fiche (si un compte lui est associé)
drop policy if exists carriers_self_read on public.carriers;
create policy carriers_self_read on public.carriers for select using (user_id = auth.uid());

-- Bucket privé des justificatifs
insert into storage.buckets (id, name, public) values ('partner-docs', 'partner-docs', false) on conflict (id) do nothing;
drop policy if exists partner_docs_admin on storage.objects;
create policy partner_docs_admin on storage.objects for all
  using (bucket_id = 'partner-docs' and public.partner_is_admin())
  with check (bucket_id = 'partner-docs' and public.partner_is_admin());

-- Décision de vérification (motif obligatoire pour refus / demande de documents / suspension)
create or replace function public.partner_set_status(p_type text, p_id uuid, p_action text, p_reason text default null)
returns text language plpgsql security definer set search_path = public as $$
declare cur text; nxt text;
begin
  if not public.partner_is_admin() then raise exception 'Accès réservé aux administrateurs'; end if;
  if p_type not in ('supplier','carrier') then raise exception 'Type de partenaire invalide'; end if;
  nxt := case p_action
    when 'approve' then 'verified' when 'refuse' then 'refused' when 'request_docs' then 'docs_required'
    when 'review' then 'in_review' when 'suspend' then 'suspended' when 'reactivate' then 'verified'
    else null end;
  if nxt is null then raise exception 'Action inconnue : %', p_action; end if;
  if p_action in ('refuse','request_docs','suspend') and coalesce(trim(p_reason), '') = '' then
    raise exception 'Un motif est obligatoire pour cette action';
  end if;

  if p_type = 'supplier' then
    select verification_status into cur from public.suppliers where id = p_id for update;
    if not found then raise exception 'Grossiste introuvable'; end if;
    if p_action = 'reactivate' and cur <> 'suspended' then raise exception 'Seul un partenaire suspendu peut être réactivé'; end if;
    update public.suppliers set verification_status = nxt, verification_reason = p_reason,
      verified_at = case when nxt = 'verified' then now() else null end where id = p_id;
  else
    select verification_status into cur from public.carriers where id = p_id for update;
    if not found then raise exception 'Transporteur introuvable'; end if;
    if p_action = 'reactivate' and cur <> 'suspended' then raise exception 'Seul un partenaire suspendu peut être réactivé'; end if;
    update public.carriers set verification_status = nxt, verification_reason = p_reason,
      verified_at = case when nxt = 'verified' then now() else null end where id = p_id;
  end if;

  insert into public.partner_verification_log(partner_type, partner_id, action, from_status, to_status, reason, actor)
  values (p_type, p_id, p_action, cur, nxt, p_reason, auth.uid());
  return nxt;
end $$;
revoke all on function public.partner_set_status(text, uuid, text, text) from public, anon;
grant execute on function public.partner_set_status(text, uuid, text, text) to authenticated;

-- Documents expirant dans les 30 jours (ou déjà expirés)
create or replace view public.v_partner_expiring_docs with (security_invoker = true) as
select d.*, (d.expires_at - current_date) as days_left
from public.partner_documents d
where d.expires_at is not null and d.expires_at <= current_date + 30;

-- Règle : un grossiste non vérifié ne reçoit pas de demande (appliquée quand enforce_verification = 'true')
create or replace function public.trg_check_supplier_verified() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'sent' and exists (select 1 from public.partner_settings where key = 'enforce_verification' and value = 'true') then
    if not exists (select 1 from public.suppliers where id = new.supplier_id and verification_status = 'verified') then
      raise exception 'Ce grossiste n''est pas vérifié : demande impossible';
    end if;
  end if;
  return new;
end $$;
drop trigger if exists check_supplier_verified on public.supplier_requests;
create trigger check_supplier_verified before insert or update of status on public.supplier_requests
  for each row execute function public.trg_check_supplier_verified();

-- Règle : aucune mission de livraison pour un transporteur non vérifié (toujours appliquée)
do $$ begin
  if to_regclass('public.delivery_details') is not null then
    alter table public.delivery_details add column if not exists carrier_id uuid references public.carriers(id);
  end if;
end $$;

create or replace function public.trg_check_carrier_verified() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.carrier_id is not null and not exists (select 1 from public.carriers where id = new.carrier_id and verification_status = 'verified') then
    raise exception 'Transporteur non vérifié : mission de livraison refusée';
  end if;
  return new;
end $$;
do $$ begin
  if to_regclass('public.delivery_details') is not null then
    drop trigger if exists check_carrier_verified on public.delivery_details;
    create trigger check_carrier_verified before insert or update of carrier_id on public.delivery_details
      for each row execute function public.trg_check_carrier_verified();
  end if;
end $$;
