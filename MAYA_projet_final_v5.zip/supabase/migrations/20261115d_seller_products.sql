-- Publication de produits par les vendeurs, avec validation admin (ou publication auto pour vendeurs de confiance)
alter table public.profiles add column if not exists auto_publish boolean not null default false;

create or replace function public.is_seller() returns boolean
language sql stable security definer set search_path = '' as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'seller' and p.active);
$$;

drop policy if exists prod_seller_select on public.products;
create policy prod_seller_select on public.products for select using (created_by = auth.uid());
drop policy if exists prod_seller_insert on public.products;
create policy prod_seller_insert on public.products for insert with check (created_by = auth.uid() and public.is_seller());
drop policy if exists prod_seller_update on public.products;
create policy prod_seller_update on public.products for update using (created_by = auth.uid() and public.is_seller()) with check (created_by = auth.uid());
drop policy if exists prod_seller_delete on public.products;
create policy prod_seller_delete on public.products for delete using (created_by = auth.uid() and public.is_seller());

-- Un vendeur ne peut jamais s'auto-approuver : statut forcé selon son réglage de confiance
create or replace function public.trg_product_status_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
declare trusted boolean;
begin
  if public.is_admin() then return new; end if;
  select auto_publish into trusted from public.profiles where id = auth.uid();
  new.created_by := coalesce(old.created_by, auth.uid());
  new.status := case when new.status = 'hidden' then 'hidden' when coalesce(trusted, false) then 'approved' else 'pending' end;
  return new;
end $$;
drop trigger if exists product_status_guard on public.products;
create trigger product_status_guard before insert or update on public.products
  for each row execute function public.trg_product_status_guard();

create or replace function public.admin_set_auto_publish(p_user uuid, p_value boolean) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  update public.profiles set auto_publish = p_value where id = p_user and role = 'seller';
end $$;
revoke all on function public.admin_set_auto_publish(uuid, boolean) from public, anon;
grant execute on function public.admin_set_auto_publish(uuid, boolean) to authenticated;

-- Photos produits (lecture publique, écriture dans son propre dossier)
insert into storage.buckets (id, name, public) values ('product-images', 'product-images', true) on conflict (id) do nothing;
drop policy if exists product_images_seller_write on storage.objects;
create policy product_images_seller_write on storage.objects for insert to authenticated
  with check (bucket_id = 'product-images' and (storage.foldername(name))[1] = auth.uid()::text and public.is_seller());
drop policy if exists product_images_admin on storage.objects;
create policy product_images_admin on storage.objects for all to authenticated
  using (bucket_id = 'product-images' and public.is_admin()) with check (bucket_id = 'product-images' and public.is_admin());
