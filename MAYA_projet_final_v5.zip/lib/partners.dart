import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';
import 'suppliers.dart' show mimeFor;

// ======== Vérification des partenaires (grossistes + transporteurs) ========
const _statusLabels = {
  'pending': 'EN ATTENTE',
  'docs_required': 'DOCUMENTS À COMPLÉTER',
  'in_review': 'EN VÉRIFICATION',
  'verified': 'VÉRIFIÉ',
  'refused': 'REFUSÉ',
  'suspended': 'SUSPENDU',
};

Color _statusColor(String s) => switch (s) {
      'verified' => maliGreen,
      'refused' || 'suspended' => maliRed,
      'docs_required' => gold,
      _ => Colors.blueGrey,
    };

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: _statusColor(status).withOpacity(0.15), borderRadius: BorderRadius.circular(10)),
        child: Text(_statusLabels[status] ?? status,
            style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800, color: _statusColor(status))),
      );
}

/// Badge affiché uniquement sur les profils approuvés.
class VerifiedBadge extends StatelessWidget {
  final String? status;
  const VerifiedBadge(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    if (status != 'verified') return const SizedBox.shrink();
    return const Chip(
      avatar: Icon(Icons.verified, color: maliGreen, size: 18),
      label: Text('PARTENAIRE VÉRIFIÉ SAAMBA', style: TextStyle(fontSize: 11, fontWeight: FontWeight.w800)),
      visualDensity: VisualDensity.compact,
    );
  }
}

class PartnersScreen extends StatelessWidget {
  const PartnersScreen({super.key});
  @override
  Widget build(BuildContext context) => const DefaultTabController(
        length: 2,
        child: Column(children: [
          TabBar(tabs: [Tab(text: 'Grossistes'), Tab(text: 'Transporteurs')]),
          Expanded(child: TabBarView(children: [_PartnerList(type: 'supplier'), _PartnerList(type: 'carrier')])),
        ]),
      );
}

class _PartnerList extends StatefulWidget {
  final String type;
  const _PartnerList({required this.type});
  @override
  State<_PartnerList> createState() => _PartnerListState();
}

class _PartnerListState extends State<_PartnerList> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  String _filter = 'all';
  bool get _isSupplier => widget.type == 'supplier';

  Future<List<Map<String, dynamic>>> _load() async => List<Map<String, dynamic>>.from(
      await sb.from(_isSupplier ? 'suppliers' : 'carriers').select().order(_isSupplier ? 'name' : 'owner_name'));

  String _title(Map<String, dynamic> p) =>
      _isSupplier ? '${p['name']}' : ('${p['company_name'] ?? ''}'.isNotEmpty ? '${p['company_name']}' : '${p['owner_name']}');

  Future<void> _addCarrier() async {
    final keys = ['owner_name', 'company_name', 'phone', 'email', 'city', 'address', 'zones', 'goods_types', 'vehicle_types', 'capacity'];
    const labels = {
      'owner_name': 'Responsable',
      'company_name': 'Entreprise (vide si individuel)',
      'phone': 'Téléphone',
      'email': 'E-mail',
      'city': 'Ville',
      'address': 'Adresse',
      'zones': 'Zones et trajets desservis',
      'goods_types': 'Marchandises transportées',
      'vehicle_types': 'Types de véhicules',
      'capacity': 'Capacité',
    };
    final c = {for (final k in keys) k: TextEditingController()};
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nouveau transporteur'),
        content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final k in keys) TextField(controller: c[k], decoration: InputDecoration(labelText: labels[k])),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Créer')),
        ],
      ),
    );
    if (ok != true || c['owner_name']!.text.trim().isEmpty || !mounted) return;
    await guarded(context, () async {
      await sb.from('carriers').insert({
        for (final k in keys) k: c[k]!.text.trim().isEmpty ? null : c[k]!.text.trim(),
        'is_individual': c['company_name']!.text.trim().isEmpty,
        'created_by': uid,
      });
      setState(() => _f = _load());
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: _isSupplier
            ? null
            : FloatingActionButton.extended(onPressed: _addCarrier, icon: const Icon(Icons.add), label: const Text('Transporteur')),
        body: Column(children: [
          SizedBox(
            height: 48,
            child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
              for (final s in ['all', ..._statusLabels.keys])
                Padding(
                  padding: const EdgeInsets.only(right: 6),
                  child: ChoiceChip(
                    label: Text(s == 'all' ? 'Tous' : _statusLabels[s]!, style: const TextStyle(fontSize: 11)),
                    selected: _filter == s,
                    onSelected: (_) => setState(() => _filter = s),
                  ),
                ),
            ]),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _f,
              builder: (context, snap) {
                if (snap.hasError) return errorView(snap.error);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final list = snap.data!.where((p) => _filter == 'all' || p['verification_status'] == _filter).toList();
                if (list.isEmpty) return const Center(child: Text('Aucun partenaire dans cette catégorie.'));
                return RefreshIndicator(
                  onRefresh: () async => setState(() => _f = _load()),
                  child: ListView.separated(
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const Divider(height: 1),
                    itemBuilder: (_, i) {
                      final p = list[i];
                      return ListTile(
                        leading: CircleAvatar(child: Icon(_isSupplier ? Icons.storefront : Icons.local_shipping)),
                        title: Text(_title(p)),
                        subtitle: Text('${p['city'] ?? ''} ${p['phone'] ?? ''}'),
                        trailing: StatusChip('${p['verification_status']}'),
                        onTap: () async {
                          await Navigator.push(context, MaterialPageRoute(builder: (_) => PartnerDetailScreen(type: widget.type, partner: p, title: _title(p))));
                          setState(() => _f = _load());
                        },
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ]),
      );
}

class PartnerDetailScreen extends StatefulWidget {
  final String type;
  final Map<String, dynamic> partner;
  final String title;
  const PartnerDetailScreen({super.key, required this.type, required this.partner, required this.title});
  @override
  State<PartnerDetailScreen> createState() => _PartnerDetailScreenState();
}

class _PartnerDetailScreenState extends State<PartnerDetailScreen> {
  late Map<String, dynamic> _p = widget.partner;
  late Future<List<dynamic>> _f = _load();
  String get _id => '${_p['id']}';
  String get _status => '${_p['verification_status']}';

  Future<List<dynamic>> _load() => Future.wait([
        sb.from('partner_documents').select().eq('partner_type', widget.type).eq('partner_id', _id).order('created_at', ascending: false),
        sb.from('partner_verification_log').select().eq('partner_type', widget.type).eq('partner_id', _id).order('created_at', ascending: false),
      ]);

  Future<void> _act(String action, {bool needsReason = false}) async {
    String? reason;
    if (needsReason) {
      reason = await askText(context, 'Motif (obligatoire)');
      if (reason == null || reason.isEmpty) {
        if (mounted && reason != null) snack(context, 'Un motif est obligatoire.');
        return;
      }
    }
    if (!mounted) return;
    await guarded(context, () async {
      await sb.rpc('partner_set_status', params: {'p_type': widget.type, 'p_id': _id, 'p_action': action, 'p_reason': reason});
      final t = widget.type == 'supplier' ? 'suppliers' : 'carriers';
      final fresh = await sb.from(t).select().eq('id', _id).single();
      if (!mounted) return;
      setState(() {
        _p = Map<String, dynamic>.from(fresh);
        _f = _load();
      });
    });
  }

  Future<void> _addDoc() async {
    final type = await askText(context, 'Type de document (ex. pièce d\'identité, assurance)', multiline: false);
    if (type == null || type.isEmpty || !mounted) return;
    final src = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.photo), title: const Text('Photo'), onTap: () => Navigator.pop(ctx, 'photo')),
          ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Appareil photo'), onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(leading: const Icon(Icons.description), title: const Text('Document / PDF'), onTap: () => Navigator.pop(ctx, 'doc')),
        ]),
      ),
    );
    if (src == null) return;
    File? file;
    String? name;
    if (src == 'doc') {
      final r = await FilePicker.platform.pickFiles();
      final f = r?.files.single;
      if (f?.path != null) {
        file = File(f!.path!);
        name = f.name;
      }
    } else {
      final x = await ImagePicker().pickImage(source: src == 'photo' ? ImageSource.gallery : ImageSource.camera, imageQuality: 70, maxWidth: 1600);
      if (x != null) {
        file = File(x.path);
        name = x.name;
      }
    }
    if (file == null || name == null || !mounted) return;
    DateTime? exp;
    final askExp = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ce document a-t-il une date d\'expiration ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Non')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Oui')),
        ],
      ),
    );
    if (askExp == true && mounted) {
      exp = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 365)), firstDate: DateTime.now().subtract(const Duration(days: 365)), lastDate: DateTime.now().add(const Duration(days: 3650)));
    }
    if (!mounted) return;
    final f = file;
    final nm = name;
    await guarded(context, () async {
      final dot = nm.lastIndexOf('.');
      final ext = dot > 0 ? nm.substring(dot + 1) : 'bin';
      final path = '${widget.type}/$_id/${DateTime.now().microsecondsSinceEpoch}.$ext';
      await sb.storage.from('partner-docs').upload(path, f, fileOptions: FileOptions(contentType: mimeFor(nm)));
      await sb.from('partner_documents').insert({
        'partner_type': widget.type,
        'partner_id': _id,
        'doc_type': type,
        'original_name': nm,
        'storage_path': path,
        'expires_at': exp?.toIso8601String().substring(0, 10),
        'uploaded_by': uid,
      });
      if (mounted) setState(() => _f = _load());
    });
  }

  Future<void> _open(String path) => guarded(context, () async {
        final url = await sb.storage.from('partner-docs').createSignedUrl(path, 300);
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      });

  List<Widget> _actions() {
    final s = _status;
    Widget b(String label, IconData i, String a, {bool reason = false, bool filled = false}) => filled
        ? FilledButton.icon(icon: Icon(i), label: Text(label), onPressed: () => _act(a, needsReason: reason))
        : OutlinedButton.icon(icon: Icon(i), label: Text(label), onPressed: () => _act(a, needsReason: reason));
    if (s == 'suspended') return [b('RÉACTIVER', Icons.play_arrow, 'reactivate', filled: true)];
    return [
      if (s != 'verified') b('APPROUVER', Icons.check_circle, 'approve', filled: true),
      if (s == 'pending' || s == 'docs_required') b('MISE EN VÉRIFICATION', Icons.manage_search, 'review'),
      if (s != 'refused') b('REFUSER', Icons.cancel, 'refuse', reason: true),
      if (s != 'docs_required') b('DEMANDER DES DOCUMENTS', Icons.upload_file, 'request_docs', reason: true),
      if (s == 'verified') b('SUSPENDRE', Icons.pause_circle, 'suspend', reason: true),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final p = _p;
    final isSup = widget.type == 'supplier';
    final info = <String, dynamic>{
      'Responsable': isSup ? p['manager_name'] : p['owner_name'],
      'Statut juridique': isSup ? null : (p['is_individual'] == true ? 'Transporteur individuel' : 'Entreprise'),
      'Téléphone': p['phone'],
      'E-mail': p['email'],
      'Ville': p['city'],
      'Adresse': p['address'],
      'Zones / trajets': p['zones'],
      'Marchandises': p['goods_types'],
      'Véhicules': p['vehicle_types'],
      'Capacité': p['capacity'],
    };
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: FutureBuilder<List<dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final docs = List<Map<String, dynamic>>.from(snap.data![0] as List);
          final log = List<Map<String, dynamic>>.from(snap.data![1] as List);
          return ListView(padding: const EdgeInsets.all(12), children: [
            Section('Statut', [
              Wrap(spacing: 8, crossAxisAlignment: WrapCrossAlignment.center, children: [StatusChip(_status), VerifiedBadge(_status)]),
              if ('${p['verification_reason'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Motif : ${p['verification_reason']}')),
              if (p['verified_at'] != null) Text('Vérifié le ${dt(p['verified_at'])}'),
              const SizedBox(height: 8),
              Wrap(spacing: 8, runSpacing: 8, children: _actions()),
            ]),
            Section('Coordonnées', [
              for (final e in info.entries)
                if (e.value != null && '${e.value}'.isNotEmpty) Text('${e.key} : ${e.value}'),
            ]),
            Section('Justificatifs (espace privé)', [
              if (docs.isEmpty) const Text('Aucun document.'),
              for (final d in docs)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  dense: true,
                  leading: const Icon(Icons.description),
                  title: Text('${d['doc_type']}'),
                  subtitle: Text(_docSub(d)),
                  trailing: const Icon(Icons.open_in_new, size: 18),
                  onTap: () => _open('${d['storage_path']}'),
                ),
              TextButton.icon(onPressed: _addDoc, icon: const Icon(Icons.add), label: const Text('Ajouter un document')),
            ]),
            Section('Historique', [
              if (log.isEmpty) const Text('Aucune décision enregistrée.'),
              for (final l in log)
                Padding(
                  padding: const EdgeInsets.only(bottom: 6),
                  child: Text('${dt(l['created_at'])} — ${_statusLabels[l['to_status']] ?? l['to_status']}'
                      '${'${l['reason'] ?? ''}'.isEmpty ? '' : '\n${l['reason']}'}'),
                ),
            ]),
          ]);
        },
      ),
    );
  }

  String _docSub(Map<String, dynamic> d) {
    final e = d['expires_at'];
    if (e == null) return 'Ajouté le ${dt(d['created_at'])}';
    final days = DateTime.parse('$e').difference(DateTime.now()).inDays;
    final tag = days < 0 ? 'EXPIRÉ' : (days <= 30 ? 'expire dans $days j' : 'valide');
    return 'Expiration : $e · $tag';
  }
}
