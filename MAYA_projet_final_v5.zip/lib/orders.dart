import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';

class OrdersScreen extends StatefulWidget {
  final bool admin;
  final String initialFilter;
  const OrdersScreen({super.key, required this.admin, this.initialFilter = 'all'});
  @override
  State<OrdersScreen> createState() => OrdersScreenState();
}

class OrdersScreenState extends State<OrdersScreen> {
  late String _filter = widget.initialFilter;
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    var q = sb.from('orders').select('*, profiles!orders_client_id_fkey(full_name)');
    if (_filter == 'shipping') {
      q = q.inFilter('status', ['handed_to_carrier', 'in_transit', 'arrived', 'reception_pending', 'not_received_to_verify']);
    }
    return List<Map<String, dynamic>>.from(await q.order('created_at', ascending: false));
  }

  void reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            ChoiceChip(label: const Text('Toutes'), selected: _filter == 'all', onSelected: (_) { _filter = 'all'; reload(); }),
            const SizedBox(width: 8),
            ChoiceChip(label: const Text('Livraisons'), selected: _filter == 'shipping', onSelected: (_) { _filter = 'shipping'; reload(); }),
          ]),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return errorView(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!;
              if (list.isEmpty) return const Center(child: Text('Aucune commande.'));
              return RefreshIndicator(
                onRefresh: () async => reload(),
                child: ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final o = list[i];
                    final bad = o['status'] == 'not_received_to_verify';
                    return ListTile(
                      title: Text(o['number'] as String),
                      subtitle: Text('${widget.admin ? '${(o['profiles'] as Map?)?['full_name'] ?? ''} · ' : ''}${orderStatusLabels[o['status']] ?? o['status']}',
                          style: TextStyle(color: bad ? Colors.red : null, fontWeight: bad ? FontWeight.bold : null)),
                      trailing: Text(money(o['total'], o['currency'] as String)),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: o['id'] as String, admin: widget.admin)));
                        reload();
                      },
                    );
                  },
                ),
              );
            },
          ),
        ),
      ]);
}

class OrderDetailScreen extends StatefulWidget {
  final String orderId;
  final bool admin;
  const OrderDetailScreen({super.key, required this.orderId, required this.admin});
  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  late Future<Map<String, dynamic>> _f = _load();
  Map<String, num> _costs = {};

  Future<Map<String, dynamic>> _load() async {
    final o = await sb
        .from('orders')
        .select('*, order_items(*), invoices(*), payments(*), delivery_details(*), disputes(*), profiles!orders_client_id_fkey(full_name,phone)')
        .eq('id', widget.orderId)
        .single();
    if (widget.admin) {
      final c = await sb.from('order_item_costs').select();
      _costs = {for (final r in c) r['order_item_id'] as String: n(r['unit_cost'])};
    }
    return o;
  }

  void _reload() => setState(() => _f = _load());

  Map<String, dynamic>? _one(dynamic v) {
    if (v is List) return v.isEmpty ? null : Map<String, dynamic>.from(v.first as Map);
    if (v is Map) return Map<String, dynamic>.from(v);
    return null;
  }

  Future<void> _confirm(bool received, {String? prefix}) async {
    String? note;
    if (received) {
      final sure = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Confirmer la réception ?'),
          content: const Text('Ne confirmez que si vous avez réellement reçu votre colis et vérifié son contenu.\n\n'
              'Cette confirmation paie le vendeur et ne peut pas être annulée. En cas de problème, appuyez sur « Non, signaler un problème ».'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Non, signaler un problème')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Oui, j\'ai reçu mon colis')),
          ],
        ),
      );
      if (sure != true) return;
    }
    if (!received) {
      note = await askText(context, 'Que s\'est-il passé ? (facultatif)');
      if (note == null) return;
      if (prefix != null) note = '$prefix${note.isEmpty ? '' : ' — $note'}';
    }
    if (!mounted) return;
    await guarded(context, () async {
      await sb.rpc('confirm_delivery', params: {'p_order_id': widget.orderId, 'p_received': received, 'p_note': note});
      _reload();
    });
  }

  Future<void> _issueInvoice() => guarded(context, () async {
        await sb.rpc('issue_invoice', params: {'p_order_id': widget.orderId});
        _reload();
      });

  Future<void> _setStatus(String s) => guarded(context, () async {
        await sb.from('orders').update({'status': s}).eq('id', widget.orderId);
        _reload();
      });

  Future<void> _addLine() async {
    final name = TextEditingController(), price = TextEditingController(), qty = TextEditingController(text: '1'), unit = TextEditingController(text: 'unité');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Ajouter un produit'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: name, decoration: const InputDecoration(labelText: 'Produit')),
          TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix unitaire')),
          TextField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité')),
          TextField(controller: unit, decoration: const InputDecoration(labelText: 'Unité')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Ajouter')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('order_items').insert({
        'order_id': widget.orderId,
        'name': name.text.trim(),
        'unit_price': n(price.text),
        'quantity': n(qty.text),
        'unit': unit.text.trim().isEmpty ? 'unité' : unit.text.trim(),
      });
      _reload();
    });
  }

  Future<void> _setSeller(Map<String, dynamic> item) async {
    final sellers = List<Map<String, dynamic>>.from(await sb.from('profiles').select('id, full_name, phone').eq('role', 'seller').order('full_name'));
    if (!mounted) return;
    final pick = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(title: const Text('Vendeur de ce produit'), children: [
        SimpleDialogOption(onPressed: () => Navigator.pop(ctx, ''), child: const Text('Aucun (vente MAYA)')),
        for (final v in sellers) SimpleDialogOption(onPressed: () => Navigator.pop(ctx, v['id'] as String), child: Text('${v['full_name'] ?? ''} ${v['phone'] ?? ''}')),
      ]),
    );
    if (pick == null || !mounted) return;
    await guarded(context, () async {
      await sb.from('order_items').update({'seller_id': pick.isEmpty ? null : pick}).eq('id', item['id']);
      _reload();
    });
  }

  Future<void> _refundSeller() => guarded(context, () async {
        final k = await sb.rpc('admin_refund_order_ledger', params: {'p_order_id': widget.orderId});
        if (mounted) snack(context, '$k gain(s) vendeur annulé(s) : les fonds bloqués ne seront pas versés.');
      });

  Future<void> _setCost(Map<String, dynamic> item) async {
    final t = await askText(context, 'Coût d\'achat unitaire (confidentiel)', multiline: false);
    if (t == null || t.isEmpty || !mounted) return;
    await guarded(context, () async {
      await sb.from('order_item_costs').upsert({'order_item_id': item['id'], 'unit_cost': n(t)});
      _reload();
    });
  }

  Future<void> _paymentLink(Map<String, dynamic> o, Map<String, dynamic> inv) async {
    final provider = TextEditingController(), ref = TextEditingController(), link = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Lien de paiement'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: provider, decoration: const InputDecoration(labelText: 'Prestataire')),
          TextField(controller: ref, decoration: const InputDecoration(labelText: 'Référence du prestataire')),
          TextField(controller: link, keyboardType: TextInputType.url, decoration: const InputDecoration(labelText: 'Lien de paiement (https://…)')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Envoyer au client')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('payments').insert({
        'invoice_id': inv['id'],
        'order_id': o['id'],
        'client_id': o['client_id'],
        'provider': provider.text.trim(),
        'provider_ref': ref.text.trim().isEmpty ? null : ref.text.trim(),
        'amount': inv['total'],
        'currency': inv['currency'],
        'payment_link': link.text.trim(),
        'created_by': uid,
      });
      _reload();
    });
  }

  Future<void> _shipping(Map<String, dynamic>? dd) async {
    final name = TextEditingController(text: dd?['carrier_name'] as String?);
    final phone = TextEditingController(text: dd?['carrier_phone'] as String?);
    final place = TextEditingController(text: dd?['arrival_place'] as String?);
    final notes = TextEditingController(text: dd?['notes'] as String?);
    DateTime? arrival = dd?['expected_arrival_date'] == null ? null : DateTime.parse(dd!['expected_arrival_date'] as String);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Expédition'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom du transporteur')),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone du transporteur')),
              TextField(controller: place, decoration: const InputDecoration(labelText: 'Ville / lieu d\'arrivée')),
              TextField(controller: notes, decoration: const InputDecoration(labelText: 'Informations complémentaires')),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () async {
                  final d = await showDatePicker(
                      context: ctx, initialDate: arrival ?? DateTime.now(), firstDate: DateTime.now().subtract(const Duration(days: 30)), lastDate: DateTime.now().add(const Duration(days: 365)));
                  if (d != null) setS(() => arrival = d);
                },
                child: Text(arrival == null ? 'Date d\'arrivée prévue' : 'Arrivée prévue : ${dOnly(arrival!.toIso8601String())}'),
              ),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('delivery_details').upsert({
        'order_id': widget.orderId,
        'carrier_name': name.text.trim(),
        'carrier_phone': phone.text.trim(),
        'arrival_place': place.text.trim(),
        'notes': notes.text.trim(),
        'expected_arrival_date': arrival?.toIso8601String().substring(0, 10),
      }, onConflict: 'order_id');
      _reload();
    });
  }

  Future<void> _resolve(Map<String, dynamic> d) async {
    final t = await askText(context, 'Résolution du signalement');
    if (t == null || !mounted) return;
    await guarded(context, () async {
      await sb.from('disputes').update({'status': 'resolved', 'resolution': t}).eq('id', d['id']);
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return Scaffold(appBar: AppBar(), body: errorView(snap.error));
          if (!snap.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
          final o = snap.data!;
          final items = List<Map<String, dynamic>>.from(o['order_items'] as List);
          final invoices = List<Map<String, dynamic>>.from(o['invoices'] as List)
            ..sort((a, b) => (b['created_at'] as String).compareTo(a['created_at'] as String));
          final inv = invoices.where((i) => i['status'] != 'cancelled').cast<Map<String, dynamic>?>().firstWhere((_) => true, orElse: () => null);
          final payments = List<Map<String, dynamic>>.from(o['payments'] as List);
          final dd = _one(o['delivery_details']);
          final disputes = List<Map<String, dynamic>>.from(o['disputes'] as List);
          final status = o['status'] as String;
          final cur = o['currency'] as String;
          final canConfirm = !widget.admin && const ['handed_to_carrier', 'in_transit', 'arrived', 'reception_pending', 'not_received_to_verify'].contains(status);
          final pending = payments.where((p) => p['status'] == 'pending' && (p['payment_link'] as String?)?.isNotEmpty == true).toList();
          return Scaffold(
            appBar: AppBar(
              title: Text(o['number'] as String),
              actions: [
                if (widget.admin)
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.flag),
                    tooltip: 'Changer le statut',
                    onSelected: _setStatus,
                    itemBuilder: (_) => [
                      for (final s in ['preparing', 'ready_to_ship', 'in_transit', 'arrived', 'received', 'not_received_to_verify'])
                        PopupMenuItem(value: s, child: Text(orderStatusLabels[s]!)),
                    ],
                  ),
              ],
            ),
            body: ListView(padding: const EdgeInsets.all(12), children: [
              Chip(
                label: Text(orderStatusLabels[status] ?? status),
                backgroundColor: status == 'not_received_to_verify' ? Colors.red.shade100 : null,
              ),
              if (widget.admin) Text('Client : ${(o['profiles'] as Map?)?['full_name'] ?? ''}  ${(o['profiles'] as Map?)?['phone'] ?? ''}'),
              Section('Produits', [
                for (final it in items)
                  InkWell(
                    onTap: widget.admin ? () => _setCost(it) : null,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(vertical: 4),
                      child: Row(children: [
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(it['name'] as String),
                            Text('${money(it['unit_price'], cur)} × ${n(it['quantity'])} ${it['unit']}', style: const TextStyle(fontSize: 12)),
                            if (widget.admin && _costs.containsKey(it['id']))
                              Text('Coût d\'achat : ${money(_costs[it['id']], cur)}', style: const TextStyle(fontSize: 11, color: Colors.deepOrange)),
                          ]),
                        ),
                        Text(money(it['line_total'], cur)),
                        if (widget.admin)
                          IconButton(
                            tooltip: 'Vendeur de ce produit',
                            icon: Icon(Icons.storefront, color: it['seller_id'] != null ? maliGreen : Colors.grey),
                            onPressed: () => _setSeller(it),
                          ),
                      ]),
                    ),
                  ),
                const Divider(),
                _row('Sous-total', money(o['subtotal'], cur)),
                _row('Transport', money(o['shipping_fee'], cur)),
                if (n(o['other_fees']) > 0) _row('Autres frais', money(o['other_fees'], cur)),
                if (n(o['discount']) > 0) _row('Réduction', '- ${money(o['discount'], cur)}'),
                _row('TOTAL', money(o['total'], cur), bold: true),
                if (widget.admin && invoices.every((i) => i['status'] != 'paid'))
                  TextButton.icon(onPressed: _addLine, icon: const Icon(Icons.add), label: const Text('Ajouter un produit')),
              ]),
              Section('Facture', [
                if (inv == null) const Text('Aucune facture pour le moment.') else ...[
                  Text('${inv['number']} · version ${inv['version']} · ${inv['status'] == 'paid' ? 'PAYÉE' : 'à payer'}'),
                  TextButton.icon(
                    icon: const Icon(Icons.picture_as_pdf),
                    label: const Text('Voir / partager le PDF'),
                    onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => InvoiceScreen(invoiceId: inv['id'] as String))),
                  ),
                ],
                if (widget.admin && (inv == null || inv['status'] != 'paid'))
                  FilledButton(onPressed: _issueInvoice, child: Text(inv == null ? 'Émettre la facture' : 'Mettre à jour la facture')),
              ]),
              Section('Paiement', [
                if (payments.isEmpty) const Text('Aucun paiement.'),
                for (final p in payments) Text('${money(p['amount'], cur)} · ${paymentStatusLabels[p['status']] ?? p['status']} ${p['paid_at'] != null ? '· ${dt(p['paid_at'])}' : ''}'),
                if (!widget.admin)
                  for (final p in pending)
                    FilledButton.icon(
                      icon: const Icon(Icons.lock),
                      label: const Text('Payer en ligne'),
                      onPressed: () => launchUrl(Uri.parse(p['payment_link'] as String), mode: LaunchMode.externalApplication),
                    ),
                if (widget.admin && inv != null && inv['status'] != 'paid')
                  OutlinedButton(onPressed: () => _paymentLink(o, inv), child: const Text('Créer un lien de paiement')),
                const Text('Le paiement est confirmé uniquement par le serveur.', style: TextStyle(fontSize: 11)),
              ]),
              Section('Livraison', [
                if (dd == null) const Text('Pas encore expédiée.') else ...[
                  Text('Transporteur : ${dd['carrier_name']}'),
                  Text('Téléphone : ${dd['carrier_phone']}'),
                  if (dd['arrival_place'] != null) Text('Arrivée : ${dd['arrival_place']}'),
                  if (dd['expected_arrival_date'] != null) Text('Date prévue : ${dOnly(dd['expected_arrival_date'])}'),
                  const SizedBox(height: 8),
                  CarrierButtons(phone: dd['carrier_phone'] as String),
                ],
                if (widget.admin) OutlinedButton(onPressed: () => _shipping(dd), child: Text(dd == null ? 'Enregistrer l\'expédition' : 'Modifier l\'expédition')),
                if (canConfirm) ...[
                  const SizedBox(height: 12),
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(color: const Color(0xFFFFF4E0), borderRadius: BorderRadius.circular(12), border: Border.all(color: gold)),
                    child: const Text(
                        '⚠ Ne confirmez « COLIS REÇU » qu\'après avoir réellement reçu et vérifié votre colis : cela paie le vendeur. '
                        'En cas de problème (non reçu, incomplet, endommagé), signalez-le : l\'administration examine le litige.',
                        style: TextStyle(fontSize: 12.5)),
                  ),
                  const SizedBox(height: 8),
                  const Text('AVEZ-VOUS REÇU VOTRE COLIS ?', style: TextStyle(fontWeight: FontWeight.bold)),
                  Row(children: [
                    Expanded(child: FilledButton(onPressed: () => _confirm(true), child: const Text('COLIS REÇU'))),
                    const SizedBox(width: 8),
                    Expanded(child: FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => _confirm(false), child: const Text('COLIS NON REÇU'))),
                  ]),
                  TextButton.icon(
                    icon: const Icon(Icons.report_problem_outlined),
                    label: const Text('Colis incomplet ou endommagé : signaler'),
                    onPressed: () => _confirm(false, prefix: 'COLIS INCOMPLET OU ENDOMMAGÉ'),
                  ),
                ],
              ]),
              if (disputes.isNotEmpty)
                Section('Signalements', [
                  for (final d in disputes)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text(d['status'] == 'resolved' ? 'Résolu' : 'COLIS NON REÇU – à vérifier'),
                      subtitle: Text('${dt(d['created_at'])}${d['reason'] != null ? '\n${d['reason']}' : ''}${d['resolution'] != null ? '\nRésolution : ${d['resolution']}' : ''}'),
                      trailing: widget.admin && d['status'] != 'resolved' ? TextButton(onPressed: () => _resolve(d), child: const Text('Résoudre')) : null,
                    ),
                  if (widget.admin && disputes.any((d) => d['status'] != 'resolved'))
                    TextButton.icon(
                      icon: const Icon(Icons.undo, color: Colors.red),
                      label: const Text('Litige en faveur du client : annuler les fonds du vendeur', style: TextStyle(color: Colors.red)),
                      onPressed: _refundSeller,
                    ),
                ]),
            ]),
          );
        },
      );

  Widget _row(String a, String b, {bool bold = false}) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 2),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          Text(a, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)),
          Text(b, style: TextStyle(fontWeight: bold ? FontWeight.bold : null)),
        ]),
      );
}

// ---------------- Factures ----------------
class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});
  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen> {
  late final Future<List<Map<String, dynamic>>> _f = sb
      .from('invoices')
      .select('*, orders(number)')
      .order('created_at', ascending: false)
      .then((r) => List<Map<String, dynamic>>.from(r));
  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          if (snap.data!.isEmpty) return const Center(child: Text('Aucune facture.'));
          return ListView(children: [
            for (final i in snap.data!)
              ListTile(
                leading: Icon(i['status'] == 'paid' ? Icons.check_circle : Icons.receipt_long, color: i['status'] == 'paid' ? Colors.green : null),
                title: Text('${i['number']}'),
                subtitle: Text('Commande ${(i['orders'] as Map?)?['number'] ?? ''} · ${i['status'] == 'paid' ? 'Payée' : 'À payer'}'),
                trailing: Text(money(i['total'], i['currency'] as String)),
                onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => InvoiceScreen(invoiceId: i['id'] as String))),
              ),
          ]);
        },
      );
}

class InvoiceScreen extends StatelessWidget {
  final String invoiceId;
  const InvoiceScreen({super.key, required this.invoiceId});

  Future<Map<String, dynamic>> _load() => sb
      .from('invoices')
      .select('*, orders(number), profiles!invoices_client_id_fkey(full_name,phone)')
      .eq('id', invoiceId)
      .single();

  Future<Uint8List> _pdf(Map<String, dynamic> inv) async {
    final cur = inv['currency'] as String;
    final items = List<Map<String, dynamic>>.from(inv['items'] as List);
    final reg = pw.Font.ttf(await rootBundle.load('assets/fonts/LiberationSans-Regular.ttf'));
    final bold = pw.Font.ttf(await rootBundle.load('assets/fonts/LiberationSans-Bold.ttf'));
    final logo = pw.MemoryImage((await rootBundle.load('assets/logo.png')).buffer.asUint8List());
    const blue = PdfColor.fromInt(0xFF0F7A28);
    final paid = inv['status'] == 'paid';
    final doc = pw.Document(theme: pw.ThemeData.withFont(base: reg, bold: bold));
    pw.Widget row(String a, String b, {bool strong = false}) => pw.Padding(
          padding: const pw.EdgeInsets.symmetric(vertical: 2),
          child: pw.Row(mainAxisAlignment: pw.MainAxisAlignment.spaceBetween, children: [
            pw.Text(a, style: pw.TextStyle(fontWeight: strong ? pw.FontWeight.bold : pw.FontWeight.normal, fontSize: strong ? 14 : 11)),
            pw.Text(b, style: pw.TextStyle(fontWeight: strong ? pw.FontWeight.bold : pw.FontWeight.normal, fontSize: strong ? 14 : 11)),
          ]),
        );
    doc.addPage(pw.MultiPage(
      margin: const pw.EdgeInsets.all(32),
      build: (c) => [
        pw.Row(crossAxisAlignment: pw.CrossAxisAlignment.center, children: [
          pw.Image(logo, width: 80, height: 80),
          pw.SizedBox(width: 14),
          pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text('MAYA', style: pw.TextStyle(fontSize: 28, fontWeight: pw.FontWeight.bold, color: blue)),
            pw.Text('Achetez • Vendez • Livrez', style: const pw.TextStyle(fontSize: 11)),
          ]),
        ]),
        pw.SizedBox(height: 16),
        pw.Text('FACTURE ${inv['number']}', style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
        pw.Text('Commande : ${(inv['orders'] as Map?)?['number'] ?? ''}'),
        pw.Text('Date : ${dOnly(inv['issued_at'] ?? inv['created_at'])}'),
        pw.Text('Client : ${(inv['profiles'] as Map?)?['full_name'] ?? ''} ${(inv['profiles'] as Map?)?['phone'] ?? ''}'),
        pw.SizedBox(height: 14),
        pw.TableHelper.fromTextArray(
          headers: ['Produit', 'Prix unitaire', 'Quantité', 'Montant'],
          headerStyle: pw.TextStyle(color: PdfColors.white, fontWeight: pw.FontWeight.bold),
          headerDecoration: const pw.BoxDecoration(color: blue),
          cellAlignments: {1: pw.Alignment.centerRight, 2: pw.Alignment.centerRight, 3: pw.Alignment.centerRight},
          data: [
            for (final it in items) [it['name'], money(it['unit_price'], cur), '${n(it['quantity'])} ${it['unit']}', money(it['line_total'], cur)],
          ],
        ),
        pw.SizedBox(height: 12),
        row('Sous-total', money(inv['subtotal'], cur)),
        row('Frais de transport', money(inv['shipping_fee'], cur)),
        row('Autres frais', money(inv['other_fees'], cur)),
        row('Réduction', '- ${money(inv['discount'], cur)}'),
        pw.Divider(),
        row('TOTAL À PAYER', money(inv['total'], cur), strong: true),
        pw.SizedBox(height: 8),
        pw.Text('Statut du paiement : ${paid ? 'PAYÉE' : 'EN ATTENTE DE PAIEMENT'}',
            style: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: paid ? PdfColors.green800 : PdfColors.orange800)),
      ],
    ));
    return doc.save();
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: _load(),
        builder: (context, snap) {
          if (snap.hasError) return Scaffold(appBar: AppBar(), body: errorView(snap.error));
          if (!snap.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
          final inv = snap.data!;
          final cur = inv['currency'] as String;
          final items = List<Map<String, dynamic>>.from(inv['items'] as List);
          return Scaffold(
            appBar: AppBar(title: Text('${inv['number']}')),
            body: ListView(padding: const EdgeInsets.all(12), children: [
              const Center(child: SaambaLogo(size: 100)),
              const SizedBox(height: 8),
              Text('Commande ${(inv['orders'] as Map?)?['number'] ?? ''} · version ${inv['version']}'),
              Text('Statut : ${inv['status'] == 'paid' ? 'PAYÉE' : 'EN ATTENTE DE PAIEMENT'}'),
              const Divider(),
              for (final it in items)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('${it['name']}'),
                  subtitle: Text('${money(it['unit_price'], cur)} × ${n(it['quantity'])} ${it['unit']}'),
                  trailing: Text(money(it['line_total'], cur)),
                ),
              const Divider(),
              Text('Sous-total : ${money(inv['subtotal'], cur)}'),
              Text('Transport : ${money(inv['shipping_fee'], cur)}'),
              Text('Autres frais : ${money(inv['other_fees'], cur)}'),
              Text('Réduction : ${money(inv['discount'], cur)}'),
              Text('TOTAL : ${money(inv['total'], cur)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              FilledButton.icon(
                icon: const Icon(Icons.picture_as_pdf),
                label: const Text('Télécharger / partager le PDF'),
                onPressed: () async => Printing.sharePdf(bytes: await _pdf(inv), filename: '${inv['number']}.pdf'),
              ),
            ]),
          );
        },
      );
}

// ---------------- Notifications & profil ----------------
class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: sb.from('notifications').stream(primaryKey: ['id']).eq('user_id', uid).order('created_at', ascending: false),
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('Aucune notification.'));
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final nt = list[i];
              final unread = nt['read_at'] == null;
              return ListTile(
                leading: Icon(unread ? Icons.circle : Icons.circle_outlined, size: 12, color: unread ? Colors.green : null),
                title: Text(nt['title'] as String, style: TextStyle(fontWeight: unread ? FontWeight.bold : null)),
                subtitle: Text('${nt['body'] ?? ''}\n${dt(nt['created_at'])}'),
                isThreeLine: true,
                onTap: () async {
                  await sb.from('notifications').update({'read_at': DateTime.now().toUtc().toIso8601String()}).eq('id', nt['id']);
                  final data = (nt['data'] as Map?) ?? {};
                  if (data['order_id'] != null && context.mounted) {
                    final admin = (await sb.from('profiles').select('role').eq('id', uid).single())['role'] == 'admin';
                    if (context.mounted) {
                      Navigator.push(context, MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: data['order_id'] as String, admin: admin)));
                    }
                  }
                },
              );
            },
          );
        },
      );
}

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _name = TextEditingController(), _code = TextEditingController();
  String _role = 'client';
  bool _loaded = false;
  @override
  void initState() {
    super.initState();
    sb.from('profiles').select().eq('id', uid).single().then((p) {
      _name.text = (p['full_name'] as String?) ?? '';
      _role = p['role'] as String;
      if (mounted) setState(() => _loaded = true);
    });
  }

  @override
  Widget build(BuildContext context) => !_loaded
      ? const Center(child: CircularProgressIndicator())
      : ListView(padding: const EdgeInsets.all(16), children: [
          Text(sb.auth.currentUser?.email?.split('@').first ?? '', style: const TextStyle(fontSize: 16)),
          const SizedBox(height: 12),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nom complet', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          FilledButton(
            onPressed: () => guarded(context, () async {
              await sb.from('profiles').update({'full_name': _name.text.trim()}).eq('id', uid);
              if (mounted) snack(context, 'Profil enregistré.');
            }),
            child: const Text('Enregistrer'),
          ),
          if (_role == 'client') ...[
            const Divider(height: 32),
            const Text('Vous êtes grossiste invité ?', style: TextStyle(fontWeight: FontWeight.bold)),
            TextField(controller: _code, decoration: const InputDecoration(labelText: 'Code d\'invitation', border: OutlineInputBorder())),
            const SizedBox(height: 8),
            OutlinedButton(
              onPressed: () => guarded(context, () async {
                await sb.rpc('accept_supplier_invitation', params: {'p_token': _code.text.trim()});
                roleRefresh.value++;
              }),
              child: const Text('Activer mon espace grossiste'),
            ),
          ],
          const Divider(height: 32),
          OutlinedButton.icon(icon: const Icon(Icons.logout), label: const Text('Se déconnecter'), onPressed: () => sb.auth.signOut()),
        ]);
}
