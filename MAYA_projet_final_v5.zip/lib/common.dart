import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

final SupabaseClient sb = Supabase.instance.client;
String get uid => sb.auth.currentUser!.id;
final ValueNotifier<int> roleRefresh = ValueNotifier<int>(0);
// Identité MAYA : vert profond (principal) et orange (secondaire)
const brand = Color(0xFF0F7A28);
const brandDark = Color(0xFF0A4D1C);
const gold = Color(0xFFFF7A00);
// Couleurs du drapeau du Mali
const maliGreen = Color(0xFF14B53A);
const maliGold = Color(0xFFFCD116);
const maliRed = Color(0xFFCE1126);
const surfaceBg = Color(0xFFF5F8F4);
const _line = Color(0xFFDDE7DC);

ThemeData saambaTheme() {
  final cs = ColorScheme.fromSeed(seedColor: brand).copyWith(primary: brand, secondary: gold, tertiary: gold);
  return ThemeData(
    colorScheme: cs,
    useMaterial3: true,
    scaffoldBackgroundColor: surfaceBg,
    appBarTheme: const AppBarTheme(
      backgroundColor: brandDark,
      foregroundColor: Colors.white,
      centerTitle: false,
      elevation: 0,
      scrolledUnderElevation: 0,
      iconTheme: IconThemeData(color: Colors.white),
      actionsIconTheme: IconThemeData(color: Colors.white),
    ),
    navigationBarTheme: const NavigationBarThemeData(
      backgroundColor: Colors.white,
      surfaceTintColor: Colors.transparent,
      indicatorColor: Color(0x33FF7A00),
      elevation: 6,
      height: 68,
    ),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: gold, foregroundColor: brandDark),
    filledButtonTheme: FilledButtonThemeData(
      style: FilledButton.styleFrom(
        minimumSize: const Size(48, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        minimumSize: const Size(48, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      ),
    ),
    inputDecorationTheme: const InputDecorationTheme(isDense: true),
  );
}

/// Bande tricolore du Mali (vert, jaune, rouge). Utilisable comme `bottom:` d'une AppBar.
class MaliStripe extends StatelessWidget implements PreferredSizeWidget {
  final double height;
  const MaliStripe({super.key, this.height = 4});
  @override
  Size get preferredSize => Size.fromHeight(height);
  @override
  Widget build(BuildContext context) => SizedBox(
        height: height,
        child: const Row(children: [
          Expanded(child: ColoredBox(color: maliGreen)),
          Expanded(child: ColoredBox(color: maliGold)),
          Expanded(child: ColoredBox(color: maliRed)),
        ]),
      );
}

class _SlideGT extends GradientTransform {
  final double p;
  const _SlideGT(this.p);
  @override
  Matrix4? transform(Rect bounds, {TextDirection? textDirection}) =>
      Matrix4.translationValues(bounds.width * p, 0.0, 0.0);
}

/// Slogan animé : les couleurs du Mali (vert, jaune, rouge) défilent en boucle dans le texte.
class AnimatedSlogan extends StatefulWidget {
  final double fontSize;
  final bool pill;
  final String text;
  const AnimatedSlogan({super.key, this.fontSize = 15, this.pill = true, this.text = 'Achetez • Vendez • Livrez'});
  @override
  State<AnimatedSlogan> createState() => _AnimatedSloganState();
}

class _AnimatedSloganState extends State<AnimatedSlogan> with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final text = AnimatedBuilder(
      animation: _c,
      builder: (_, __) => ShaderMask(
        blendMode: BlendMode.srcIn,
        shaderCallback: (rect) => LinearGradient(
          colors: const [Color(0xFF3EE060), maliGold, Color(0xFFFF4A5A), Color(0xFF3EE060)],
          stops: const [0.0, 0.33, 0.66, 1.0],
          tileMode: TileMode.repeated,
          transform: _SlideGT(_c.value),
        ).createShader(rect),
        child: Text(
          widget.text,
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: widget.fontSize, fontWeight: FontWeight.w800, letterSpacing: 1.1, color: Colors.white),
        ),
      ),
    );
    if (!widget.pill) return text;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(color: const Color(0xFF06300F), borderRadius: BorderRadius.circular(22)),
      child: text,
    );
  }
}

/// Bandeau d'accueil : logo, titre, bande tricolore et slogan animé.
class HeroBanner extends StatelessWidget {
  final String title;
  const HeroBanner({super.key, required this.title});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.only(bottom: 12),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: const LinearGradient(begin: Alignment.topLeft, end: Alignment.bottomRight, colors: [Color(0xFF06300F), brand]),
          borderRadius: BorderRadius.circular(22),
          boxShadow: const [BoxShadow(color: Color(0x330A2A78), blurRadius: 14, offset: Offset(0, 6))],
        ),
        child: Column(children: [
          Row(children: [
            const LogoBadge(size: 56),
            const SizedBox(width: 12),
            Expanded(child: Text(title, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800))),
          ]),
          const SizedBox(height: 12),
          ClipRRect(borderRadius: BorderRadius.circular(6), child: const MaliStripe(height: 5)),
          const SizedBox(height: 10),
          const AnimatedSlogan(pill: false, fontSize: 14),
        ]),
      );
}

/// Carte blanche arrondie.
BoxDecoration softBox({Color? color}) => BoxDecoration(
      color: color ?? Colors.white,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: _line),
    );

final _nf = NumberFormat('#,##0', 'fr_FR');
num n(dynamic v) => v is num ? v : (num.tryParse('$v') ?? 0);
String money(dynamic v, [String cur = 'XOF']) =>
    '${_nf.format(n(v)).replaceAll(RegExp('[\u202f\u00a0]'), ' ')} ${cur == 'XOF' ? 'FCFA' : cur}';
String dt(dynamic iso) => iso == null ? '' : DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse('$iso').toLocal());
String dOnly(dynamic iso) => iso == null ? '' : DateFormat('dd/MM/yyyy').format(DateTime.parse('$iso').toLocal());

const orderStatusLabels = <String, String>{
  'request_received': 'Demande reçue',
  'order_created': 'Commande créée',
  'invoice_sent': 'Facture envoyée',
  'payment_pending': 'Paiement en attente',
  'paid': 'Payée',
  'preparing': 'En préparation',
  'ready_to_ship': 'Prête à expédier',
  'handed_to_carrier': 'Remise au transporteur',
  'in_transit': 'En cours de transport',
  'arrived': 'Arrivée au lieu prévu',
  'reception_pending': 'Réception à confirmer',
  'received': 'Reçue par le client',
  'not_received_to_verify': 'NON REÇUE – À VÉRIFIER',
};

const paymentStatusLabels = <String, String>{
  'pending': 'En attente',
  'paid': 'Payé',
  'failed': 'Échoué',
  'cancelled': 'Annulé',
  'refunded': 'Remboursé',
};

String mimeFor(String name) {
  final e = name.toLowerCase().split('.').last;
  const m = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp',
    'mp4': 'video/mp4', 'mov': 'video/quicktime', 'm4a': 'audio/mp4', 'pdf': 'application/pdf',
    'doc': 'application/msword', 'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls': 'application/vnd.ms-excel', 'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  };
  return m[e] ?? 'application/octet-stream';
}

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

Future<void> guarded(BuildContext c, Future<void> Function() f) async {
  try {
    await f();
  } on PostgrestException catch (e) {
    if (c.mounted) snack(c, e.message);
  } on AuthException catch (e) {
    if (c.mounted) snack(c, e.message);
  } catch (e) {
    if (c.mounted) snack(c, 'Erreur : $e');
  }
}

Future<String?> askText(BuildContext c, String title, {String hint = '', bool multiline = true}) {
  final ctrl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: ctrl, autofocus: true, maxLines: multiline ? 3 : 1, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: const Text('OK')),
      ],
    ),
  );
}

Future<void> callCarrier(BuildContext context, String phone, String operator) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text('Appeler avec $operator'),
      content: Text('Votre téléphone va ouvrir l\'appel. Si vous avez deux cartes SIM, choisissez la SIM $operator dans le sélecteur Android. '
          'Si cette ligne n\'est pas disponible, utilisez la ligne disponible.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Appeler')),
      ],
    ),
  );
  if (ok == true) await launchUrl(Uri(scheme: 'tel', path: phone));
}

class CarrierButtons extends StatelessWidget {
  final String phone;
  const CarrierButtons({super.key, required this.phone});
  @override
  Widget build(BuildContext context) => Column(children: [
        SizedBox(width: double.infinity, child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF7900)),
          icon: const Icon(Icons.call), label: const Text('APPELER AVEC ORANGE'),
          onPressed: () => callCarrier(context, phone, 'Orange'))),
        const SizedBox(height: 6),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1565C0)),
          icon: const Icon(Icons.call), label: const Text('APPELER AVEC MALITEL'),
          onPressed: () => callCarrier(context, phone, 'Malitel'))),
      ]);
}

/// Symbole MAYA (sac « M » + panier), carré. `size` = côté en pixels logiques.
class SaambaLogo extends StatelessWidget {
  final double size;
  const SaambaLogo({super.key, this.size = 34});
  @override
  Widget build(BuildContext context) => Image.asset('assets/logo.png', width: size, height: size, fit: BoxFit.contain);
}

/// Symbole MAYA dans une pastille blanche arrondie (lisible sur fond vert).
class LogoBadge extends StatelessWidget {
  final double size;
  const LogoBadge({super.key, this.size = 40});
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        padding: EdgeInsets.all(size * 0.08),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(size * 0.28)),
        child: Image.asset('assets/logo.png', fit: BoxFit.contain),
      );
}

/// Logo complet MAYA (symbole, nom, signature et slogan).
class MayaFullLogo extends StatelessWidget {
  final double width;
  const MayaFullLogo({super.key, this.width = 280});
  @override
  Widget build(BuildContext context) => Image.asset('assets/logo_full.png', width: width, fit: BoxFit.contain);
}

/// Titre de barre d'application : logo + nom.
class SaambaTitle extends StatelessWidget {
  final String? suffix;
  const SaambaTitle({super.key, this.suffix});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        const LogoBadge(size: 36),
        const SizedBox(width: 8),
        const Text('MAYA', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5, color: Colors.white)),
        if (suffix != null) ...[
          const SizedBox(width: 8),
          Text(suffix!, style: const TextStyle(fontSize: 14, color: gold, fontWeight: FontWeight.w600)),
        ],
      ]);
}

/// Écran de démarrage.
class SplashView extends StatelessWidget {
  const SplashView({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.white,
        body: Column(children: [
          Expanded(
            child: Center(
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                const MayaFullLogo(width: 300),
                const SizedBox(height: 18),
                const AnimatedSlogan(text: 'Le commerce, plus proche de vous !', fontSize: 14),
                const SizedBox(height: 26),
                const SizedBox(width: 26, height: 26, child: CircularProgressIndicator(strokeWidth: 3, color: gold)),
              ]),
            ),
          ),
          const MaliStripe(height: 8),
        ]),
      );
}

class Section extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const Section(this.title, this.children, {super.key});
  @override
  Widget build(BuildContext context) => Container(
        margin: const EdgeInsets.symmetric(vertical: 6),
        padding: const EdgeInsets.all(14),
        decoration: softBox(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(width: 4, height: 16, decoration: BoxDecoration(color: maliGreen, borderRadius: BorderRadius.circular(2))),
            const SizedBox(width: 8),
            Expanded(child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: brandDark))),
          ]),
          const SizedBox(height: 8),
          ...children,
        ]),
      );
}

Widget errorView(Object? e) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Erreur : $e', textAlign: TextAlign.center)));
