import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';
import 'orders.dart';
import 'partners.dart';

// ======== Espace grossiste (compte invité) ========
class SupplierShell extends StatefulWidget {
  const SupplierShell({super.key});
  @override
  State<SupplierShell> createState() => _SupplierShellState();
}

class _SupplierShellState extends State<SupplierShell> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async => List<Map<String, dynamic>>.from(
      await sb.from('supplier_requests').select('*, suppliers(name)').order('created_at', ascending: false));

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          title: const SaambaTitle(suffix: 'Grossiste'),
          actions: [
            IconButton(icon: const Icon(Icons.notifications_none), onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Notifications')), body: const NotificationsScreen())))),
            IconButton(icon: const Icon(Icons.logout), onPressed: () => sb.auth.signOut()),
          ],
        ),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            if (snap.data!.isEmpty) return const Center(child: Text('Aucune demande pour le moment.'));
            return RefreshIndicator(
              onRefresh: () async => setState(() => _f = _load()),
              child: ListView(children: [
                for (final r in snap.data!)
                  ListTile(
                    title: Text((r['title'] as String?) ?? 'Demande de prix'),
                    subtitle: Text('${dt(r['sent_at'] ?? r['created_at'])} · ${_reqStatus(r['status'] as String)}'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => RequestDetailScreen(requestId: r['id'] as String, admin: false)));
                      setState(() => _f = _load());
                    },
                  ),
              ]),
            );
          },
        ),
      );
}

String _reqStatus(String s) => const {'draft': 'Brouillon', 'sent': 'À répondre', 'answered': 'Répondue', 'cancelled': 'Annulée'}[s] ?? s;
String _avail(String s) => const {'available': 'Disponible', 'partial': 'Partiellement disponible', 'unavailable': 'Indisponible'}[s] ?? s;

// ---------- Pièces jointes (photos / documents) ----------
class PickedAttachment {
  final File file;
  final String name;
  PickedAttachment(this.file, this.name);
}

Future<void> uploadSupplierAttachments(String supplierId, List<PickedAttachment> items, {String? requestId, String? responseId}) async {
  for (var i = 0; i < items.length; i++) {
    final a = items[i];
    final dot = a.name.lastIndexOf('.');
    final ext = dot > 0 ? a.name.substring(dot + 1) : 'bin';
    final path = '$supplierId/${DateTime.now().microsecondsSinceEpoch}_$i.$ext';
    await sb.storage.from('supplier-files').upload(path, a.file, fileOptions: FileOptions(contentType: mimeFor(a.name)));
    await sb.from('supplier_attachments').insert({
      'supplier_id': supplierId,
      'request_id': requestId,
      'response_id': responseId,
      'storage_path': path,
      'mime_type': mimeFor(a.name),
      'original_name': a.name,
      'uploaded_by': uid,
    });
  }
}

Future<void> openSupplierFile(BuildContext c, String path) => guarded(c, () async {
      final url = await sb.storage.from('supplier-files').createSignedUrl(path, 600);
      await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    });

Widget supplierFileButton(BuildContext c, Map<String, dynamic> a) => Align(
      alignment: Alignment.centerLeft,
      child: TextButton.icon(
        icon: const Icon(Icons.attach_file, size: 18),
        label: Text((a['original_name'] as String?) ?? 'Pièce jointe'),
        onPressed: () => openSupplierFile(c, a['storage_path'] as String),
      ),
    );

class AttachmentPicker extends StatelessWidget {
  final List<PickedAttachment> items;
  final VoidCallback onChanged;
  const AttachmentPicker({super.key, required this.items, required this.onChanged});

  Future<void> _add(BuildContext context) async {
    final c = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.photo), title: const Text('Photo / capture d\'écran'), onTap: () => Navigator.pop(ctx, 'photo')),
          ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Appareil photo'), onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(leading: const Icon(Icons.description), title: const Text('Document'), onTap: () => Navigator.pop(ctx, 'doc')),
        ]),
      ),
    );
    if (c == null) return;
    if (c == 'doc') {
      final r = await FilePicker.platform.pickFiles();
      final f = r?.files.single;
      if (f?.path != null) items.add(PickedAttachment(File(f!.path!), f.name));
    } else {
      final x = await ImagePicker().pickImage(source: c == 'photo' ? ImageSource.gallery : ImageSource.camera, imageQuality: 70, maxWidth: 1600);
      if (x != null) items.add(PickedAttachment(File(x.path), x.name));
    }
    onChanged();
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (var i = 0; i < items.length; i++)
          ListTile(
            dense: true,
            contentPadding: EdgeInsets.zero,
            leading: const Icon(Icons.attach_file),
            title: Text(items[i].name, maxLines: 1, overflow: TextOverflow.ellipsis),
            trailing: IconButton(icon: const Icon(Icons.close), onPressed: () { items.removeAt(i); onChanged(); }),
          ),
        OutlinedButton.icon(onPressed: () => _add(context), icon: const Icon(Icons.add_a_photo_outlined), label: const Text('Joindre une photo / un document')),
      ]);
}

// ======== Espace administration : grossistes ========
class SuppliersHome extends StatelessWidget {
  const SuppliersHome({super.key});
  @override
  Widget build(BuildContext context) => const DefaultTabController(
        length: 3,
        child: Column(children: [
          TabBar(tabs: [Tab(text: 'Grossistes'), Tab(text: 'Prix'), Tab(text: 'Vérification')]),
          Expanded(child: TabBarView(children: [SuppliersList(), ComparisonScreen(), PartnersScreen()])),
        ]),
      );
}

class SuppliersList extends StatefulWidget {
  const SuppliersList({super.key});
  @override
  State<SuppliersList> createState() => _SuppliersListState();
}

class _SuppliersListState extends State<SuppliersList> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  String _q = '';
  bool _archived = false;
  Future<List<Map<String, dynamic>>> _load() async =>
      List<Map<String, dynamic>>.from(await sb.from('suppliers').select().order('name'));

  Future<void> _add() async {
    final c = {for (final k in ['name', 'manager_name', 'phone', 'whatsapp', 'city', 'address', 'description']) k: TextEditingController()};
    final labels = {'name': 'Nom du grossiste / entreprise', 'manager_name': 'Responsable', 'phone': 'Téléphone', 'whatsapp': 'WhatsApp', 'city': 'Ville', 'address': 'Adresse', 'description': 'Description'};
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nouveau grossiste'),
        content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
          for (final k in c.keys) TextField(controller: c[k], decoration: InputDecoration(labelText: labels[k])),
        ])),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Créer')),
        ],
      ),
    );
    if (ok != true || c['name']!.text.trim().isEmpty || !mounted) return;
    await guarded(context, () async {
      await sb.from('suppliers').insert({for (final k in c.keys) k: c[k]!.text.trim().isEmpty ? null : c[k]!.text.trim(), 'created_by': uid});
      setState(() => _f = _load());
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Grossiste')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(
                child: TextField(
                  decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher un grossiste', border: OutlineInputBorder()),
                  onChanged: (v) => setState(() => _q = v.toLowerCase()),
                ),
              ),
              const SizedBox(width: 8),
              FilterChip(label: const Text('Archivés'), selected: _archived, onSelected: (v) => setState(() => _archived = v)),
            ]),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _f,
              builder: (context, snap) {
                if (snap.hasError) return errorView(snap.error);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final list = snap.data!.where((s) {
                  if ((s['status'] == 'archived') != _archived) return false;
                  final hay = '${s['name']} ${s['city']} ${s['phone']} ${s['manager_name']}'.toLowerCase();
                  return hay.contains(_q);
                }).toList();
                if (list.isEmpty) return Center(child: Text(_archived ? 'Aucun grossiste archivé.' : 'Aucun grossiste. Créez le premier.'));
                return ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final s = list[i];
                    return ListTile(
                      leading: const CircleAvatar(child: Icon(Icons.storefront)),
                      title: Text(s['name'] as String),
                      subtitle: Text('${s['city'] ?? ''} ${s['phone'] ?? ''}${s['status'] == 'archived' ? ' · ARCHIVÉ' : ''}'),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => SupplierDetailScreen(supplier: s)));
                        setState(() => _f = _load());
                      },
                    );
                  },
                );
              },
            ),
          ),
        ]),
      );
}

class SupplierDetailScreen extends StatefulWidget {
  final Map<String, dynamic> supplier;
  const SupplierDetailScreen({super.key, required this.supplier});
  @override
  State<SupplierDetailScreen> createState() => _SupplierDetailScreenState();
}

class _SupplierDetailScreenState extends State<SupplierDetailScreen> {
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() => Future.wait([
        sb.from('supplier_requests').select('*, supplier_request_items(count)').eq('supplier_id', widget.supplier['id']).order('created_at', ascending: false),
        sb.from('supplier_notes').select().eq('supplier_id', widget.supplier['id']).order('created_at', ascending: false),
      ]);
  void _reload() => setState(() => _f = _load());

  Future<void> _invite() => guarded(context, () async {
        final r = await sb.from('supplier_invitations').insert({'supplier_id': widget.supplier['id'], 'created_by': uid}).select('token').single();
        final code = r['token'] as String;
        if (!mounted) return;
        await showDialog<void>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Invitation grossiste'),
            content: Text('Envoyez ce code au grossiste (valable 7 jours). Après avoir créé un compte MAYA, il le saisit dans Profil > Activer mon espace grossiste.\n\n$code'),
            actions: [
              TextButton(onPressed: () { Clipboard.setData(ClipboardData(text: code)); Navigator.pop(ctx); }, child: const Text('Copier')),
              FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer')),
            ],
          ),
        );
      });

  Future<void> _note() async {
    final t = await askText(context, 'Note privée');
    if (t == null || t.isEmpty || !mounted) return;
    await guarded(context, () async {
      await sb.from('supplier_notes').insert({'supplier_id': widget.supplier['id'], 'note': t, 'created_by': uid});
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) {
    final s = widget.supplier;
    final wa = '${s['whatsapp'] ?? ''}'.replaceAll(RegExp(r'\D'), '');
    return Scaffold(
      appBar: AppBar(title: Text(s['name'] as String), actions: [
        PopupMenuButton<String>(
          onSelected: (v) async {
            if (v == 'archive') {
              await guarded(context, () async {
                await sb.from('suppliers').update({'status': s['status'] == 'archived' ? 'active' : 'archived'}).eq('id', s['id']);
                if (mounted) Navigator.pop(context);
              });
            }
          },
          itemBuilder: (_) => [PopupMenuItem(value: 'archive', child: Text(s['status'] == 'archived' ? 'Réactiver' : 'Archiver'))],
        ),
      ]),
      body: FutureBuilder<List<dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final reqs = List<Map<String, dynamic>>.from(snap.data![0] as List);
          final notes = List<Map<String, dynamic>>.from(snap.data![1] as List);
          return ListView(padding: const EdgeInsets.all(12), children: [
            Section('Informations', [
              VerifiedBadge('${s['verification_status']}'),
              if (s['manager_name'] != null) Text('Responsable : ${s['manager_name']}'),
              Text('Téléphone : ${s['phone'] ?? '-'}'),
              Text('Ville : ${s['city'] ?? '-'}  ${s['address'] ?? ''}'),
              if (s['description'] != null) Text('${s['description']}'),
              Wrap(spacing: 8, children: [
                if (s['phone'] != null) OutlinedButton.icon(icon: const Icon(Icons.call), label: const Text('Appeler'), onPressed: () => launchUrl(Uri(scheme: 'tel', path: s['phone'] as String))),
                if (wa.isNotEmpty) OutlinedButton.icon(icon: const Icon(Icons.chat), label: const Text('WhatsApp'), onPressed: () => launchUrl(Uri.parse('https://wa.me/$wa'), mode: LaunchMode.externalApplication)),
                OutlinedButton.icon(icon: const Icon(Icons.person_add), label: const Text('Inviter dans MAYA'), onPressed: _invite),
              ]),
            ]),
            FilledButton.icon(
              icon: const Icon(Icons.request_quote),
              label: const Text('Nouvelle demande de prix / disponibilité'),
              onPressed: () async {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => NewRequestScreen(supplierId: s['id'] as String)));
                _reload();
              },
            ),
            Section('Demandes et archives', [
              if (reqs.isEmpty) const Text('Aucune demande.'),
              for (final r in reqs)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text((r['title'] as String?) ?? 'Demande'),
                  subtitle: Text('${dt(r['created_at'])} · ${_reqStatus(r['status'] as String)}'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => RequestDetailScreen(requestId: r['id'] as String, admin: true)));
                    _reload();
                  },
                ),
            ]),
            Section('Notes privées', [
              for (final nt in notes) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('${dt(nt['created_at'])}\n${nt['note']}')),
              TextButton.icon(onPressed: _note, icon: const Icon(Icons.note_add), label: const Text('Ajouter une note')),
            ]),
          ]);
        },
      ),
    );
  }
}

class _ReqLine {
  final name = TextEditingController(), qty = TextEditingController(), unit = TextEditingController(), ref = TextEditingController();
}

class NewRequestScreen extends StatefulWidget {
  final String supplierId;
  const NewRequestScreen({super.key, required this.supplierId});
  @override
  State<NewRequestScreen> createState() => _NewRequestScreenState();
}

class _NewRequestScreenState extends State<NewRequestScreen> {
  final _title = TextEditingController(), _comments = TextEditingController();
  final List<_ReqLine> _lines = [_ReqLine()];
  DateTime? _deadline;
  bool _busy = false;
  final List<PickedAttachment> _files = [];

  Future<void> _save() async {
    final valid = _lines.where((l) => l.name.text.trim().isNotEmpty).toList();
    if (valid.isEmpty) return snack(context, 'Ajoutez au moins un produit.');
    setState(() => _busy = true);
    await guarded(context, () async {
      final r = await sb.from('supplier_requests').insert({
        'supplier_id': widget.supplierId,
        'title': _title.text.trim().isEmpty ? null : _title.text.trim(),
        'comments': _comments.text.trim().isEmpty ? null : _comments.text.trim(),
        'desired_deadline': _deadline?.toIso8601String().substring(0, 10),
        'created_by': uid,
      }).select('id').single();
      await sb.from('supplier_request_items').insert([
        for (final l in valid)
          {
            'request_id': r['id'],
            'product_name': l.name.text.trim(),
            'reference': l.ref.text.trim().isEmpty ? null : l.ref.text.trim(),
            'quantity': l.qty.text.trim().isEmpty ? null : n(l.qty.text),
            'unit': l.unit.text.trim().isEmpty ? null : l.unit.text.trim(),
          }
      ]);
      await sb.from('supplier_requests').update({'status': 'sent'}).eq('id', r['id']);
      if (_files.isNotEmpty) {
        try {
          await uploadSupplierAttachments(widget.supplierId, _files, requestId: r['id'] as String);
        } catch (_) {
          if (mounted) snack(context, 'Demande envoyée, mais certaines pièces jointes n\'ont pas pu être envoyées.');
        }
      }
      if (mounted) Navigator.pop(context);
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Nouvelle demande')),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          TextField(controller: _title, decoration: const InputDecoration(labelText: 'Titre (facultatif)', border: OutlineInputBorder())),
          const SizedBox(height: 8),
          for (var i = 0; i < _lines.length; i++)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(children: [
                  Row(children: [
                    Expanded(child: TextField(controller: _lines[i].name, decoration: InputDecoration(labelText: 'Produit ${i + 1}'))),
                    if (_lines.length > 1) IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => _lines.removeAt(i))),
                  ]),
                  Row(children: [
                    Expanded(child: TextField(controller: _lines[i].qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].unit, decoration: const InputDecoration(labelText: 'Unité'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].ref, decoration: const InputDecoration(labelText: 'Référence'))),
                  ]),
                ]),
              ),
            ),
          TextButton.icon(onPressed: () => setState(() => _lines.add(_ReqLine())), icon: const Icon(Icons.add), label: const Text('Ajouter un produit')),
          OutlinedButton(
            onPressed: () async {
              final d = await showDatePicker(context: context, initialDate: DateTime.now().add(const Duration(days: 3)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 365)));
              if (d != null) setState(() => _deadline = d);
            },
            child: Text(_deadline == null ? 'Délai souhaité (facultatif)' : 'Délai : ${dOnly(_deadline!.toIso8601String())}'),
          ),
          const SizedBox(height: 8),
          AttachmentPicker(items: _files, onChanged: () => setState(() {})),
          const SizedBox(height: 8),
          TextField(controller: _comments, maxLines: 3, decoration: const InputDecoration(labelText: 'Commentaires', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? '…' : 'Enregistrer et envoyer')),
          const Padding(
            padding: EdgeInsets.only(top: 8),
            child: Text('Si le grossiste n\'a pas de compte, contactez-le par téléphone ou WhatsApp puis saisissez sa réponse dans la demande.', style: TextStyle(fontSize: 12)),
          ),
        ]),
      );
}

class RequestDetailScreen extends StatefulWidget {
  final String requestId;
  final bool admin;
  const RequestDetailScreen({super.key, required this.requestId, required this.admin});
  @override
  State<RequestDetailScreen> createState() => _RequestDetailScreenState();
}

class _RequestDetailScreenState extends State<RequestDetailScreen> {
  late Future<Map<String, dynamic>> _f = _load();
  Future<Map<String, dynamic>> _load() async {
    final r = await sb
        .from('supplier_requests')
        .select('*, suppliers(name), supplier_request_items(*), supplier_responses(*, supplier_response_items(*))')
        .eq('id', widget.requestId)
        .single();
    final ids = (r['supplier_responses'] as List).map((x) => (x as Map)['id']).toList();
    final filter = ['request_id.eq.${widget.requestId}', if (ids.isNotEmpty) 'response_id.in.(${ids.join(',')})'].join(',');
    final att = await sb.from('supplier_attachments').select().or(filter).order('created_at');
    return {...r, 'attachments': att};
  }

  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return Scaffold(appBar: AppBar(), body: errorView(snap.error));
          if (!snap.hasData) return Scaffold(appBar: AppBar(), body: const Center(child: CircularProgressIndicator()));
          final r = snap.data!;
          final items = List<Map<String, dynamic>>.from(r['supplier_request_items'] as List);
          final names = {for (final i in items) i['id'] as String: i['product_name'] as String};
          final resp = List<Map<String, dynamic>>.from(r['supplier_responses'] as List)
            ..sort((a, b) => (b['responded_at'] as String).compareTo(a['responded_at'] as String));
          final open = r['status'] == 'sent' || r['status'] == 'answered';
          final att = List<Map<String, dynamic>>.from(r['attachments'] as List);
          final reqAtt = att.where((a) => a['request_id'] == widget.requestId).toList();
          return Scaffold(
            appBar: AppBar(title: Text((r['title'] as String?) ?? 'Demande'), actions: [
              if (widget.admin && open)
                IconButton(
                  tooltip: 'Annuler la demande',
                  icon: const Icon(Icons.cancel_outlined),
                  onPressed: () => guarded(context, () async {
                    await sb.from('supplier_requests').update({'status': 'cancelled'}).eq('id', widget.requestId);
                    _reload();
                  }),
                ),
            ]),
            body: ListView(padding: const EdgeInsets.all(12), children: [
              Text('${(r['suppliers'] as Map?)?['name'] ?? ''} · ${_reqStatus(r['status'] as String)}'),
              if (r['desired_deadline'] != null) Text('Délai souhaité : ${dOnly(r['desired_deadline'])}'),
              if (r['comments'] != null) Text('${r['comments']}'),
              Section('Produits demandés', [
                for (final i in items)
                  Text('• ${i['product_name']}${i['quantity'] != null ? ' — ${n(i['quantity'])} ${i['unit'] ?? ''}' : ''}${i['reference'] != null ? ' (réf. ${i['reference']})' : ''}'),
              ]),
              if (reqAtt.isNotEmpty) Section('Pièces jointes de la demande', [for (final a in reqAtt) supplierFileButton(context, a)]),
              if (open)
                FilledButton.icon(
                  icon: const Icon(Icons.reply),
                  label: Text(widget.admin ? 'Saisir une réponse (téléphone / WhatsApp)' : 'Répondre à la demande'),
                  onPressed: () async {
                    await Navigator.push(context, MaterialPageRoute(builder: (_) => ResponseFormScreen(request: r, admin: widget.admin)));
                    _reload();
                  },
                ),
              Section('Réponses (historique conservé)', [
                if (resp.isEmpty) const Text('Aucune réponse pour le moment.'),
                for (final x in resp) ...[
                  Text('${dt(x['responded_at'])} · ${x['source'] == 'in_app' ? 'Dans MAYA' : 'Saisie manuelle (${x['channel']})'}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  for (final it in List<Map<String, dynamic>>.from(x['supplier_response_items'] as List))
                    Text('• ${names[it['request_item_id']] ?? ''} : ${_avail(it['availability'] as String)}'
                        '${it['unit_price'] != null ? ' · ${money(it['unit_price'], it['currency'] as String)}' : ''}'
                        '${it['available_qty'] != null ? ' · qté ${n(it['available_qty'])}' : ''}'
                        '${it['conditions'] != null ? ' · ${it['conditions']}' : ''}'),
                  if (x['comments'] != null) Text('${x['comments']}'),
                  for (final a in att.where((a) => a['response_id'] == x['id'])) supplierFileButton(context, a),
                  const Divider(),
                ],
              ]),
            ]),
          );
        },
      );
}

class _RespLine {
  String availability = 'available';
  final price = TextEditingController(), qty = TextEditingController(), unit = TextEditingController(), cond = TextEditingController(), lead = TextEditingController();
}

class ResponseFormScreen extends StatefulWidget {
  final Map<String, dynamic> request;
  final bool admin;
  const ResponseFormScreen({super.key, required this.request, required this.admin});
  @override
  State<ResponseFormScreen> createState() => _ResponseFormScreenState();
}

class _ResponseFormScreenState extends State<ResponseFormScreen> {
  late final List<Map<String, dynamic>> _items = List<Map<String, dynamic>>.from(widget.request['supplier_request_items'] as List);
  late final List<_RespLine> _lines = [for (final _ in _items) _RespLine()];
  String _channel = 'phone';
  final _comments = TextEditingController();
  bool _busy = false;
  final List<PickedAttachment> _files = [];

  Future<void> _save() async {
    setState(() => _busy = true);
    await guarded(context, () async {
      final r = await sb.from('supplier_responses').insert({
        'request_id': widget.request['id'],
        'source': widget.admin ? 'manual' : 'in_app',
        'channel': widget.admin ? _channel : 'in_app',
        'comments': _comments.text.trim().isEmpty ? null : _comments.text.trim(),
      }).select('id').single();
      await sb.from('supplier_response_items').insert([
        for (var i = 0; i < _items.length; i++)
          {
            'response_id': r['id'],
            'request_item_id': _items[i]['id'],
            'availability': _lines[i].availability,
            'unit_price': _lines[i].price.text.trim().isEmpty ? null : n(_lines[i].price.text),
            'available_qty': _lines[i].qty.text.trim().isEmpty ? null : n(_lines[i].qty.text),
            'unit': _lines[i].unit.text.trim().isEmpty ? null : _lines[i].unit.text.trim(),
            'conditions': _lines[i].cond.text.trim().isEmpty ? null : _lines[i].cond.text.trim(),
            'lead_time_days': _lines[i].lead.text.trim().isEmpty ? null : n(_lines[i].lead.text).toInt(),
          }
      ]);
      if (_files.isNotEmpty) {
        try {
          await uploadSupplierAttachments(widget.request['supplier_id'] as String, _files, responseId: r['id'] as String);
        } catch (_) {
          if (mounted) snack(context, 'Réponse enregistrée, mais certaines pièces jointes n\'ont pas pu être envoyées.');
        }
      }
      if (mounted) Navigator.pop(context);
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.admin ? 'Saisir une réponse' : 'Ma réponse')),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          if (widget.admin)
            DropdownButtonFormField<String>(
              value: _channel,
              decoration: const InputDecoration(labelText: 'Canal utilisé', border: OutlineInputBorder()),
              items: const [
                DropdownMenuItem(value: 'phone', child: Text('Appel téléphonique')),
                DropdownMenuItem(value: 'whatsapp', child: Text('WhatsApp')),
                DropdownMenuItem(value: 'other', child: Text('Autre')),
              ],
              onChanged: (v) => setState(() => _channel = v ?? 'phone'),
            ),
          for (var i = 0; i < _items.length; i++)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${_items[i]['product_name']}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  DropdownButtonFormField<String>(
                    value: _lines[i].availability,
                    items: const [
                      DropdownMenuItem(value: 'available', child: Text('Disponible')),
                      DropdownMenuItem(value: 'partial', child: Text('Partiellement disponible')),
                      DropdownMenuItem(value: 'unavailable', child: Text('Indisponible')),
                    ],
                    onChanged: (v) => setState(() => _lines[i].availability = v ?? 'available'),
                  ),
                  Row(children: [
                    Expanded(child: TextField(controller: _lines[i].price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix unitaire'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Qté dispo'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].unit, decoration: const InputDecoration(labelText: 'Unité'))),
                  ]),
                  Row(children: [
                    Expanded(child: TextField(controller: _lines[i].cond, decoration: const InputDecoration(labelText: 'Conditions de vente'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].lead, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Délai (jours)'))),
                  ]),
                ]),
              ),
            ),
          AttachmentPicker(items: _files, onChanged: () => setState(() {})),
          const SizedBox(height: 8),
          TextField(controller: _comments, maxLines: 3, decoration: const InputDecoration(labelText: 'Commentaires', border: OutlineInputBorder())),
          const SizedBox(height: 12),
          FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? '…' : 'Enregistrer la réponse')),
        ]),
      );
}

class ComparisonScreen extends StatefulWidget {
  const ComparisonScreen({super.key});
  @override
  State<ComparisonScreen> createState() => _ComparisonScreenState();
}

class _ComparisonScreenState extends State<ComparisonScreen> {
  bool _old = false;
  String _q = '';
  String? _availFilter;
  DateTime? _since;
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final r = _old
        ? await sb.from('v_supplier_offers').select().order('product_name').order('responded_at', ascending: false)
        : await sb.from('v_best_offers').select().order('product_name').order('unit_price', ascending: true);
    return List<Map<String, dynamic>>.from(r);
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(8, 8, 8, 0),
          child: TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Produit ou grossiste', border: OutlineInputBorder()),
            onChanged: (v) => setState(() => _q = v.toLowerCase()),
          ),
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 8),
          child: Row(children: [
            for (final e in const {'available': 'Disponible', 'partial': 'Partiel', 'unavailable': 'Indisponible'}.entries)
              Padding(
                padding: const EdgeInsets.only(right: 6),
                child: ChoiceChip(
                  label: Text(e.value),
                  selected: _availFilter == e.key,
                  onSelected: (v) => setState(() => _availFilter = v ? e.key : null),
                ),
              ),
            ActionChip(
              avatar: const Icon(Icons.event, size: 16),
              label: Text(_since == null ? 'Depuis le…' : 'Depuis ${dOnly(_since!.toIso8601String())}'),
              onPressed: () async {
                final d = await showDatePicker(context: context, initialDate: _since ?? DateTime.now(), firstDate: DateTime(2024), lastDate: DateTime.now());
                if (d != null) setState(() => _since = d);
              },
            ),
            if (_since != null) IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setState(() => _since = null)),
          ]),
        ),
        SwitchListTile(
          title: const Text('Afficher aussi les anciens prix'),
          value: _old,
          onChanged: (v) => setState(() {
            _old = v;
            _f = _load();
          }),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return errorView(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!.where((o) {
                if (_availFilter != null && o['availability'] != _availFilter) return false;
                if (_since != null && DateTime.parse('${o['responded_at']}').toLocal().isBefore(_since!)) return false;
                return '${o['product_name']} ${o['supplier_name']}'.toLowerCase().contains(_q);
              }).toList();
              if (list.isEmpty) return const Center(child: Text('Pas d\'offres à afficher.'));
              return RefreshIndicator(
                onRefresh: () async => setState(() => _f = _load()),
                child: ListView(children: [
                  for (final o in list)
                    ListTile(
                      title: Text('${o['product_name']} — ${o['unit_price'] == null ? 'prix non indiqué' : money(o['unit_price'], o['currency'] as String)}'),
                      subtitle: Text('${o['supplier_name']} · ${_avail(o['availability'] as String)} · ${dOnly(o['responded_at'])}'
                          '${o['available_qty'] != null ? ' · qté ${n(o['available_qty'])} ${o['unit'] ?? ''}' : ''}'
                          '${o['conditions'] != null ? '\n${o['conditions']}' : ''}'),
                      isThreeLine: o['conditions'] != null,
                      trailing: (o['is_outdated'] == true || o['is_latest_for_supplier'] == false)
                          ? const Chip(label: Text('ANCIEN PRIX'))
                          : (o['is_best_offer'] == true ? const Chip(label: Text('MEILLEUR PRIX'), backgroundColor: Color(0xFFC8E6C9)) : null),
                    ),
                ]),
              );
            },
          ),
        ),
      ]);
}
