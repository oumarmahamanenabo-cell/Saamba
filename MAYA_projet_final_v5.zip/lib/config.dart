const supabaseUrl = 'https://juaidyvcngqizxvnsxke.supabase.co';
const supabaseKey = 'sb_publishable_0hMHJrEkJ5uZyip61AvbYg_s9ZzMTrO';
