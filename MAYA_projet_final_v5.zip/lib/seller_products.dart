import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'common.dart';

const _prodLabels = {'pending': 'EN ATTENTE DE VALIDATION', 'approved': 'PUBLIÉ', 'hidden': 'SUSPENDU / MASQUÉ'};

Color _prodColor(String s) => s == 'approved' ? maliGreen : (s == 'pending' ? gold : Colors.blueGrey);

/// URL publique de la photo d'un produit (ou null).
String? productImageUrl(Map<String, dynamic> p) {
  final path = p['image_path'] as String?;
  if (path == null || path.isEmpty) return null;
  return sb.storage.from('product-images').getPublicUrl(path);
}

// ======== Espace vendeur : mes produits ========
class SellerProductsScreen extends StatefulWidget {
  const SellerProductsScreen({super.key});
  @override
  State<SellerProductsScreen> createState() => _SellerProductsScreenState();
}

class _SellerProductsScreenState extends State<SellerProductsScreen> {
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() => sb.from('products').select().eq('created_by', uid).order('created_at', ascending: false);
  void _reload() => setState(() => _f = _load());

  Future<void> _edit([Map<String, dynamic>? p]) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => ProductForm(product: p)));
    _reload();
  }

  Future<void> _toggle(Map<String, dynamic> p) => guarded(context, () async {
        // « Réactiver » repasse par le contrôle : validation admin sauf vendeur de confiance
        await sb.from('products').update({'status': p['status'] == 'hidden' ? 'pending' : 'hidden'}).eq('id', p['id']);
        _reload();
      });

  Future<void> _delete(Map<String, dynamic> p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Supprimer ce produit ?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Supprimer')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('products').delete().eq('id', p['id']);
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Produit')),
        body: FutureBuilder<List<dynamic>>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final list = List<Map<String, dynamic>>.from(snap.data!);
            if (list.isEmpty) return const Center(child: Text('Aucun produit. Ajoutez le premier.'));
            return RefreshIndicator(
              onRefresh: () async => _reload(),
              child: ListView.separated(
                padding: const EdgeInsets.only(bottom: 80),
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final p = list[i];
                  final st = '${p['status']}';
                  return ListTile(
                    leading: _thumb(p),
                    title: Text('${p['name']}'),
                    subtitle: Text('${money(p['promo_price'] ?? p['price'])} · stock ${n(p['stock'])} ${p['unit']}\n${_prodLabels[st] ?? st}',
                        style: TextStyle(color: _prodColor(st))),
                    isThreeLine: true,
                    onTap: () => _edit(p),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) => v == 'toggle' ? _toggle(p) : _delete(p),
                      itemBuilder: (_) => [
                        PopupMenuItem(value: 'toggle', child: Text(st == 'hidden' ? 'Remettre en vente' : 'Suspendre')),
                        const PopupMenuItem(value: 'delete', child: Text('Supprimer')),
                      ],
                    ),
                  );
                },
              ),
            );
          },
        ),
      );
}

Widget _thumb(Map<String, dynamic> p) {
  final url = productImageUrl(p);
  return ClipRRect(
    borderRadius: BorderRadius.circular(10),
    child: SizedBox(
      width: 52,
      height: 52,
      child: url == null ? const ColoredBox(color: Color(0xFFEFF3EE), child: Icon(Icons.image_outlined)) : Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)),
    ),
  );
}

class ProductForm extends StatefulWidget {
  final Map<String, dynamic>? product;
  const ProductForm({super.key, this.product});
  @override
  State<ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<ProductForm> {
  late final _name = TextEditingController(text: '${widget.product?['name'] ?? ''}');
  late final _desc = TextEditingController(text: '${widget.product?['description'] ?? ''}');
  late final _price = TextEditingController(text: widget.product == null ? '' : '${n(widget.product!['price'])}');
  late final _promo = TextEditingController(text: widget.product?['promo_price'] == null ? '' : '${n(widget.product!['promo_price'])}');
  late final _stock = TextEditingController(text: widget.product == null ? '' : '${n(widget.product!['stock'])}');
  late final _unit = TextEditingController(text: '${widget.product?['unit'] ?? 'pièce'}');
  String? _cat;
  List<Map<String, dynamic>> _cats = [];
  File? _photo;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _cat = widget.product?['category_id'] as String?;
    sb.from('categories').select('id, name').eq('active', true).order('position').then((r) {
      if (mounted) setState(() => _cats = List<Map<String, dynamic>>.from(r));
    });
  }

  Future<void> _pick() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 1280);
    if (x != null) setState(() => _photo = File(x.path));
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty || n(_price.text) <= 0) return snack(context, 'Nom et prix (FCFA) obligatoires.');
    if (_promo.text.trim().isNotEmpty && n(_promo.text) >= n(_price.text)) return snack(context, 'Le prix promo doit être inférieur au prix.');
    setState(() => _busy = true);
    await guarded(context, () async {
      String? path = widget.product?['image_path'] as String?;
      if (_photo != null) {
        path = '$uid/${DateTime.now().microsecondsSinceEpoch}.jpg';
        await sb.storage.from('product-images').upload(path, _photo!, fileOptions: const FileOptions(contentType: 'image/jpeg'));
      }
      final data = {
        'name': _name.text.trim(),
        'description': _desc.text.trim().isEmpty ? null : _desc.text.trim(),
        'price': n(_price.text),
        'promo_price': _promo.text.trim().isEmpty ? null : n(_promo.text),
        'stock': n(_stock.text),
        'unit': _unit.text.trim().isEmpty ? 'pièce' : _unit.text.trim(),
        'category_id': _cat,
        'image_path': path,
        'status': 'pending', // le serveur décide : publié directement seulement pour un vendeur de confiance
      };
      if (widget.product == null) {
        await sb.from('products').insert({...data, 'created_by': uid});
      } else {
        await sb.from('products').update(data).eq('id', widget.product!['id']);
      }
      if (!mounted) return;
      snack(context, 'Produit enregistré. Il sera publié après validation par l\'administration.');
      Navigator.pop(context);
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.product == null ? 'Nouveau produit' : 'Modifier le produit')),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          InkWell(
            onTap: _pick,
            child: Container(
              height: 150,
              decoration: softBox(),
              child: _photo != null
                  ? Image.file(_photo!, fit: BoxFit.cover)
                  : (productImageUrl(widget.product ?? {}) != null
                      ? Image.network(productImageUrl(widget.product!)!, fit: BoxFit.cover)
                      : const Center(child: Column(mainAxisSize: MainAxisSize.min, children: [Icon(Icons.add_a_photo_outlined, size: 36), Text('Ajouter une photo')]))),
            ),
          ),
          const SizedBox(height: 10),
          TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nom du produit', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: _cats.any((c) => c['id'] == _cat) ? _cat : null,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Catégorie', border: OutlineInputBorder()),
            items: [for (final c in _cats) DropdownMenuItem(value: c['id'] as String, child: Text('${c['name']}'))],
            onChanged: (v) => setState(() => _cat = v),
          ),
          const SizedBox(height: 10),
          TextField(controller: _desc, maxLines: 3, decoration: const InputDecoration(labelText: 'Description', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(controller: _price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix (FCFA)', border: OutlineInputBorder()))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: _promo, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix promo', border: OutlineInputBorder()))),
          ]),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: TextField(controller: _stock, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Quantité disponible', border: OutlineInputBorder()))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: _unit, decoration: const InputDecoration(labelText: 'Unité (pièce, sac, kg…)', border: OutlineInputBorder()))),
          ]),
          const SizedBox(height: 16),
          FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? '…' : 'Enregistrer')),
        ]),
      );
}

// ======== Administration : validation des produits ========
class AdminProductsScreen extends StatefulWidget {
  const AdminProductsScreen({super.key});
  @override
  State<AdminProductsScreen> createState() => _AdminProductsScreenState();
}

class _AdminProductsScreenState extends State<AdminProductsScreen> {
  String _filter = 'pending';
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() => sb
      .from('products')
      .select('*, profiles!products_created_by_fkey(full_name, phone)')
      .eq('status', _filter)
      .order('created_at', ascending: false)
      .limit(100);

  Future<void> _set(Map<String, dynamic> p, String status) => guarded(context, () async {
        await sb.from('products').update({'status': status}).eq('id', p['id']);
        if (mounted) setState(() => _f = _load());
      });

  @override
  Widget build(BuildContext context) => Column(children: [
        SizedBox(
          height: 48,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 8), children: [
            for (final s in ['pending', 'approved', 'hidden'])
              Padding(
                padding: const EdgeInsets.only(right: 6, top: 6, bottom: 6),
                child: ChoiceChip(
                  label: Text(_prodLabels[s]!, style: const TextStyle(fontSize: 11)),
                  selected: _filter == s,
                  onSelected: (_) => setState(() {
                    _filter = s;
                    _f = _load();
                  }),
                ),
              ),
          ]),
        ),
        Expanded(
          child: FutureBuilder<List<dynamic>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return errorView(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = List<Map<String, dynamic>>.from(snap.data!);
              if (list.isEmpty) return const Center(child: Text('Aucun produit dans cette catégorie.'));
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final p = list[i];
                  final who = p['profiles'] as Map?;
                  return ListTile(
                    leading: _thumb(p),
                    title: Text('${p['name']} · ${money(p['promo_price'] ?? p['price'])}'),
                    subtitle: Text('${who?['full_name'] ?? who?['phone'] ?? 'MAYA'} · stock ${n(p['stock'])}'),
                    trailing: Wrap(children: [
                      if (_filter != 'approved') IconButton(tooltip: 'Approuver', icon: const Icon(Icons.check_circle, color: maliGreen), onPressed: () => _set(p, 'approved')),
                      if (_filter != 'hidden') IconButton(tooltip: 'Masquer / refuser', icon: const Icon(Icons.visibility_off, color: maliRed), onPressed: () => _set(p, 'hidden')),
                    ]),
                  );
                },
              );
            },
          ),
        ),
      ]);
}
