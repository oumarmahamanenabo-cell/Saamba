import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'admin.dart';
import 'chat.dart';
import 'client.dart';
import 'common.dart';
import 'config.dart';
import 'orders.dart';
import 'shop.dart';
import 'wallet.dart';
import 'suppliers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
  runApp(const SaambaApp());
}

class SaambaApp extends StatelessWidget {
  const SaambaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'MAYA',
        debugShowCheckedModeBanner: false,
        theme: saambaTheme(),
        home: const Gate(),
      );
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Future<Map<String, dynamic>?>? _profile;
  StreamSubscription<AuthState>? _sub;
  bool _splash = true;

  @override
  void initState() {
    super.initState();
    _load();
    _sub = sb.auth.onAuthStateChange.listen((_) => _refresh());
    roleRefresh.addListener(_refresh);
    Future.delayed(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    roleRefresh.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(_load);
  }

  void _load() {
    _profile = sb.auth.currentUser == null
        ? Future<Map<String, dynamic>?>.value(null)
        : sb.from('profiles').select().eq('id', uid).maybeSingle();
  }

  @override
  Widget build(BuildContext context) {
    if (_splash) return const SplashView();
    if (sb.auth.currentUser == null) return const AuthScreen();
    return FutureBuilder<Map<String, dynamic>?>(
      future: _profile,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const SplashView();
        final p = snap.data;
        if (p == null || p['active'] != true) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const SaambaLogo(size: 120),
                  const SizedBox(height: 16),
                  const Text('Compte indisponible ou désactivé.', textAlign: TextAlign.center),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('Se déconnecter')),
                ]),
              ),
            ),
          );
        }
        switch (p['role']) {
          case 'admin':
            return const AdminShell();
          case 'supplier':
            return const SupplierShell();
          case 'seller':
            return const SellerShell();
          default:
            return const ClientShell();
        }
      },
    );
  }
}

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool _register = false, _busy = false;
  final _name = TextEditingController(), _phone = TextEditingController(text: '+223 '), _pass = TextEditingController();

  // Numéro malien normalisé : 223 + 8 chiffres (accepte « +223 70 00 00 00 » ou « 70 00 00 00 »)
  String get _digits {
    var d = _phone.text.replaceAll(RegExp(r'\D'), '');
    if (d.length == 8) d = '223$d';
    return d;
  }

  bool get _phoneOk => RegExp(r'^223\d{8}$').hasMatch(_digits);

  String get _email => '$_digits@saamba.app';

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_phoneOk || _pass.text.length < 6) {
      snack(context, 'Numéro malien (+223 suivi de 8 chiffres) et mot de passe de 6 caractères minimum.');
      return;
    }
    setState(() => _busy = true);
    await guarded(context, () async {
      if (_register) {
        await sb.auth.signUp(
            email: _email,
            password: _pass.text,
            data: {'full_name': _name.text.trim(), 'phone': '+$_digits'});
      } else {
        await sb.auth.signInWithPassword(email: _email, password: _pass.text);
      }
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Column(children: [
                const MayaFullLogo(width: 290),
                const SizedBox(height: 8),
                const AnimatedSlogan(text: 'Le commerce, plus proche de vous !', fontSize: 13),
                const SizedBox(height: 24),
                if (_register) ...[
                  TextField(controller: _name, decoration: const InputDecoration(labelText: 'Nom complet', border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                ],
                TextField(
                    controller: _phone,
                    keyboardType: TextInputType.phone,
                    decoration: const InputDecoration(labelText: 'Numéro de téléphone (+223…)', border: OutlineInputBorder())),
                const SizedBox(height: 12),
                TextField(
                    controller: _pass,
                    obscureText: true,
                    decoration: const InputDecoration(labelText: 'Mot de passe', border: OutlineInputBorder())),
                const SizedBox(height: 20),
                SizedBox(
                    width: double.infinity,
                    child: FilledButton(
                        onPressed: _busy ? null : _submit,
                        child: Text(_busy ? '…' : (_register ? 'Créer mon compte' : 'Se connecter')))),
                TextButton(
                    onPressed: () => setState(() => _register = !_register),
                    child: Text(_register ? 'J\'ai déjà un compte' : 'Créer un compte client')),
              ]),
            ),
          ),
        ),
      );
}

class ClientShell extends StatefulWidget {
  const ClientShell({super.key});
  @override
  State<ClientShell> createState() => _ClientShellState();
}

class _ClientShellState extends State<ClientShell> {
  int _i = 0;

  void _chat() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Messages avec MAYA')), body: const _ClientChat())));
  void _invoices() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Mes factures')), body: const InvoicesScreen())));

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      ShopHome(onGo: (v) => setState(() => _i = v), onContact: _chat),
      const CategoriesScreen(),
      const FavoritesScreen(),
      const OrdersScreen(admin: false),
      AccountHub(onMessages: _chat, onInvoices: _invoices, profile: const ProfileScreen()),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const SaambaTitle(),
        bottom: const MaliStripe(),
        actions: const [NotifBell()],
      ),
      body: pages[_i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Accueil'),
          NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'Catégories'),
          NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'Favoris'),
          NavigationDestination(icon: Icon(Icons.assignment_outlined), selectedIcon: Icon(Icons.assignment), label: 'Commandes'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Mon compte'),
        ],
      ),
    );
  }
}

class _ClientChat extends StatelessWidget {
  const _ClientChat();
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: sb.from('conversations').select('id').eq('client_id', uid).single(),
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          return ChatScreen(conversationId: snap.data!['id'] as String, title: 'MAYA', embedded: true);
        },
      );
}
