#!/usr/bin/env python3
"""Adapte le dossier android/ généré par `flutter create` pour SAAMBA :
permissions, requêtes tel/https, nom de l'application, minSdk 23."""
import pathlib
import re
import sys

root = pathlib.Path(sys.argv[1] if len(sys.argv) > 1 else '.')
manifest = root / 'android/app/src/main/AndroidManifest.xml'
m = manifest.read_text(encoding='utf-8')

PERMS = [
    '<uses-permission android:name="android.permission.INTERNET"/>',
    '<uses-permission android:name="android.permission.RECORD_AUDIO"/>',
    '<uses-permission android:name="android.permission.CAMERA"/>',
    '<uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>',
    '<uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>',
    '<uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>',
    '<uses-feature android:name="android.hardware.camera" android:required="false"/>',
    '<uses-feature android:name="android.hardware.microphone" android:required="false"/>',
]
missing = [p for p in PERMS if p.split('"')[1] not in m]
if missing:
    block = ''.join('    ' + p + '\n' for p in missing)
    assert '<application' in m, 'balise <application> introuvable'
    m = m.replace('<application', block + '    <application', 1)

QUERIES = [
    '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>',
    '<intent><action android:name="android.intent.action.VIEW"/><data android:scheme="tel"/></intent>',
    '<intent><action android:name="android.intent.action.DIAL"/><data android:scheme="tel"/></intent>',
]
if 'android:scheme="tel"' not in m:
    inner = ''.join('        ' + q + '\n' for q in QUERIES)
    if '</queries>' in m:
        m = m.replace('</queries>', inner + '    </queries>', 1)
    else:
        m = m.replace('</manifest>', '    <queries>\n' + inner + '    </queries>\n</manifest>', 1)

m, k = re.subn(r'android:label="[^"]*"', 'android:label="SAAMBA"', m, count=1)
assert k == 1, 'android:label introuvable'
manifest.write_text(m, encoding='utf-8')

# minSdk 23 (record, audioplayers, printing)
done = False
for name in ('build.gradle.kts', 'build.gradle'):
    g = root / 'android/app' / name
    if not g.exists():
        continue
    t = g.read_text(encoding='utf-8')
    t2 = re.sub(r'minSdk(Version)?(\s*=\s*|\s+)flutter\.minSdkVersion', lambda mo: 'minSdk' + ('Version' if mo.group(1) else '') + mo.group(2) + '23', t)
    t2 = re.sub(r'minSdk(Version)?(\s*=\s*|\s+)(\d+)', lambda mo: 'minSdk' + ('Version' if mo.group(1) else '') + mo.group(2) + '23' if int(mo.group(3)) < 23 else mo.group(0), t2)
    assert re.search(r'minSdk(Version)?\s*=?\s*(23|2[4-9]|3\d)\b', t2), 'minSdk non défini dans ' + name
    g.write_text(t2, encoding='utf-8')
    done = True
    break
assert done, 'build.gradle(.kts) introuvable'
print('Android patché : permissions, queries, nom SAAMBA, minSdk 23')
