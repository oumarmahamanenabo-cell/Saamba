-- Expédition renseignée par le vendeur : transporteur, contacts, lieu et date d'arrivée.
-- Additif et idempotent. Prérequis : migrations précédentes (orders, order_items, carriers, notify_user, notify_admins, is_admin).

alter table public.profiles add column if not exists city text;

create table if not exists public.seller_shipments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  seller_id uuid not null references public.profiles(id),
  seller_name text,
  seller_phone text not null,
  carrier_id uuid references public.carriers(id),
  carrier_name text not null,
  carrier_phone text not null,
  carrier_verified boolean not null default false,
  arrival_place text not null,
  expected_arrival_date date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (order_id, seller_id)
);

alter table public.seller_shipments enable row level security;
drop policy if exists seller_shipments_read on public.seller_shipments;
create policy seller_shipments_read on public.seller_shipments for select using (
  seller_id = auth.uid()
  or public.is_admin()
  or exists (select 1 from public.orders o where o.id = order_id and o.client_id = auth.uid())
);
-- aucune politique d'écriture : tout passe par seller_save_shipping()

-- Transporteurs vérifiés proposés au vendeur
create or replace function public.list_verified_carriers()
returns table(id uuid, name text, phone text, city text, zones text)
language sql stable security definer set search_path = public as $$
  select c.id, coalesce(nullif(c.company_name, ''), c.owner_name), c.phone, c.city, c.zones
  from public.carriers c
  where c.verification_status = 'verified'
    and exists (select 1 from public.profiles p where p.id = auth.uid() and p.role in ('seller', 'admin') and p.active = true)
  order by 2;
$$;

-- Commandes payées qui contiennent des produits du vendeur connecté
create or replace function public.seller_my_orders() returns jsonb
language plpgsql stable security definer set search_path = public as $$
begin
  if not exists (select 1 from public.profiles where id = auth.uid() and role = 'seller' and active = true) then
    raise exception 'Réservé aux vendeurs';
  end if;
  return coalesce((
    select jsonb_agg(t.x order by t.created desc)
    from (
      select o.created_at as created,
             jsonb_build_object(
               'order_id', o.id,
               'number', o.number,
               'status', o.status,
               'created_at', o.created_at,
               'client_name', cp.full_name,
               'client_phone', cp.phone,
               'client_city', cp.city,
               'items', (select coalesce(jsonb_agg(jsonb_build_object('name', i.name, 'quantity', i.quantity, 'unit', i.unit)), '[]'::jsonb)
                         from public.order_items i where i.order_id = o.id and i.seller_id = auth.uid()),
               'shipment', (select to_jsonb(s) from public.seller_shipments s where s.order_id = o.id and s.seller_id = auth.uid())
             ) as x
      from public.orders o
      join public.profiles cp on cp.id = o.client_id
      where o.status in ('paid','preparing','ready_to_ship','handed_to_carrier','in_transit','arrived','reception_pending','received','not_received_to_verify')
        and exists (select 1 from public.order_items i where i.order_id = o.id and i.seller_id = auth.uid())
    ) t
  ), '[]'::jsonb);
end $$;

-- Le vendeur enregistre ou modifie son expédition
create or replace function public.seller_save_shipping(
  p_order uuid,
  p_carrier_id uuid,
  p_carrier_name text,
  p_carrier_phone text,
  p_seller_phone text,
  p_arrival_place text,
  p_arrival_date date,
  p_notes text
) returns void
language plpgsql security definer set search_path = public as $$
declare
  o record;
  c record;
  v_sname text;
  v_name text := trim(coalesce(p_carrier_name, ''));
  v_phone text := trim(coalesce(p_carrier_phone, ''));
  v_ok boolean := false;
  v_sphone text := regexp_replace(coalesce(p_seller_phone, ''), '\D', '', 'g');
begin
  select full_name into v_sname from public.profiles where id = auth.uid() and role = 'seller' and active = true;
  if not found then raise exception 'Réservé aux vendeurs'; end if;

  select * into o from public.orders where id = p_order;
  if not found or not exists (select 1 from public.order_items where order_id = p_order and seller_id = auth.uid()) then
    raise exception 'Commande introuvable pour ce vendeur';
  end if;
  if o.status not in ('paid','preparing','ready_to_ship','handed_to_carrier','in_transit','arrived','reception_pending') then
    raise exception 'Cette commande ne peut plus être modifiée (statut : %)', o.status;
  end if;

  if p_carrier_id is not null then
    select * into c from public.carriers where id = p_carrier_id and verification_status = 'verified';
    if not found then raise exception 'Transporteur non vérifié'; end if;
    v_ok := true;
    if v_name = '' then v_name := coalesce(nullif(c.company_name, ''), c.owner_name); end if;
    if v_phone = '' then v_phone := coalesce(c.phone, ''); end if;
  end if;

  if v_name = '' then raise exception 'Le nom du transporteur est obligatoire'; end if;
  if length(regexp_replace(v_phone, '\D', '', 'g')) < 8 then raise exception 'Le téléphone du transporteur est obligatoire'; end if;
  if v_sphone !~ '^(223)?\d{8}$' then raise exception 'Votre numéro de contact malien est obligatoire (+223 et 8 chiffres)'; end if;
  if length(trim(coalesce(p_arrival_place, ''))) < 2 then raise exception 'Le lieu d''arrivée du colis est obligatoire'; end if;
  if length(v_sphone) = 8 then v_sphone := '223' || v_sphone; end if;

  insert into public.seller_shipments(order_id, seller_id, seller_name, seller_phone, carrier_id, carrier_name, carrier_phone,
                                      carrier_verified, arrival_place, expected_arrival_date, notes)
  values (p_order, auth.uid(), v_sname, '+' || v_sphone, p_carrier_id, v_name, v_phone, v_ok,
          trim(p_arrival_place), p_arrival_date, nullif(trim(coalesce(p_notes, '')), ''))
  on conflict (order_id, seller_id) do update set
    seller_name = excluded.seller_name,
    seller_phone = excluded.seller_phone,
    carrier_id = excluded.carrier_id,
    carrier_name = excluded.carrier_name,
    carrier_phone = excluded.carrier_phone,
    carrier_verified = excluded.carrier_verified,
    arrival_place = excluded.arrival_place,
    expected_arrival_date = excluded.expected_arrival_date,
    notes = excluded.notes,
    updated_at = now();

  perform public.notify_user(o.client_id, 'delivery', 'Livraison de votre commande ' || o.number,
    'Le vendeur a indiqué le transporteur, son contact et le lieu d''arrivée de votre colis.',
    jsonb_build_object('order_id', p_order));
  perform public.notify_admins('delivery', 'Expédition renseignée',
    'Le vendeur a renseigné l''expédition de la commande ' || o.number
      || case when v_ok then '.' else ' avec un transporteur NON vérifié : à contrôler.' end,
    jsonb_build_object('order_id', p_order));
end $$;

revoke all on function public.list_verified_carriers() from public, anon;
revoke all on function public.seller_my_orders() from public, anon;
revoke all on function public.seller_save_shipping(uuid, uuid, text, text, text, text, date, text) from public, anon;
grant execute on function public.list_verified_carriers() to authenticated;
grant execute on function public.seller_my_orders() to authenticated;
grant execute on function public.seller_save_shipping(uuid, uuid, text, text, text, text, date, text) to authenticated;
