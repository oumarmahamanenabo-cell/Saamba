import 'package:flutter/material.dart';
import 'common.dart';
import 'orders.dart';
import 'seller_products.dart';
import 'shop.dart' show NotifBell;

// ======== Espace vendeur : portefeuille avec séquestre ========
class SellerShell extends StatefulWidget {
  const SellerShell({super.key});
  @override
  State<SellerShell> createState() => _SellerShellState();
}

class _SellerShellState extends State<SellerShell> {
  int _i = 0;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const SaambaTitle(suffix: 'Vendeur'), bottom: const MaliStripe(), actions: const [NotifBell()]),
        body: [const WalletScreen(), const SellerProductsScreen(), const ProfileScreen()][_i],
        bottomNavigationBar: NavigationBar(
          selectedIndex: _i,
          onDestinationSelected: (v) => setState(() => _i = v),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.account_balance_wallet_outlined), label: 'Portefeuille'),
            NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Produits'),
            NavigationDestination(icon: Icon(Icons.person_outline), label: 'Compte'),
          ],
        ),
      );
}

const _ledgerLabels = {
  'held': 'BLOQUÉ – en attente de réception par le client',
  'available': 'DISPONIBLE',
  'refunded': 'ANNULÉ (remboursement client)',
};
const _wdLabels = {'requested': 'EN ATTENTE', 'paid': 'PAYÉ', 'rejected': 'REFUSÉ'};

class WalletScreen extends StatefulWidget {
  const WalletScreen({super.key});
  @override
  State<WalletScreen> createState() => _WalletScreenState();
}

class _WalletScreenState extends State<WalletScreen> {
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() => Future.wait([
        sb.rpc('my_wallet'),
        sb.from('seller_ledger').select().eq('seller_id', uid).order('created_at', ascending: false).limit(100),
        sb.from('seller_withdrawals').select().eq('seller_id', uid).order('created_at', ascending: false).limit(50),
      ]);
  void _reload() => setState(() => _f = _load());

  Future<void> _withdraw(num max) async {
    final amount = TextEditingController(), phone = TextEditingController();
    String method = 'Orange Money';
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => AlertDialog(
          title: const Text('Demander un retrait'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Text('Retirable : ${money(max)}'),
              TextField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Montant (FCFA)')),
              DropdownButtonFormField<String>(
                value: method,
                items: const [for (final m in ['Orange Money', 'Moov Money', 'Wave']) DropdownMenuItem(value: m, child: Text(m))],
                onChanged: (v) => set(() => method = v ?? method),
                decoration: const InputDecoration(labelText: 'Recevoir sur'),
              ),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Numéro de réception')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Envoyer')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('request_withdrawal', params: {'p_amount': n(amount.text), 'p_method': method, 'p_phone': phone.text.trim()});
      if (mounted) snack(context, 'Demande envoyée. L\'administration vous paiera après vérification.');
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final w = Map<String, dynamic>.from(snap.data![0] as Map);
          final ledger = List<Map<String, dynamic>>.from(snap.data![1] as List);
          final wds = List<Map<String, dynamic>>.from(snap.data![2] as List);
          Widget card(String label, dynamic v, Color c) => Expanded(
                child: Container(
                  margin: const EdgeInsets.all(4),
                  padding: const EdgeInsets.all(10),
                  decoration: softBox(),
                  child: Column(children: [
                    Text(money(v), style: TextStyle(fontWeight: FontWeight.w800, color: c, fontSize: 15)),
                    const SizedBox(height: 2),
                    Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11)),
                  ]),
                ),
              );
          final withdrawable = n(w['withdrawable']);
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              Row(children: [
                card('Retirable', w['withdrawable'], maliGreen),
                card('Bloqué (réception client)', w['held'], gold),
              ]),
              Row(children: [
                card('Retrait en cours', w['pending_withdrawals'], Colors.blueGrey),
                card('Déjà retiré', w['paid_out'], brandDark),
              ]),
              const SizedBox(height: 6),
              FilledButton.icon(
                  onPressed: withdrawable > 0 ? () => _withdraw(withdrawable) : null,
                  icon: const Icon(Icons.payments),
                  label: const Text('Demander un retrait')),
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 8),
                child: Text(
                    'L\'argent d\'une vente est retirable seulement après que le client a confirmé « Colis reçu ». '
                    'En cas de litige, l\'administration examine le dossier.',
                    style: TextStyle(fontSize: 12)),
              ),
              Section('Mes ventes', [
                if (ledger.isEmpty) const Text('Aucune vente payée pour le moment.'),
                for (final l in ledger)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text('${l['order_number']} · ${money(l['amount'])}'),
                    subtitle: Text('${dt(l['created_at'])}\n${_ledgerLabels[l['status']] ?? l['status']}'),
                    isThreeLine: true,
                    leading: Icon(l['status'] == 'available' ? Icons.lock_open : (l['status'] == 'held' ? Icons.lock_clock : Icons.undo),
                        color: l['status'] == 'available' ? maliGreen : (l['status'] == 'held' ? gold : maliRed)),
                  ),
              ]),
              Section('Mes retraits', [
                if (wds.isEmpty) const Text('Aucun retrait.'),
                for (final x in wds)
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    dense: true,
                    title: Text('${money(x['amount'])} · ${x['method'] ?? ''}'),
                    subtitle: Text('${dt(x['created_at'])} · ${_wdLabels[x['status']] ?? x['status']}${x['note'] != null ? '\n${x['note']}' : ''}'),
                  ),
              ]),
            ]),
          );
        },
      );
}

// ======== Administration : retraits et vendeurs ========
class AdminSellersScreen extends StatelessWidget {
  const AdminSellersScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Vendeurs et retraits')),
        body: const DefaultTabController(
          length: 3,
          child: Column(children: [
            TabBar(tabs: [Tab(text: 'Retraits'), Tab(text: 'Produits'), Tab(text: 'Vendeurs')]),
            Expanded(child: TabBarView(children: [_AdminWithdrawals(), AdminProductsScreen(), _AdminSellers()])),
          ]),
        ),
      );
}

class _AdminWithdrawals extends StatefulWidget {
  const _AdminWithdrawals();
  @override
  State<_AdminWithdrawals> createState() => _AdminWithdrawalsState();
}

class _AdminWithdrawalsState extends State<_AdminWithdrawals> {
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() => sb.from('seller_withdrawals').select('*, profiles!seller_withdrawals_seller_id_fkey(full_name, phone)').order('created_at', ascending: false).limit(100);

  Future<void> _process(Map<String, dynamic> x, bool paid) async {
    final note = await askText(context, paid ? 'Référence du paiement effectué (facultatif)' : 'Motif du refus');
    if (note == null || (!paid && note.isEmpty) || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('admin_process_withdrawal', params: {'p_id': x['id'], 'p_paid': paid, 'p_note': note.isEmpty ? null : note});
      if (mounted) setState(() => _f = _load());
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = List<Map<String, dynamic>>.from(snap.data!);
          if (list.isEmpty) return const Center(child: Text('Aucune demande de retrait.'));
          return ListView.separated(
            itemCount: list.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (_, i) {
              final x = list[i];
              final p = x['profiles'] as Map?;
              return ListTile(
                title: Text('${money(x['amount'])} · ${p?['full_name'] ?? p?['phone'] ?? 'Vendeur'}'),
                subtitle: Text('${dt(x['created_at'])} · ${x['method'] ?? ''} ${x['phone'] ?? ''}\n${_wdLabels[x['status']] ?? x['status']}'),
                isThreeLine: true,
                trailing: x['status'] == 'requested'
                    ? Wrap(children: [
                        IconButton(tooltip: 'Marquer payé', icon: const Icon(Icons.check_circle, color: maliGreen), onPressed: () => _process(x, true)),
                        IconButton(tooltip: 'Refuser', icon: const Icon(Icons.cancel, color: maliRed), onPressed: () => _process(x, false)),
                      ])
                    : null,
              );
            },
          );
        },
      );
}

class _AdminSellers extends StatefulWidget {
  const _AdminSellers();
  @override
  State<_AdminSellers> createState() => _AdminSellersState();
}

class _AdminSellersState extends State<_AdminSellers> {
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() => sb.from('profiles').select('id, full_name, phone, auto_publish').eq('role', 'seller').order('full_name');

  Future<void> _add() async {
    final clients = List<Map<String, dynamic>>.from(await sb.from('profiles').select('id, full_name, phone').eq('role', 'client').order('full_name'));
    if (!mounted) return;
    final pick = await showDialog<String>(
      context: context,
      builder: (ctx) => SimpleDialog(title: const Text('Nommer un vendeur (parmi les clients)'), children: [
        if (clients.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucun client disponible.')),
        for (final c in clients)
          SimpleDialogOption(onPressed: () => Navigator.pop(ctx, c['id'] as String), child: Text('${c['full_name'] ?? ''} ${c['phone'] ?? ''}')),
      ]),
    );
    if (pick == null || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('admin_make_seller', params: {'p_user': pick});
      if (mounted) setState(() => _f = _load());
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.person_add), label: const Text('Vendeur')),
        body: FutureBuilder<List<dynamic>>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final list = List<Map<String, dynamic>>.from(snap.data!);
            if (list.isEmpty) return const Center(child: Text('Aucun vendeur. Nommez-en un.'));
            return ListView(children: [
              for (final s in list)
                SwitchListTile(
                  secondary: const CircleAvatar(child: Icon(Icons.storefront)),
                  title: Text('${s['full_name'] ?? ''}'),
                  subtitle: Text('${s['phone'] ?? ''}\nPublication automatique (vendeur de confiance)'),
                  isThreeLine: true,
                  value: s['auto_publish'] == true,
                  onChanged: (v) => guarded(context, () async {
                    await sb.rpc('admin_set_auto_publish', params: {'p_user': s['id'], 'p_value': v});
                    if (mounted) setState(() => _f = _load());
                  }),
                ),
            ]);
          },
        ),
      );
}
