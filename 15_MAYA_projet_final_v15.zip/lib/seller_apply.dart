import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';
import 'guest.dart';

/// « Devenir vendeur » : compte obligatoire (création ou connexion), puis demande de boutique + documents + validation admin.
Future<void> startSellerFlow(BuildContext context) async {
  final nav = Navigator.of(context);
  final ok = await requireAuth(
    context,
    reason: 'Pour vendre sur MAYA, créez d\'abord votre compte (ou connectez-vous), puis complétez la demande de votre boutique.',
    banner: 'Étape 1 sur 4 : votre compte. Ensuite : informations de la boutique, documents de vérification, validation par MAYA.',
  );
  if (!ok) return;
  await nav.push(MaterialPageRoute(builder: (_) => const SellerApplyScreen()));
}

class _Doc {
  final File file;
  final String name;
  const _Doc(this.file, this.name);
}

const _appStatus = {'pending': 'EN COURS D\'EXAMEN', 'approved': 'ACCEPTÉE', 'rejected': 'REFUSÉE'};
const _docKinds = {'identity': 'Pièce d\'identité', 'business': 'Justificatif de la boutique / activité', 'other': 'Autre document'};

class SellerApplyScreen extends StatefulWidget {
  const SellerApplyScreen({super.key});
  @override
  State<SellerApplyScreen> createState() => _SellerApplyScreenState();
}

class _SellerApplyScreenState extends State<SellerApplyScreen> {
  late Future<Map<String, dynamic>> _f = _load();
  final _shop = TextEditingController(),
      _activity = TextEditingController(),
      _city = TextEditingController(),
      _phone = TextEditingController(),
      _wa = TextEditingController(),
      _address = TextEditingController();
  String? _category;
  final Map<String, _Doc?> _docs = {'identity': null, 'business': null, 'other': null};
  bool _busy = false, _prefilled = false;

  Future<Map<String, dynamic>> _load() async {
    final p = await sb.from('profiles').select('role, full_name, phone, city').eq('id', uid).single();
    final apps = await sb.from('seller_applications').select().eq('user_id', uid).order('created_at', ascending: false).limit(1);
    final cats = await sb.from('categories').select('name').eq('active', true).order('position');
    return {
      'profile': Map<String, dynamic>.from(p),
      'app': (apps as List).isEmpty ? null : Map<String, dynamic>.from(apps.first as Map),
      'cats': [for (final c in cats as List) '${(c as Map)['name']}'],
    };
  }

  @override
  void dispose() {
    for (final c in [_shop, _activity, _city, _phone, _wa, _address]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _pick(String kind) async {
    final src = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.photo), title: const Text('Photo de la galerie'), onTap: () => Navigator.pop(ctx, 'photo')),
          ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Prendre une photo'), onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(leading: const Icon(Icons.description), title: const Text('Fichier PDF / image'), onTap: () => Navigator.pop(ctx, 'doc')),
        ]),
      ),
    );
    if (src == null) return;
    File? file;
    String? name;
    if (src == 'doc') {
      final r = await FilePicker.platform.pickFiles(type: FileType.custom, allowedExtensions: ['jpg', 'jpeg', 'png', 'webp', 'pdf']);
      final f = r?.files.single;
      if (f?.path != null) {
        file = File(f!.path!);
        name = f.name;
      }
    } else {
      final x = await ImagePicker().pickImage(source: src == 'photo' ? ImageSource.gallery : ImageSource.camera, imageQuality: 75, maxWidth: 1800);
      if (x != null) {
        file = File(x.path);
        name = x.name;
      }
    }
    if (file == null || name == null || !mounted) return;
    if (await file.length() > 8 * 1024 * 1024) {
      if (mounted) snack(context, 'Fichier trop lourd (8 Mo maximum).');
      return;
    }
    setState(() => _docs[kind] = _Doc(file!, name!));
  }

  Future<void> _submit() async {
    if (_shop.text.trim().length < 2) {
      snack(context, 'Le nom de la boutique est obligatoire.');
      return;
    }
    if (_activity.text.trim().length < 3) {
      snack(context, 'Décrivez ce que vous vendez.');
      return;
    }
    if (_city.text.trim().length < 2) {
      snack(context, 'La ville est obligatoire.');
      return;
    }
    if (_phone.text.trim().length < 6) {
      snack(context, 'Le numéro de téléphone est obligatoire.');
      return;
    }
    if (_docs['identity'] == null) {
      snack(context, 'La pièce d\'identité est obligatoire.');
      return;
    }
    setState(() => _busy = true);
    await guarded(context, () async {
      final uploaded = <Map<String, String>>[];
      for (final e in _docs.entries) {
        final d = e.value;
        if (d == null) continue;
        final dot = d.name.lastIndexOf('.');
        final ext = dot > 0 ? d.name.substring(dot + 1).toLowerCase() : 'jpg';
        final path = '$uid/${DateTime.now().microsecondsSinceEpoch}_${e.key}.$ext';
        await sb.storage.from('seller-docs').upload(path, d.file, fileOptions: FileOptions(contentType: mimeFor(d.name)));
        uploaded.add({'kind': e.key, 'path': path});
      }
      await sb.rpc('submit_seller_application', params: {
        'p_shop_name': _shop.text.trim(),
        'p_activity': _activity.text.trim(),
        'p_category': _category,
        'p_city': _city.text.trim(),
        'p_phone': _phone.text.trim(),
        'p_whatsapp': _wa.text.trim(),
        'p_address': _address.text.trim(),
        'p_docs': uploaded,
      });
      if (mounted) {
        snack(context, 'Demande envoyée. MAYA l\'examine et vous prévient dès la décision.');
        setState(() => _f = _load());
      }
    });
    if (mounted) setState(() => _busy = false);
  }

  Widget _step(int n, String t, bool done) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          CircleAvatar(radius: 11, backgroundColor: done ? maliGreen : const Color(0xFFDDE7DC), child: done ? const Icon(Icons.check, size: 14, color: Colors.white) : Text('$n', style: const TextStyle(fontSize: 11))),
          const SizedBox(width: 10),
          Expanded(child: Text(t, style: TextStyle(fontWeight: done ? FontWeight.w700 : FontWeight.w500))),
        ]),
      );

  Widget _docTile(String kind, bool required) {
    final d = _docs[kind];
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Icon(d == null ? Icons.upload_file : Icons.check_circle, color: d == null ? null : maliGreen),
      title: Text('${_docKinds[kind]}${required ? ' *' : ''}'),
      subtitle: Text(d?.name ?? 'Photo ou PDF · 8 Mo maximum'),
      trailing: d == null
          ? OutlinedButton(onPressed: () => _pick(kind), child: const Text('Ajouter'))
          : IconButton(tooltip: 'Retirer', icon: const Icon(Icons.close), onPressed: () => setState(() => _docs[kind] = null)),
      onTap: () => _pick(kind),
    );
  }

  Widget _form(Map<String, dynamic> data) {
    final cats = List<String>.from(data['cats'] as List);
    if (!_prefilled) {
      final p = data['profile'] as Map<String, dynamic>;
      _phone.text = '${p['phone'] ?? ''}';
      _city.text = '${p['city'] ?? ''}';
      _prefilled = true;
    }
    final last = data['app'] as Map<String, dynamic>?;
    return ListView(padding: const EdgeInsets.all(14), children: [
      Container(
        padding: const EdgeInsets.all(14),
        decoration: softBox(),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Comment devenir vendeur', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 15, color: brandDark)),
          const SizedBox(height: 6),
          _step(1, 'Créer un compte et se connecter', true),
          _step(2, 'Compléter les informations de la boutique', false),
          _step(3, 'Fournir les documents de vérification', false),
          _step(4, 'Attendre la validation de MAYA', false),
        ]),
      ),
      if (last != null && last['status'] == 'rejected')
        Container(
          margin: const EdgeInsets.only(top: 10),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFFFFEBEE), borderRadius: BorderRadius.circular(14)),
          child: Text('Votre précédente demande a été refusée.\nMotif : ${last['admin_note'] ?? 'non précisé'}\nVous pouvez corriger et renvoyer une demande.'),
        ),
      const SizedBox(height: 10),
      Section('Votre boutique', [
        TextField(controller: _shop, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nom de la boutique *', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: _activity, maxLines: 3, decoration: const InputDecoration(labelText: 'Que vendez-vous ? *', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        if (cats.isNotEmpty)
          DropdownButtonFormField<String>(
            value: _category,
            items: [for (final c in cats) DropdownMenuItem(value: c, child: Text(c))],
            onChanged: (v) => setState(() => _category = v),
            decoration: const InputDecoration(labelText: 'Catégorie principale', border: OutlineInputBorder()),
          ),
        if (cats.isNotEmpty) const SizedBox(height: 10),
        TextField(controller: _city, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Ville *', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: _address, decoration: const InputDecoration(labelText: 'Adresse / quartier', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone *', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: _wa, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'WhatsApp', border: OutlineInputBorder())),
      ]),
      Section('Documents de vérification', [
        const Text('Ils ne sont vus que par l\'administration MAYA et ne sont jamais publiés.', style: TextStyle(fontSize: 12, color: Colors.black54)),
        _docTile('identity', true),
        _docTile('business', false),
        _docTile('other', false),
      ]),
      const SizedBox(height: 8),
      FilledButton.icon(onPressed: _busy ? null : _submit, icon: const Icon(Icons.send), label: Text(_busy ? 'Envoi…' : 'Envoyer ma demande')),
      const SizedBox(height: 6),
      const Text('Tant que MAYA n\'a pas validé votre demande, vous ne pouvez pas publier de produits.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
    ]);
  }

  Widget _statusCard(Map<String, dynamic> a) {
    final st = '${a['status']}';
    final color = st == 'approved' ? maliGreen : (st == 'rejected' ? maliRed : gold);
    return ListView(padding: const EdgeInsets.all(14), children: [
      Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: color, width: 1.6)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Icon(st == 'approved' ? Icons.verified : Icons.hourglass_top, color: color),
            const SizedBox(width: 8),
            Text('Demande ${_appStatus[st] ?? st}', style: TextStyle(fontWeight: FontWeight.w800, color: color, fontSize: 16)),
          ]),
          const SizedBox(height: 8),
          Text('Boutique : ${a['shop_name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
          Text('${a['city']} · envoyée le ${dOnly(a['created_at'])}'),
          const SizedBox(height: 8),
          Text(st == 'pending'
              ? 'MAYA vérifie votre demande et vos documents. Vous recevrez une notification dès la décision.'
              : 'Votre demande est acceptée. Fermez puis rouvrez l\'application : votre espace vendeur est disponible.'),
        ]),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Devenir vendeur'), bottom: const MaliStripe()),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 640),
            child: FutureBuilder<Map<String, dynamic>>(
              future: _f,
              builder: (context, snap) {
                if (snap.hasError) return errorView(snap.error);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                final role = '${(snap.data!['profile'] as Map)['role']}';
                if (role != 'client') {
                  return Center(
                      child: Padding(
                          padding: const EdgeInsets.all(24),
                          child: Text(role == 'seller' ? 'Votre compte est déjà un compte vendeur.' : 'Votre compte dispose déjà d\'un espace dédié.', textAlign: TextAlign.center)));
                }
                final a = snap.data!['app'] as Map<String, dynamic>?;
                if (a != null && (a['status'] == 'pending' || a['status'] == 'approved')) return _statusCard(a);
                return _form(snap.data!);
              },
            ),
          ),
        ),
      );
}

// ======== Administration : demandes vendeurs ========
class AdminSellerApplicationsScreen extends StatefulWidget {
  const AdminSellerApplicationsScreen({super.key});
  @override
  State<AdminSellerApplicationsScreen> createState() => _AdminSellerApplicationsScreenState();
}

class _AdminSellerApplicationsScreenState extends State<AdminSellerApplicationsScreen> {
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final rows = await sb.from('seller_applications').select('*, profiles!seller_applications_user_id_fkey(full_name, phone)').order('created_at', ascending: false).limit(200);
    final list = [for (final r in rows as List) Map<String, dynamic>.from(r as Map)];
    list.sort((a, b) => (a['status'] == 'pending' ? 0 : 1).compareTo(b['status'] == 'pending' ? 0 : 1));
    return list;
  }

  Future<void> _open(String path) => guarded(context, () async {
        final url = await sb.storage.from('seller-docs').createSignedUrl(path, 300);
        await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      });

  Future<void> _review(Map<String, dynamic> a, bool approve) async {
    String? note;
    if (!approve) {
      note = await askText(context, 'Motif du refus (visible par le demandeur)');
      if (note == null || note.isEmpty || !mounted) return;
    } else {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Valider ce vendeur ?'),
          content: Text('Le compte deviendra vendeur et la boutique « ${a['shop_name']} » sera créée. Il pourra publier des produits (soumis à votre validation).'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Valider')),
          ],
        ),
      );
      if (ok != true || !mounted) return;
    }
    await guarded(context, () async {
      await sb.rpc('admin_review_seller_application', params: {'p_id': a['id'], 'p_approve': approve, 'p_note': note});
      if (mounted) setState(() => _f = _load());
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('Aucune demande vendeur pour le moment.'));
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView(padding: const EdgeInsets.all(10), children: [
              for (final a in list)
                Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.all(12),
                  decoration: softBox(),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text('${a['shop_name']}', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15))),
                      Text(_appStatus[a['status']] ?? '${a['status']}',
                          style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11, color: a['status'] == 'pending' ? gold : (a['status'] == 'approved' ? maliGreen : maliRed))),
                    ]),
                    const SizedBox(height: 4),
                    Text('${(a['profiles'] as Map?)?['full_name'] ?? ''} · ${a['phone']} · ${a['city']}${a['address'] != null ? ' · ${a['address']}' : ''}'),
                    if (a['category'] != null) Text('Catégorie : ${a['category']}'),
                    const SizedBox(height: 4),
                    Text('${a['activity']}'),
                    Text('Reçue le ${dt(a['created_at'])}', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                    const SizedBox(height: 6),
                    Wrap(spacing: 6, children: [
                      for (final d in (a['doc_paths'] as List))
                        ActionChip(
                          avatar: const Icon(Icons.attach_file, size: 16),
                          label: Text(_docKinds[(d as Map)['kind']] ?? '${d['kind']}', style: const TextStyle(fontSize: 12)),
                          onPressed: () => _open('${d['path']}'),
                        ),
                    ]),
                    if (a['admin_note'] != null) Padding(padding: const EdgeInsets.only(top: 4), child: Text('Note : ${a['admin_note']}', style: const TextStyle(fontStyle: FontStyle.italic))),
                    if (a['status'] == 'pending')
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Row(children: [
                          Expanded(child: OutlinedButton.icon(onPressed: () => _review(a, false), icon: const Icon(Icons.close, color: maliRed), label: const Text('Refuser'))),
                          const SizedBox(width: 8),
                          Expanded(child: FilledButton.icon(onPressed: () => _review(a, true), icon: const Icon(Icons.check), label: const Text('Valider'))),
                        ]),
                      ),
                  ]),
                ),
            ]),
          );
        },
      );
}
