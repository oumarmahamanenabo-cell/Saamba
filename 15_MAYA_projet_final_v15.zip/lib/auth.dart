import 'package:flutter/material.dart';
import 'common.dart';

/// Connexion / inscription. N'est plus l'écran d'entrée : il s'ouvre à la demande
/// (bouton « Se connecter », fenêtre « compte requis », « Devenir vendeur »…).
/// Se ferme tout seul avec `true` dès que la session est ouverte.
class AuthScreen extends StatefulWidget {
  final bool initialRegister;

  /// Message d'accueil affiché au-dessus du formulaire (ex. pourquoi un compte est nécessaire).
  final String? banner;
  const AuthScreen({super.key, this.initialRegister = false, this.banner});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  late bool _register = widget.initialRegister;
  bool _busy = false;
  final _name = TextEditingController(),
      _city = TextEditingController(),
      _email = TextEditingController(),
      _phone = TextEditingController(text: '+223 '),
      _pass = TextEditingController();

  // Numéro malien normalisé : 223 + 8 chiffres (accepte « +223 70 00 00 00 » ou « 70 00 00 00 »)
  String _digitsOf(String text) {
    var d = text.replaceAll(RegExp(r'\D'), '');
    if (d.length == 8) d = '223$d';
    return d;
  }

  bool get _phoneOk => RegExp(r'^223\d{8}$').hasMatch(_digitsOf(_phone.text));

  bool _isEmail(String v) => RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(v.trim());

  @override
  void dispose() {
    _name.dispose();
    _city.dispose();
    _email.dispose();
    _phone.dispose();
    _pass.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final mail = _email.text.trim().toLowerCase();
    if (_pass.text.length < 6) {
      snack(context, 'Le mot de passe doit contenir 6 caractères minimum.');
      return;
    }
    if (_register) {
      if (_name.text.trim().length < 2) {
        snack(context, 'Le nom complet est obligatoire.');
        return;
      }
      if (_city.text.trim().length < 2) {
        snack(context, 'La ville est obligatoire.');
        return;
      }
      if (!_phoneOk) {
        snack(context, 'Numéro de téléphone malien obligatoire (+223 suivi de 8 chiffres).');
        return;
      }
      if (!_isEmail(mail)) {
        snack(context, 'Adresse e-mail invalide.');
        return;
      }
    } else if (!_isEmail(mail) && !RegExp(r'^223\d{8}$').hasMatch(_digitsOf(mail))) {
      snack(context, 'Saisissez votre adresse e-mail.');
      return;
    }
    setState(() => _busy = true);
    await guarded(context, () async {
      if (_register) {
        await sb.auth.signUp(email: mail, password: _pass.text, data: {
          'full_name': _name.text.trim(),
          'phone': '+${_digitsOf(_phone.text)}',
          'city': _city.text.trim(),
        });
      } else {
        // Les anciens comptes créés avec un numéro restent utilisables (numéro saisi à la place de l'e-mail).
        final login = _isEmail(mail) ? mail : '${_digitsOf(mail)}@saamba.app';
        await sb.auth.signInWithPassword(email: login, password: _pass.text);
      }
    });
    if (!mounted) return;
    setState(() => _busy = false);
    if (sb.auth.currentUser != null) {
      Navigator.of(context).pop(true);
    } else if (_register) {
      snack(context, 'Compte créé. Connectez-vous avec votre e-mail et votre mot de passe.');
      setState(() => _register = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(_register ? 'Créer un compte' : 'Se connecter'), bottom: const MaliStripe()),
        body: SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: ConstrainedBox(
                constraints: const BoxConstraints(maxWidth: 440),
                child: Column(children: [
                  const MayaFullLogo(width: 250),
                  const SizedBox(height: 8),
                  const AnimatedSlogan(text: 'Le commerce, plus proche de vous !', fontSize: 13),
                  if (widget.banner != null) ...[
                    const SizedBox(height: 16),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(color: const Color(0xFFFFF1CF), borderRadius: BorderRadius.circular(14)),
                      child: Text(widget.banner!, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: brandDark)),
                    ),
                  ],
                  const SizedBox(height: 20),
                  if (_register) ...[
                    TextField(
                        controller: _name,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(labelText: 'Nom complet *', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    TextField(
                        controller: _city,
                        textCapitalization: TextCapitalization.words,
                        decoration: const InputDecoration(labelText: 'Ville *', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                    TextField(
                        controller: _phone,
                        keyboardType: TextInputType.phone,
                        decoration: const InputDecoration(labelText: 'Numéro de téléphone malien (+223…) *', border: OutlineInputBorder())),
                    const SizedBox(height: 12),
                  ],
                  TextField(
                      controller: _email,
                      keyboardType: TextInputType.emailAddress,
                      autocorrect: false,
                      decoration: InputDecoration(labelText: _register ? 'Adresse e-mail *' : 'Adresse e-mail', border: const OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(
                      controller: _pass,
                      obscureText: true,
                      onSubmitted: (_) => _busy ? null : _submit(),
                      decoration: InputDecoration(labelText: _register ? 'Mot de passe * (6 caractères minimum)' : 'Mot de passe', border: const OutlineInputBorder())),
                  const SizedBox(height: 20),
                  SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                          onPressed: _busy ? null : _submit, child: Text(_busy ? '…' : (_register ? 'Créer mon compte' : 'Se connecter')))),
                  TextButton(
                      onPressed: () => setState(() => _register = !_register),
                      child: Text(_register ? 'J\'ai déjà un compte' : 'Créer un compte client')),
                  TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Continuer sans compte')),
                ]),
              ),
            ),
          ),
        ),
      );
}
