import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';

// MAYA SELLER HUNTER — module de prospection réservé à l'administration.
// L'accès réel est protégé côté serveur (RLS : public.is_admin()). Ce fichier n'est atteint
// que depuis AdminShell. Exécuter d'abord supabase/migrations/20261115g_seller_hunter.sql.

const _joinBase = 'https://maya.app/join-seller/';

const _statusLabels = <String, String>{
  'nouveau': 'Nouveau prospect',
  'a_verifier': 'À vérifier',
  'verifie': 'Vérifié',
  'a_inviter': 'À inviter',
  'invitation_preparee': 'Invitation préparée',
  'invitation_envoyee': 'Invitation envoyée',
  'invitation_recue': 'Invitation reçue',
  'a_repondu': 'A répondu',
  'interesse': 'Intéressé',
  'inscription_commencee': 'Inscription commencée',
  'inscription_terminee': 'Inscription terminée',
  'en_attente_verification': 'En attente de vérification',
  'vendeur_valide': 'Vendeur validé',
  'refuse': 'Refusé',
  'desinscrit': 'Désinscrit',
};

const _invStatusLabels = <String, String>{
  'prepared': 'Préparée',
  'sent': 'Envoyée',
  'delivered': 'Reçue',
  'clicked': 'Lien ouvert',
  'replied': 'A répondu',
  'registering': 'Inscription commencée',
  'registered': 'Inscription terminée',
  'failed': 'Échec',
  'cancelled': 'Annulée',
};

const _priorityLabels = <String, String>{'high': 'Priorité élevée', 'medium': 'Priorité moyenne', 'to_check': 'À vérifier'};
const _langs = <String, String>{'fr': 'Français', 'en': 'English', 'pt': 'Português', 'ar': 'العربية'};
const _channels = <String, String>{'whatsapp': 'WhatsApp', 'email': 'E-mail', 'link': 'Lien seul'};
const _bizTypes = <String, String>{
  'retailer': 'Détaillant',
  'wholesaler': 'Grossiste',
  'manufacturer': 'Fabricant',
  'distributor': 'Distributeur',
  'other': 'Autre',
};

const _africa = <String, String>{
  'DZ': 'Algérie', 'AO': 'Angola', 'BJ': 'Bénin', 'BW': 'Botswana', 'BF': 'Burkina Faso', 'BI': 'Burundi',
  'CM': 'Cameroun', 'CV': 'Cap-Vert', 'CF': 'Centrafrique', 'TD': 'Tchad', 'KM': 'Comores', 'CG': 'Congo',
  'CD': 'RD Congo', 'CI': 'Côte d\'Ivoire', 'DJ': 'Djibouti', 'EG': 'Égypte', 'GQ': 'Guinée équatoriale',
  'ER': 'Érythrée', 'SZ': 'Eswatini', 'ET': 'Éthiopie', 'GA': 'Gabon', 'GM': 'Gambie', 'GH': 'Ghana',
  'GN': 'Guinée', 'GW': 'Guinée-Bissau', 'KE': 'Kenya', 'LS': 'Lesotho', 'LR': 'Libéria', 'LY': 'Libye',
  'MG': 'Madagascar', 'MW': 'Malawi', 'ML': 'Mali', 'MR': 'Mauritanie', 'MU': 'Maurice', 'MA': 'Maroc',
  'MZ': 'Mozambique', 'NA': 'Namibie', 'NE': 'Niger', 'NG': 'Nigéria', 'RW': 'Rwanda',
  'ST': 'Sao Tomé-et-Principe', 'SN': 'Sénégal', 'SC': 'Seychelles', 'SL': 'Sierra Leone', 'SO': 'Somalie',
  'ZA': 'Afrique du Sud', 'SS': 'Soudan du Sud', 'SD': 'Soudan', 'TZ': 'Tanzanie', 'TG': 'Togo',
  'TN': 'Tunisie', 'UG': 'Ouganda', 'ZM': 'Zambie', 'ZW': 'Zimbabwe',
};

// ---------- utilitaires ----------

String _cname(dynamic cc) => cc == null ? 'Inconnu' : (_africa['$cc'.toUpperCase()] ?? '$cc');
String _digits(dynamic s) => '${s ?? ''}'.replaceAll(RegExp(r'\D'), '');
String _slug(dynamic s) => '${s ?? ''}'.toLowerCase().replaceAll(RegExp(r'[^a-z0-9]+'), '');
String? _nz(String s) => s.trim().isEmpty ? null : s.trim();
Color _prioColor(dynamic p) => p == 'high' ? maliGreen : (p == 'medium' ? gold : Colors.grey);
String _url(String u) => u.startsWith('http') ? u : 'https://$u';
String _nowIso() => DateTime.now().toUtc().toIso8601String();

String _host(dynamic u) {
  final t = '${u ?? ''}'.trim();
  if (t.isEmpty) return '';
  final uri = Uri.tryParse(_url(t));
  return (uri?.host ?? '').replaceFirst(RegExp(r'^www\.'), '').toLowerCase();
}

String _dedupe(Map<String, dynamic> p) {
  final cc = '${p['country_code'] ?? 'xx'}'.toLowerCase();
  final wa = _digits(p['whatsapp']);
  if (wa.length >= 7) return '$cc|wa|$wa';
  final h = _host(p['website']);
  if (h.isNotEmpty) return '$cc|web|$h';
  return '$cc|name|${_slug(p['shop_name'])}|${_slug(p['city'])}';
}

Map<String, dynamic> _score(Map<String, dynamic> p) {
  var s = 0;
  final reasons = <String>[];
  final links = (p['social_links'] is Map) ? Map<String, dynamic>.from(p['social_links'] as Map) : <String, dynamic>{};
  final hasContact = _digits(p['whatsapp']).isNotEmpty || '${p['email'] ?? ''}'.isNotEmpty;
  final hasSite = '${p['website'] ?? ''}'.isNotEmpty;
  if (hasSite) {
    s += 15;
    reasons.add('Site Internet public');
  }
  if (hasContact) {
    s += 20;
    reasons.add('Coordonnées professionnelles publiques');
  }
  final platforms = links.values.where((v) => '${v ?? ''}'.isNotEmpty).length + (hasSite ? 1 : 0);
  if (platforms >= 2) {
    s += 20;
    reasons.add('Présence sur plusieurs plateformes');
  }
  if (p['products'] is List && (p['products'] as List).isNotEmpty) {
    s += 20;
    reasons.add('Produits visibles');
  }
  if ('${p['city'] ?? ''}'.isNotEmpty && '${p['country_code'] ?? ''}'.isNotEmpty) {
    s += 10;
    reasons.add('Localisation identifiée');
  }
  if (links.isNotEmpty) {
    s += 15;
    reasons.add('Profil commercial public');
  }
  if (s > 100) s = 100;
  if (reasons.isEmpty) reasons.add('Informations insuffisantes');
  final prio = (s >= 65 && hasContact) ? 'high' : (s >= 35 ? 'medium' : 'to_check');
  return {'confidence_score': s, 'priority': prio, 'score_reasons': reasons};
}

/// Ajoute un prospect s'il n'existe pas déjà (détection de doublons). Retourne false si doublon.
Future<bool> _insertProspect(Map<String, dynamic> p) async {
  p['dedupe_key'] = _dedupe(p);
  final ex = await sb.from('seller_prospects').select('id').eq('dedupe_key', p['dedupe_key'] as String).maybeSingle();
  if (ex != null) return false;
  p.addAll(_score(p));
  p['created_by'] = uid;
  p['last_verified_at'] = _nowIso();
  await sb.from('seller_prospects').insert(p);
  return true;
}

Future<List<Map<String, dynamic>>> _rows(String table, String cols) async {
  final all = <Map<String, dynamic>>[];
  for (var from = 0; from < 20000; from += 1000) {
    final r = await sb.from(table).select(cols).range(from, from + 999);
    all.addAll(List<Map<String, dynamic>>.from(r));
    if (r.length < 1000) break;
  }
  return all;
}

Map<String, int> _count(List<Map<String, dynamic>> rows, String key) {
  final m = <String, int>{};
  for (final r in rows) {
    final v = r[key] == null ? 'inconnu' : '${r[key]}';
    m[v] = (m[v] ?? 0) + 1;
  }
  return m;
}

Future<void> _open(BuildContext c, String url) async {
  await guarded(c, () async {
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && c.mounted) snack(c, 'Impossible d\'ouvrir ce lien.');
  });
}

Widget _err(Object? e) {
  final m = '$e';
  final missing = m.contains('seller_') && (m.contains('does not exist') || m.contains('schema cache') || m.contains('relation'));
  return Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Text(
        missing
            ? 'Module non installé : exécutez supabase/migrations/20261115g_seller_hunter.sql dans le SQL Editor de Supabase, puis revenez ici.'
            : 'Erreur : $m',
        textAlign: TextAlign.center,
      ),
    ),
  );
}

Widget _statCard(String label, Object? v, {Color? color}) => Container(
      decoration: softBox(color: color),
      padding: const EdgeInsets.all(8),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Text('$v', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: brandDark)),
        const SizedBox(height: 2),
        Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11, color: Color(0xFF55607A))),
      ]),
    );

Widget _grid(List<Widget> children) => GridView.count(
      crossAxisCount: 3,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisSpacing: 8,
      mainAxisSpacing: 8,
      childAspectRatio: 1.1,
      children: children,
    );

Widget _bars(Map<String, int> data, {String Function(String)? label}) {
  if (data.isEmpty) return const Text('Pas encore de données.');
  final e = data.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
  final mx = e.first.value == 0 ? 1 : e.first.value;
  return Column(children: [
    for (final x in e.take(15))
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: Row(children: [
          SizedBox(
              width: 110,
              child: Text(label == null ? x.key : label(x.key), maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12))),
          Expanded(child: LinearProgressIndicator(value: x.value / mx, minHeight: 8, color: maliGreen, backgroundColor: const Color(0xFFE6EEE4))),
          const SizedBox(width: 8),
          Text('${x.value}', style: const TextStyle(fontWeight: FontWeight.w700)),
        ]),
      ),
  ]);
}

Future<List<Map<String, dynamic>>> _categories() async {
  final r = await sb.from('seller_categories').select().order('sort_order').order('label_fr');
  return List<Map<String, dynamic>>.from(r);
}

String _render(String t, Map<String, dynamic> p, String link) => t
    .replaceAll('{{shop_name}}', '${p['shop_name'] ?? ''}')
    .replaceAll('{{owner_name}}', '${p['owner_name'] ?? ''}')
    .replaceAll('{{country}}', '${p['country'] ?? ''}')
    .replaceAll('{{category}}', '${p['category'] ?? ''}')
    .replaceAll('{{join_link}}', link);

String _token() {
  final r = Random.secure();
  return List.generate(32, (_) => r.nextInt(256).toRadixString(16).padLeft(2, '0')).join();
}

/// Prépare des invitations (rien n'est envoyé). Retourne {prepared, skipped}.
Future<Map<String, int>> _prepare(List<Map<String, dynamic>> ps, String channel, String lang) async {
  final tpl = await sb.from('seller_message_templates').select().eq('name', 'invitation_standard').eq('language', lang).eq('active', true).maybeSingle();
  if (tpl == null) throw 'Modèle de message introuvable pour cette langue.';
  final unsubs = await sb.from('seller_unsubscribes').select('contact_value').eq('channel', channel);
  final blocked = <String>{for (final u in unsubs) '${u['contact_value']}'};
  bool eligible(Map<String, dynamic> p) {
    if (p['status'] == 'desinscrit' || p['status'] == 'refuse') return false;
    if (channel == 'whatsapp' && _digits(p['whatsapp']).length < 7) return false;
    if (channel == 'email' && '${p['email'] ?? ''}'.isEmpty) return false;
    if (blocked.contains(_digits(p['whatsapp'])) && channel == 'whatsapp') return false;
    if (blocked.contains('${p['email'] ?? ''}'.toLowerCase()) && channel == 'email') return false;
    return true;
  }

  final ok = ps.where(eligible).toList();
  final skipped = ps.length - ok.length;
  if (ok.isEmpty) return {'prepared': 0, 'skipped': skipped};
  final camp = await sb.from('seller_campaigns').insert({
    'name': 'Campagne ${dt(_nowIso())}',
    'channel': channel,
    'language': lang,
    'status': 'prepared',
    'template_id': tpl['id'],
    'created_by': uid,
  }).select('id').single();
  final rows = <Map<String, dynamic>>[];
  for (final p in ok) {
    final tok = _token();
    rows.add({
      'prospect_id': p['id'],
      'campaign_id': camp['id'],
      'channel': channel,
      'language': lang,
      'message': _render('${tpl['body']}', p, '$_joinBase$tok'),
      'join_token': tok,
      'status': 'prepared',
      'created_by': uid,
    });
  }
  final inserted = await sb.from('seller_invitations').insert(rows).select('id');
  await sb.from('seller_invitation_events').insert([
    for (final i in inserted) {'invitation_id': i['id'], 'event_type': 'prepared', 'actor_id': uid}
  ]);
  await sb
      .from('seller_prospects')
      .update({'status': 'invitation_preparee'})
      .inFilter('id', [for (final p in ok) p['id']])
      .inFilter('status', ['nouveau', 'a_verifier', 'verifie', 'a_inviter']);
  return {'prepared': ok.length, 'skipped': skipped};
}

Future<void> _inviteFlow(BuildContext context, List<Map<String, dynamic>> ps) async {
  if (ps.isEmpty) {
    snack(context, 'Sélectionnez au moins un prospect.');
    return;
  }
  if (ps.length > 500) {
    snack(context, 'Maximum 500 prospects par campagne.');
    return;
  }
  var channel = 'whatsapp';
  var lang = 'fr';
  final go = await showDialog<bool>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text('Inviter ${ps.length} prospect(s)'),
        content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          DropdownButtonFormField<String>(
            value: channel,
            decoration: const InputDecoration(labelText: 'Canal'),
            items: [for (final e in _channels.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value))],
            onChanged: (v) => setS(() => channel = v ?? channel),
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: lang,
            decoration: const InputDecoration(labelText: 'Langue du message'),
            items: [for (final e in _langs.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value))],
            onChanged: (v) => setS(() => lang = v ?? lang),
          ),
          const SizedBox(height: 12),
          const Text(
            'Les invitations sont seulement préparées : rien n\'est envoyé automatiquement. Vous envoyez vous-même chaque message depuis l\'onglet Invitations. Les prospects désinscrits ou sans contact public sont écartés.',
            style: TextStyle(fontSize: 12),
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmer')),
        ],
      ),
    ),
  );
  if (go != true || !context.mounted) return;
  await guarded(context, () async {
    final r = await _prepare(ps, channel, lang);
    if (!context.mounted) return;
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Invitations préparées'),
        content: Text('${r['prepared']} invitation(s) préparée(s), ${r['skipped']} écartée(s).\nOuvrez l\'onglet Invitations pour envoyer chaque message.'),
        actions: [FilledButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
      ),
    );
  });
}

// ---------- écran principal ----------

class SellerHunterScreen extends StatelessWidget {
  const SellerHunterScreen({super.key});
  static const _tabs = ['Vue générale', 'Recherche', 'Prospects', 'Campagnes', 'Invitations', 'Recrutés', 'Statistiques', 'Paramètres'];

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: _tabs.length,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('MAYA Seller Hunter'),
            bottom: TabBar(
              isScrollable: true,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              indicatorColor: gold,
              tabs: [for (final t in _tabs) Tab(text: t)],
            ),
          ),
          body: const TabBarView(children: [
            _Overview(),
            _AddImport(),
            _ProspectsTab(),
            _CampaignsTab(),
            _InvitationsTab(),
            _RecruitedTab(),
            _StatsTab(),
            _SettingsTab(),
          ]),
        ),
      );
}

// ---------- 1. Vue générale ----------

class _Overview extends StatefulWidget {
  const _Overview();
  @override
  State<_Overview> createState() => _OverviewState();
}

class _OverviewState extends State<_Overview> {
  late Future<List<List<Map<String, dynamic>>>> _f = _load();
  Future<List<List<Map<String, dynamic>>>> _load() async => [await _rows('seller_prospects', 'status,priority'), await _rows('seller_invitations', 'status')];

  @override
  Widget build(BuildContext context) => FutureBuilder<List<List<Map<String, dynamic>>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return _err(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final ps = _count(snap.data![0], 'status');
          final iv = _count(snap.data![1], 'status');
          int g(Map<String, int> m, List<String> k) => k.fold(0, (a, b) => a + (m[b] ?? 0));
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              const HeroBanner(title: 'Centre de prospection'),
              _grid([
                _statCard('Vendeurs découverts', snap.data![0].length),
                _statCard('Vérifiés', ps['verifie'] ?? 0),
                _statCard('À inviter', ps['a_inviter'] ?? 0),
                _statCard('Invitations préparées', g(iv, ['prepared'])),
                _statCard('Invitations envoyées', g(iv, ['sent', 'delivered', 'clicked', 'replied', 'registering', 'registered'])),
                _statCard('Réponses', g(iv, ['replied', 'registering', 'registered'])),
                _statCard('Inscriptions', g(iv, ['registered'])),
                _statCard('Vendeurs validés', ps['vendeur_valide'] ?? 0),
                _statCard('Désinscrits', ps['desinscrit'] ?? 0),
              ]),
              const Section('Rappel', [
                Text('Aucune invitation n\'est envoyée automatiquement : vous préparez, puis vous envoyez vous-même depuis l\'onglet Invitations. '
                    'Un prospect n\'est jamais validé automatiquement comme vendeur.', style: TextStyle(fontSize: 12)),
              ]),
            ]),
          );
        },
      );
}

// ---------- 2. Recherche : ajout manuel et import ----------

class _AddImport extends StatefulWidget {
  const _AddImport();
  @override
  State<_AddImport> createState() => _AddImportState();
}

class _AddImportState extends State<_AddImport> {
  bool _busy = false;

  Future<void> _addOne() async {
    final ok = await showModalBottomSheet<bool>(context: context, isScrollControlled: true, builder: (_) => const _ProspectForm());
    if (ok == true && mounted) snack(context, 'Prospect ajouté.');
  }

  Future<void> _import() async {
    final ctrl = TextEditingController();
    final text = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Importer une liste'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text(
              'Collez des lignes CSV avec une première ligne d\'en-têtes. Colonnes possibles : shop_name (obligatoire), owner_name, country_code, city, category, whatsapp, email, website, facebook, instagram, tiktok, products. Maximum 500 lignes.',
              style: TextStyle(fontSize: 12),
            ),
            const SizedBox(height: 8),
            TextField(controller: ctrl, maxLines: 8, minLines: 5, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'shop_name,country_code,city,whatsapp\nBoutique Aya,ML,Bamako,+22370000000')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Importer')),
        ],
      ),
    );
    if (text == null || text.trim().isEmpty || !mounted) return;
    setState(() => _busy = true);
    await guarded(context, () async {
      final r = await _importCsv(text);
      if (mounted) snack(context, r);
    });
    if (mounted) setState(() => _busy = false);
  }

  Future<String> _importCsv(String text) async {
    final lines = text.split(RegExp(r'\r?\n')).where((l) => l.trim().isNotEmpty).toList();
    if (lines.length < 2) throw 'Collez l\'en-tête et au moins une ligne.';
    if (lines.length > 501) throw 'Maximum 500 lignes par import.';
    final sep = (lines.first.contains(';') && !lines.first.contains(',')) ? ';' : ',';
    final head = lines.first.split(sep).map((e) => e.trim().toLowerCase()).toList();
    if (!head.contains('shop_name')) throw 'La colonne shop_name est obligatoire.';
    final cats = {for (final c in await _categories()) '${c['slug']}'};
    var added = 0, dup = 0, bad = 0;
    for (final l in lines.skip(1)) {
      final cells = l.split(sep);
      final m = <String, String>{};
      for (var i = 0; i < head.length && i < cells.length; i++) {
        m[head[i]] = cells[i].trim();
      }
      final name = m['shop_name'] ?? '';
      if (name.length < 2) {
        bad++;
        continue;
      }
      final cc = (m['country_code'] ?? '').toUpperCase();
      final links = <String, String>{};
      for (final k in ['facebook', 'instagram', 'tiktok']) {
        if ((m[k] ?? '').isNotEmpty) links[k] = m[k]!;
      }
      final p = <String, dynamic>{
        'shop_name': name,
        'owner_name': _nz(m['owner_name'] ?? ''),
        'country_code': _africa.containsKey(cc) ? cc : null,
        'country': _africa.containsKey(cc) ? _africa[cc] : null,
        'city': _nz(m['city'] ?? ''),
        'category': cats.contains(m['category']) ? m['category'] : null,
        'whatsapp': _nz(m['whatsapp'] ?? ''),
        'email': _nz((m['email'] ?? '').toLowerCase()),
        'website': _nz(m['website'] ?? ''),
        'social_links': links,
        'products': (m['products'] ?? '').split('|').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
        'discovery_source': 'import_csv',
      };
      if (await _insertProspect(p)) {
        added++;
      } else {
        dup++;
      }
    }
    return '$added ajouté(s), $dup doublon(s) ignoré(s), $bad ligne(s) invalide(s).';
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(12), children: [
        Section('Ajouter des vendeurs', [
          const Text('Saisissez un commerce trouvé sur Facebook, Instagram, TikTok, Google ou un annuaire. N\'enregistrez que des informations publiques.', style: TextStyle(fontSize: 12)),
          const SizedBox(height: 10),
          SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: _busy ? null : _addOne, icon: const Icon(Icons.add_business), label: const Text('Ajouter un prospect'))),
          const SizedBox(height: 8),
          SizedBox(width: double.infinity, child: OutlinedButton.icon(onPressed: _busy ? null : _import, icon: _busy ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.upload_file), label: Text(_busy ? 'Import en cours…' : 'Importer une liste (CSV)'))),
          const SizedBox(height: 6),
          const Text('Plusieurs produits dans une cellule : séparez-les par « | ».', style: TextStyle(fontSize: 11)),
        ]),
        const Section('Recherche automatique', [
          Text('La découverte automatique (Google Places, annuaires, recherches programmées) nécessite une fonction serveur et une clé API qui ne sont pas encore activées. '
              'En attendant, ajoutez les prospects ici : doublons détectés, score calculé et fiche créée automatiquement.', style: TextStyle(fontSize: 12)),
        ]),
      ]);
}

class _ProspectForm extends StatefulWidget {
  const _ProspectForm();
  @override
  State<_ProspectForm> createState() => _ProspectFormState();
}

class _ProspectFormState extends State<_ProspectForm> {
  static const _keys = ['shop_name', 'owner_name', 'city', 'whatsapp', 'email', 'website', 'facebook', 'instagram', 'tiktok', 'products'];
  static const _labels = <String, String>{
    'shop_name': 'Nom de la boutique *',
    'owner_name': 'Responsable (si public)',
    'city': 'Ville',
    'whatsapp': 'WhatsApp professionnel public',
    'email': 'E-mail professionnel public',
    'website': 'Site Internet',
    'facebook': 'Lien Facebook',
    'instagram': 'Lien Instagram',
    'tiktok': 'Lien TikTok',
    'products': 'Produits (séparés par des virgules)',
  };
  final _c = <String, TextEditingController>{for (final k in _keys) k: TextEditingController()};
  String? _cc, _cat, _bt;
  List<Map<String, dynamic>> _cats = [];
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _categories().then((v) {
      if (mounted) setState(() => _cats = v);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    for (final c in _c.values) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    final name = _c['shop_name']!.text.trim();
    if (name.length < 2) {
      snack(context, 'Le nom de la boutique est obligatoire.');
      return;
    }
    setState(() => _busy = true);
    await guarded(context, () async {
      final links = <String, String>{};
      for (final k in ['facebook', 'instagram', 'tiktok']) {
        final v = _c[k]!.text.trim();
        if (v.isNotEmpty) links[k] = v;
      }
      final p = <String, dynamic>{
        'shop_name': name,
        'owner_name': _nz(_c['owner_name']!.text),
        'city': _nz(_c['city']!.text),
        'country_code': _cc,
        'country': _cc == null ? null : _cname(_cc),
        'category': _cat,
        'business_type': _bt,
        'whatsapp': _nz(_c['whatsapp']!.text),
        'email': _nz(_c['email']!.text.toLowerCase()),
        'website': _nz(_c['website']!.text),
        'social_links': links,
        'products': _c['products']!.text.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList(),
        'discovery_source': 'manual',
      };
      final ok = await _insertProspect(p);
      if (!mounted) return;
      if (ok) {
        Navigator.pop(context, true);
      } else {
        snack(context, 'Ce prospect existe déjà (doublon détecté).');
      }
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Nouveau prospect', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: brandDark)),
            const SizedBox(height: 12),
            for (final k in _keys.take(3)) ...[
              TextField(controller: _c[k], decoration: InputDecoration(labelText: _labels[k], border: const OutlineInputBorder())),
              const SizedBox(height: 10),
            ],
            DropdownButtonFormField<String>(
              value: _cc,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Pays', border: OutlineInputBorder()),
              items: [for (final e in _africa.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value))],
              onChanged: (v) => setState(() => _cc = v),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _cat,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Catégorie', border: OutlineInputBorder()),
              items: [for (final c in _cats) DropdownMenuItem<String>(value: '${c['slug']}', child: Text('${c['label_fr']}'))],
              onChanged: (v) => setState(() => _cat = v),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              value: _bt,
              isExpanded: true,
              decoration: const InputDecoration(labelText: 'Type de vendeur', border: OutlineInputBorder()),
              items: [for (final e in _bizTypes.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value))],
              onChanged: (v) => setState(() => _bt = v),
            ),
            const SizedBox(height: 10),
            for (final k in _keys.skip(3)) ...[
              TextField(
                controller: _c[k],
                keyboardType: k == 'email' ? TextInputType.emailAddress : (k == 'whatsapp' ? TextInputType.phone : TextInputType.text),
                decoration: InputDecoration(labelText: _labels[k], border: const OutlineInputBorder()),
              ),
              const SizedBox(height: 10),
            ],
            SizedBox(width: double.infinity, child: FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? '…' : 'Enregistrer'))),
          ]),
        ),
      );
}

// ---------- 3. Prospects ----------

class _ProspectsTab extends StatefulWidget {
  const _ProspectsTab();
  @override
  State<_ProspectsTab> createState() => _ProspectsTabState();
}

class _ProspectsTabState extends State<_ProspectsTab> {
  String _text = '';
  String? _country, _category, _status, _priority;
  List<Map<String, dynamic>> _cats = [];
  final _sel = <String>{};
  List<Map<String, dynamic>> _list = [];
  late Future<List<Map<String, dynamic>>> _f = _load();

  @override
  void initState() {
    super.initState();
    _categories().then((v) {
      if (mounted) setState(() => _cats = v);
    }).catchError((_) {});
  }

  Future<List<Map<String, dynamic>>> _load() async {
    var q = sb.from('seller_prospects').select();
    if (_text.trim().isNotEmpty) q = q.ilike('shop_name', '%${_text.trim()}%');
    if (_country != null) q = q.eq('country_code', _country!);
    if (_category != null) q = q.eq('category', _category!);
    if (_status != null) q = q.eq('status', _status!);
    if (_priority != null) q = q.eq('priority', _priority!);
    final r = await q.order('confidence_score', ascending: false).limit(500);
    _list = List<Map<String, dynamic>>.from(r);
    return _list;
  }

  void _reload() => setState(() {
        _sel.clear();
        _f = _load();
      });

  void _selectFirst(int k) => setState(() {
        _sel
          ..clear()
          ..addAll(_list.take(k).map((p) => '${p['id']}'));
      });

  Widget _filters() => Padding(
        padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
        child: Column(children: [
          TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher une boutique', border: OutlineInputBorder()),
            onSubmitted: (v) {
              _text = v;
              _reload();
            },
          ),
          const SizedBox(height: 6),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(children: [
              _drop('Pays', _country, {for (final e in _africa.entries) e.key: e.value}, (v) {
                _country = v;
                _reload();
              }),
              _drop('Catégorie', _category, {for (final c in _cats) '${c['slug']}': '${c['label_fr']}'}, (v) {
                _category = v;
                _reload();
              }),
              _drop('Statut', _status, _statusLabels, (v) {
                _status = v;
                _reload();
              }),
              _drop('Priorité', _priority, _priorityLabels, (v) {
                _priority = v;
                _reload();
              }),
            ]),
          ),
        ]),
      );

  Widget _drop(String label, String? value, Map<String, String> items, void Function(String?) on) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: SizedBox(
          width: 150,
          child: DropdownButtonFormField<String>(
            value: value,
            isExpanded: true,
            decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
            items: [
              const DropdownMenuItem<String>(value: null, child: Text('Tous')),
              for (final e in items.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis)),
            ],
            onChanged: on,
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => Column(children: [
        _filters(),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(children: [
            PopupMenuButton<int>(
              tooltip: 'Sélectionner',
              onSelected: (k) => _selectFirst(k),
              itemBuilder: (_) => const [
                PopupMenuItem(value: 50, child: Text('Sélectionner 50')),
                PopupMenuItem(value: 100, child: Text('Sélectionner 100')),
                PopupMenuItem(value: 500, child: Text('Sélectionner 500')),
                PopupMenuItem(value: 100000, child: Text('Tous les résultats filtrés')),
              ],
              child: const Padding(padding: EdgeInsets.all(8), child: Row(children: [Icon(Icons.checklist), SizedBox(width: 4), Text('Sélection')])),
            ),
            if (_sel.isNotEmpty) TextButton(onPressed: () => setState(_sel.clear), child: Text('Effacer (${_sel.length})')),
            const Spacer(),
            FilledButton.icon(
              onPressed: _sel.isEmpty ? null : () async => _inviteFlow(context, _list.where((p) => _sel.contains('${p['id']}')).toList()).then((_) => _reload()),
              icon: const Icon(Icons.send),
              label: Text('Inviter (${_sel.length})'),
            ),
          ]),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return _err(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!;
              if (list.isEmpty) return const Center(child: Text('Aucun prospect. Ajoutez-en depuis l\'onglet Recherche.'));
              return ListView.separated(
                itemCount: list.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final p = list[i];
                  final id = '${p['id']}';
                  final on = _sel.contains(id);
                  return ListTile(
                    leading: Checkbox(value: on, onChanged: (v) => setState(() => v == true ? _sel.add(id) : _sel.remove(id))),
                    title: Text('${p['shop_name']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text('${p['city'] ?? ''}${p['city'] != null ? ', ' : ''}${_cname(p['country_code'])} · ${_statusLabels[p['status']] ?? p['status']}'),
                    trailing: Chip(
                      label: Text('${p['confidence_score']}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
                      backgroundColor: _prioColor(p['priority']),
                      visualDensity: VisualDensity.compact,
                    ),
                    onTap: () async {
                      await Navigator.push(context, MaterialPageRoute(builder: (_) => _ProspectDetail(p)));
                      _reload();
                    },
                  );
                },
              );
            },
          ),
        ),
      ]);
}

class _ProspectDetail extends StatefulWidget {
  final Map<String, dynamic> p;
  const _ProspectDetail(this.p);
  @override
  State<_ProspectDetail> createState() => _ProspectDetailState();
}

class _ProspectDetailState extends State<_ProspectDetail> {
  late Map<String, dynamic> p = Map<String, dynamic>.from(widget.p);

  Future<void> _setStatus(String s) async {
    await guarded(context, () async {
      final upd = <String, dynamic>{'status': s};
      if (s == 'verifie') upd['last_verified_at'] = _nowIso();
      await sb.from('seller_prospects').update(upd).eq('id', p['id']);
      if (mounted) setState(() => p.addAll(upd));
    });
  }

  Future<void> _unsubscribe() async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Marquer comme désinscrit ?'),
        content: const Text('Ce prospect (et ses contacts WhatsApp / e-mail) ne pourra plus être invité.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Confirmer')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      final wa = _digits(p['whatsapp']);
      final em = '${p['email'] ?? ''}'.toLowerCase();
      final rows = <Map<String, dynamic>>[
        if (wa.isNotEmpty) {'prospect_id': p['id'], 'channel': 'whatsapp', 'contact_value': wa, 'reason': 'Demande de désinscription'},
        if (em.isNotEmpty) {'prospect_id': p['id'], 'channel': 'email', 'contact_value': em, 'reason': 'Demande de désinscription'},
      ];
      if (rows.isNotEmpty) await sb.from('seller_unsubscribes').upsert(rows, onConflict: 'channel,contact_value');
      await _setStatus('desinscrit');
    });
  }

  Widget _row(String k, dynamic v, {String? open}) {
    final t = '${v ?? ''}'.trim();
    if (t.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        SizedBox(width: 110, child: Text(k, style: const TextStyle(fontSize: 12, color: Color(0xFF55607A)))),
        Expanded(child: Text(t)),
        if (open != null) IconButton(visualDensity: VisualDensity.compact, icon: const Icon(Icons.open_in_new, size: 20), onPressed: () => _open(context, open)),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) {
    final links = (p['social_links'] is Map) ? Map<String, dynamic>.from(p['social_links'] as Map) : <String, dynamic>{};
    final reasons = (p['score_reasons'] is List) ? List<dynamic>.from(p['score_reasons'] as List) : <dynamic>[];
    final prods = (p['products'] is List) ? (p['products'] as List).join(', ') : '';
    final wa = _digits(p['whatsapp']);
    return Scaffold(
      appBar: AppBar(title: Text('${p['shop_name']}')),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        Section('Fiche', [
          _row('Responsable', p['owner_name']),
          _row('Pays', _cname(p['country_code'])),
          _row('Ville', p['city']),
          _row('Adresse', p['address']),
          _row('Catégorie', p['category']),
          _row('Type', _bizTypes[p['business_type']]),
          _row('Produits', prods),
          _row('Description', p['description']),
        ]),
        Section('Contacts publics', [
          _row('WhatsApp', p['whatsapp'], open: wa.length >= 7 ? 'https://wa.me/$wa' : null),
          _row('E-mail', p['email'], open: '${p['email'] ?? ''}'.isEmpty ? null : 'mailto:${p['email']}'),
          _row('Site', p['website'], open: '${p['website'] ?? ''}'.isEmpty ? null : _url('${p['website']}')),
          for (final e in links.entries) _row(e.key, e.value, open: '${e.value ?? ''}'.isEmpty ? null : _url('${e.value}')),
        ]),
        Section('Classement', [
          Row(children: [
            Chip(label: Text(_priorityLabels[p['priority']] ?? '${p['priority']}', style: const TextStyle(color: Colors.white)), backgroundColor: _prioColor(p['priority'])),
            const SizedBox(width: 8),
            Text('Score : ${p['confidence_score']}/100', style: const TextStyle(fontWeight: FontWeight.w700)),
          ]),
          for (final r in reasons) Text('• $r', style: const TextStyle(fontSize: 12)),
        ]),
        Section('Suivi', [
          _row('Source', p['discovery_source']),
          _row('Découvert le', dOnly(p['discovered_at'])),
          _row('Vérifié le', p['last_verified_at'] == null ? '' : dOnly(p['last_verified_at'])),
          const SizedBox(height: 6),
          DropdownButtonFormField<String>(
            value: _statusLabels.containsKey(p['status']) ? '${p['status']}' : null,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Statut de prospection', border: OutlineInputBorder()),
            items: [for (final e in _statusLabels.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value))],
            onChanged: (v) {
              if (v != null) _setStatus(v);
            },
          ),
        ]),
        const SizedBox(height: 6),
        FilledButton.icon(onPressed: () async => _inviteFlow(context, [p]), icon: const Icon(Icons.send), label: const Text('INVITER SUR MAYA')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: _unsubscribe, icon: const Icon(Icons.block, color: maliRed), label: const Text('Marquer comme désinscrit')),
      ]),
    );
  }
}

// ---------- 4. Campagnes ----------

class _CampaignsTab extends StatefulWidget {
  const _CampaignsTab();
  @override
  State<_CampaignsTab> createState() => _CampaignsTabState();
}

class _CampaignsTabState extends State<_CampaignsTab> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async {
    final r = await sb.from('seller_campaigns').select('*, seller_invitations(count)').order('created_at', ascending: false).limit(100);
    return List<Map<String, dynamic>>.from(r);
  }

  Future<void> _cancel(Map<String, dynamic> c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Annuler la campagne ?'),
        content: const Text('Les invitations non envoyées de cette campagne seront annulées.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Non')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Annuler la campagne')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('seller_invitations').update({'status': 'cancelled'}).eq('campaign_id', c['id']).eq('status', 'prepared');
      await sb.from('seller_campaigns').update({'status': 'cancelled'}).eq('id', c['id']);
      if (mounted) setState(() => _f = _load());
    });
  }

  int _n(Map<String, dynamic> c) {
    final l = c['seller_invitations'];
    if (l is List && l.isNotEmpty && l.first is Map) return (l.first as Map)['count'] is int ? (l.first as Map)['count'] as int : 0;
    return 0;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return _err(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('Aucune campagne. Sélectionnez des prospects puis « Inviter ».'));
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final c = list[i];
                return ListTile(
                  title: Text('${c['name']}'),
                  subtitle: Text('${_channels[c['channel']] ?? c['channel']} · ${_langs[c['language']] ?? c['language']} · ${_n(c)} invitation(s)\n${c['status']} · ${dt(c['created_at'])}'),
                  isThreeLine: true,
                  trailing: (c['status'] == 'cancelled')
                      ? null
                      : IconButton(tooltip: 'Annuler', icon: const Icon(Icons.cancel_outlined, color: maliRed), onPressed: () => _cancel(c)),
                );
              },
            ),
          );
        },
      );
}

// ---------- 5. Invitations ----------

class _InvitationsTab extends StatefulWidget {
  const _InvitationsTab();
  @override
  State<_InvitationsTab> createState() => _InvitationsTabState();
}

class _InvitationsTabState extends State<_InvitationsTab> {
  String? _status;
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async {
    var q = sb.from('seller_invitations').select('*, seller_prospects(shop_name, whatsapp, email, country_code)');
    if (_status != null) q = q.eq('status', _status!);
    final r = await q.order('created_at', ascending: false).limit(200);
    return List<Map<String, dynamic>>.from(r);
  }

  void _reload() => setState(() => _f = _load());

  Future<void> _set(Map<String, dynamic> inv, String status) async {
    await guarded(context, () async {
      final upd = <String, dynamic>{'status': status};
      if (status == 'sent') upd['sent_at'] = _nowIso();
      if (status == 'replied') upd['replied_at'] = _nowIso();
      await sb.from('seller_invitations').update(upd).eq('id', inv['id']);
      await sb.from('seller_invitation_events').insert({'invitation_id': inv['id'], 'event_type': status, 'actor_id': uid});
      const map = <String, String>{'sent': 'invitation_envoyee', 'replied': 'a_repondu', 'registering': 'inscription_commencee', 'registered': 'inscription_terminee'};
      final ps = map[status];
      if (ps != null) await sb.from('seller_prospects').update({'status': ps}).eq('id', inv['prospect_id']);
      if (mounted) _reload();
    });
  }

  Future<void> _send(Map<String, dynamic> inv) async {
    final p = (inv['seller_prospects'] is Map) ? Map<String, dynamic>.from(inv['seller_prospects'] as Map) : <String, dynamic>{};
    final msg = '${inv['message'] ?? ''}';
    final ch = '${inv['channel']}';
    String? url;
    if (ch == 'whatsapp' && _digits(p['whatsapp']).length >= 7) {
      url = 'https://wa.me/${_digits(p['whatsapp'])}?text=${Uri.encodeComponent(msg)}';
    } else if (ch == 'email' && '${p['email'] ?? ''}'.isNotEmpty) {
      url = 'mailto:${p['email']}?subject=${Uri.encodeComponent('Invitation à rejoindre MAYA')}&body=${Uri.encodeComponent(msg)}';
    }
    if (url == null) {
      await Clipboard.setData(ClipboardData(text: msg));
      if (mounted) snack(context, 'Message copié : collez-le dans Instagram, Facebook ou ailleurs.');
    } else {
      await _open(context, url);
    }
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
          child: DropdownButtonFormField<String>(
            value: _status,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Statut', border: OutlineInputBorder()),
            items: [const DropdownMenuItem<String>(value: null, child: Text('Tous')), for (final e in _invStatusLabels.entries) DropdownMenuItem<String>(value: e.key, child: Text(e.value))],
            onChanged: (v) {
              _status = v;
              _reload();
            },
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return _err(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!;
              if (list.isEmpty) return const Center(child: Text('Aucune invitation.'));
              return RefreshIndicator(
                onRefresh: () async => _reload(),
                child: ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final inv = list[i];
                    final p = (inv['seller_prospects'] is Map) ? Map<String, dynamic>.from(inv['seller_prospects'] as Map) : <String, dynamic>{};
                    final st = '${inv['status']}';
                    final open = st == 'prepared' || st == 'sent';
                    return ListTile(
                      title: Text('${p['shop_name'] ?? 'Prospect'}'),
                      subtitle: Text('${_channels[inv['channel']] ?? inv['channel']} · ${_invStatusLabels[st] ?? st}\n${dt(inv['sent_at'] ?? inv['prepared_at'])}'),
                      isThreeLine: true,
                      trailing: PopupMenuButton<String>(
                        onSelected: (v) async {
                          if (v == 'open') {
                            await _send(inv);
                          } else if (v == 'copy') {
                            await Clipboard.setData(ClipboardData(text: '$_joinBase${inv['join_token']}'));
                            if (mounted) snack(context, 'Lien d\'inscription copié.');
                          } else {
                            await _set(inv, v);
                          }
                        },
                        itemBuilder: (_) => [
                          if (open) const PopupMenuItem(value: 'open', child: Text('Ouvrir le message')),
                          const PopupMenuItem(value: 'copy', child: Text('Copier le lien d\'inscription')),
                          if (st == 'prepared') const PopupMenuItem(value: 'sent', child: Text('Marquer comme envoyée')),
                          if (st != 'cancelled' && st != 'prepared') const PopupMenuItem(value: 'replied', child: Text('A répondu')),
                          if (st != 'cancelled' && st != 'prepared') const PopupMenuItem(value: 'registering', child: Text('Inscription commencée')),
                          if (st != 'cancelled' && st != 'prepared') const PopupMenuItem(value: 'registered', child: Text('Inscription terminée')),
                          if (st == 'prepared') const PopupMenuItem(value: 'cancelled', child: Text('Annuler')),
                        ],
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ]);
}

// ---------- 6. Vendeurs recrutés ----------

class _RecruitedTab extends StatefulWidget {
  const _RecruitedTab();
  @override
  State<_RecruitedTab> createState() => _RecruitedTabState();
}

class _RecruitedTabState extends State<_RecruitedTab> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async {
    final r = await sb
        .from('seller_prospects')
        .select()
        .inFilter('status', ['inscription_commencee', 'inscription_terminee', 'en_attente_verification', 'vendeur_valide'])
        .order('updated_at', ascending: false)
        .limit(200);
    return List<Map<String, dynamic>>.from(r);
  }

  Future<void> _validate(Map<String, dynamic> p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Valider ce vendeur ?'),
        content: const Text('Vous confirmez avoir vérifié ses informations et ses documents. Son compte vendeur reste géré dans « Vendeurs et retraits ».'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Valider')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('seller_prospects').update({'status': 'vendeur_valide'}).eq('id', p['id']);
      if (mounted) setState(() => _f = _load());
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return _err(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) return const Center(child: Text('Aucun vendeur recruté pour l\'instant.'));
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView.separated(
              itemCount: list.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final p = list[i];
                return ListTile(
                  title: Text('${p['shop_name']}'),
                  subtitle: Text('${_cname(p['country_code'])} · ${_statusLabels[p['status']] ?? p['status']}'),
                  trailing: p['status'] == 'vendeur_valide'
                      ? const Icon(Icons.verified, color: maliGreen)
                      : TextButton(onPressed: () => _validate(p), child: const Text('Valider')),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _ProspectDetail(p))).then((_) => setState(() => _f = _load())),
                );
              },
            ),
          );
        },
      );
}

// ---------- 7. Statistiques ----------

class _StatsTab extends StatefulWidget {
  const _StatsTab();
  @override
  State<_StatsTab> createState() => _StatsTabState();
}

class _StatsTabState extends State<_StatsTab> {
  late Future<List<List<Map<String, dynamic>>>> _f = _load();
  Future<List<List<Map<String, dynamic>>>> _load() async =>
      [await _rows('seller_prospects', 'status,country_code,category,priority,discovery_source'), await _rows('seller_invitations', 'status')];

  @override
  Widget build(BuildContext context) => FutureBuilder<List<List<Map<String, dynamic>>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return _err(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final ps = snap.data![0];
          final iv = _count(snap.data![1], 'status');
          final sent = ['sent', 'delivered', 'clicked', 'replied', 'registering', 'registered'].fold<int>(0, (a, b) => a + (iv[b] ?? 0));
          final replied = ['replied', 'registering', 'registered'].fold<int>(0, (a, b) => a + (iv[b] ?? 0));
          final reg = iv['registered'] ?? 0;
          String pct(int a, int b) => b == 0 ? '—' : '${(a * 100 / b).round()} %';
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              Section('Entonnoir d\'invitation', [
                Text('Envoyées : $sent'),
                Text('Réponses : $replied (${pct(replied, sent)})'),
                Text('Inscriptions terminées : $reg (${pct(reg, sent)})'),
              ]),
              Section('Prospects par pays', [_bars(_count(ps, 'country_code'), label: _cname)]),
              Section('Prospects par catégorie', [_bars(_count(ps, 'category'))]),
              Section('Par priorité', [_bars(_count(ps, 'priority'), label: (k) => _priorityLabels[k] ?? k)]),
              Section('Par statut', [_bars(_count(ps, 'status'), label: (k) => _statusLabels[k] ?? k)]),
              Section('Par source', [_bars(_count(ps, 'discovery_source'))]),
            ]),
          );
        },
      );
}

// ---------- 8. Paramètres ----------

class _SettingsTab extends StatefulWidget {
  const _SettingsTab();
  @override
  State<_SettingsTab> createState() => _SettingsTabState();
}

class _SettingsTabState extends State<_SettingsTab> {
  late Future<List<dynamic>> _f = _load();
  Future<List<dynamic>> _load() async => [
        await _categories(),
        List<Map<String, dynamic>>.from(await sb.from('seller_message_templates').select().order('name').order('language')),
        List<Map<String, dynamic>>.from(await sb.from('seller_unsubscribes').select().order('created_at', ascending: false).limit(100)),
      ];

  void _reload() => setState(() => _f = _load());

  Future<void> _addCategory() async {
    final label = await askText(context, 'Nouvelle catégorie', multiline: false);
    if (label == null || label.length < 2 || !mounted) return;
    await guarded(context, () async {
      var slug = _slug(label);
      if (slug.isEmpty) slug = 'cat_${DateTime.now().millisecondsSinceEpoch}';
      await sb.from('seller_categories').insert({'slug': slug, 'label_fr': label, 'sort_order': 100});
      if (mounted) _reload();
    });
  }

  Future<void> _toggleCategory(Map<String, dynamic> c) async {
    await guarded(context, () async {
      await sb.from('seller_categories').update({'active': c['active'] != true}).eq('slug', c['slug']);
      if (mounted) _reload();
    });
  }

  Future<void> _editTemplate(Map<String, dynamic> t) async {
    final ctrl = TextEditingController(text: '${t['body']}');
    final v = await showDialog<String>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('Modèle (${_langs[t['language']] ?? t['language']})'),
        content: SizedBox(
          width: double.maxFinite,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const Text('Variables : {{shop_name}} {{owner_name}} {{country}} {{category}} {{join_link}}', style: TextStyle(fontSize: 11)),
            const SizedBox(height: 8),
            TextField(controller: ctrl, maxLines: 12, minLines: 6, decoration: const InputDecoration(border: OutlineInputBorder())),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (v == null || v.trim().isEmpty || !mounted) return;
    await guarded(context, () async {
      await sb.from('seller_message_templates').update({'body': v}).eq('id', t['id']);
      if (mounted) _reload();
    });
  }

  Future<void> _addUnsub() async {
    final v = await askText(context, 'Numéro WhatsApp ou e-mail à ne plus contacter', multiline: false);
    if (v == null || v.isEmpty || !mounted) return;
    await guarded(context, () async {
      final isMail = v.contains('@');
      await sb.from('seller_unsubscribes').upsert({
        'channel': isMail ? 'email' : 'whatsapp',
        'contact_value': isMail ? v.toLowerCase() : _digits(v),
        'reason': 'Ajout manuel',
      }, onConflict: 'channel,contact_value');
      if (mounted) _reload();
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return _err(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final cats = List<Map<String, dynamic>>.from(snap.data![0] as List);
          final tpls = List<Map<String, dynamic>>.from(snap.data![1] as List);
          final uns = List<Map<String, dynamic>>.from(snap.data![2] as List);
          return ListView(padding: const EdgeInsets.all(12), children: [
            Section('Catégories', [
              for (final c in cats)
                Row(children: [
                  Expanded(child: Text('${c['label_fr']}', style: TextStyle(color: c['active'] == true ? null : Colors.grey))),
                  Switch(value: c['active'] == true, onChanged: (_) => _toggleCategory(c)),
                ]),
              OutlinedButton.icon(onPressed: _addCategory, icon: const Icon(Icons.add), label: const Text('Ajouter une catégorie')),
            ]),
            Section('Modèles d\'invitation', [
              for (final t in tpls)
                ListTile(
                  contentPadding: EdgeInsets.zero,
                  title: Text('${t['name']} · ${_langs[t['language']] ?? t['language']}'),
                  subtitle: Text('${t['body']}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  trailing: const Icon(Icons.edit_outlined),
                  onTap: () => _editTemplate(t),
                ),
            ]),
            Section('Liste de désinscription', [
              if (uns.isEmpty) const Text('Aucun contact désinscrit.'),
              for (final u in uns) Text('${u['channel']} · ${u['contact_value']}'),
              const SizedBox(height: 6),
              OutlinedButton.icon(onPressed: _addUnsub, icon: const Icon(Icons.block), label: const Text('Ajouter un contact à ne plus contacter')),
            ]),
            const Section('Conformité', [
              Text('N\'enregistrez que des informations publiques. Respectez les règles des plateformes, le consentement, les limites de fréquence et les demandes de désinscription. '
                  'Aucun envoi massif non sollicité.', style: TextStyle(fontSize: 12)),
            ]),
          ]);
        },
      );
}
