import 'package:flutter/material.dart';
import 'client.dart' show NotificationsPage, DeliveriesPage;
import 'common.dart';
import 'delivery_courier.dart' show MyDeliveriesScreen, CarrierSpaceScreen, JoinDeliveryScreen;
import 'guest.dart';
import 'my_shop.dart' show ProductDetailPage, ShopPage;
import 'seller_apply.dart' show startSellerFlow;
import 'shop_media.dart' show storageUrl;
import 'seller_products.dart' show productImageUrl;

/// Envoie un message au chat MAYA (les commandes sont traitées par l'administration).
Future<void> messageAdmin(BuildContext c, String text) async {
  // Passer une commande exige un compte : fenêtre « Se connecter / Créer un compte » pour un visiteur.
  if (!await requireAuth(c, reason: 'Connectez-vous ou créez un compte pour passer commande.')) return;
  if (!c.mounted) return;
  await guarded(c, () async {
      final conv = await sb.from('conversations').select('id').eq('client_id', uid).single();
      await sb.from('messages').insert({
        'conversation_id': conv['id'],
        'sender_id': uid,
        'kind': 'text',
        'body': text,
        'client_msg_id': 'app-${DateTime.now().microsecondsSinceEpoch}',
      });
      if (c.mounted) snack(c, 'Message envoyé à MAYA. Nous revenons vers vous très vite.');
    });
}

/// Favoris : chargés une seule fois par session ; l'ajout exige un compte.
class FavStore {
  static final ValueNotifier<Set<String>> ids = ValueNotifier<Set<String>>(<String>{});
  static bool _loaded = false, _listening = false;

  static void _listen() {
    if (_listening) return;
    _listening = true;
    sb.auth.onAuthStateChange.listen((_) {
      _loaded = false;
      ids.value = <String>{};
    });
  }

  static Future<void> ensureLoaded() async {
    _listen();
    if (_loaded || sb.auth.currentUser == null) return;
    _loaded = true;
    try {
      final rows = await sb.from('favorites').select('product_id').eq('user_id', uid);
      ids.value = {for (final r in rows as List) '${(r as Map)['product_id']}'};
    } catch (_) {
      _loaded = false;
    }
  }

  static Future<void> toggle(BuildContext c, String productId) async {
    if (!await requireAuth(c, reason: 'Connectez-vous ou créez un compte pour ajouter ce produit à vos favoris.')) return;
    await ensureLoaded();
    final on = ids.value.contains(productId);
    try {
      if (on) {
        await sb.from('favorites').delete().eq('user_id', uid).eq('product_id', productId);
        ids.value = {...ids.value}..remove(productId);
      } else {
        await sb.from('favorites').upsert({'user_id': uid, 'product_id': productId});
        ids.value = {...ids.value, productId};
      }
    } catch (e) {
      if (c.mounted) snack(c, 'Erreur : $e');
    }
  }
}

class FavoriteButton extends StatefulWidget {
  final String productId;
  final double size;
  const FavoriteButton({super.key, required this.productId, this.size = 32});
  @override
  State<FavoriteButton> createState() => _FavoriteButtonState();
}

class _FavoriteButtonState extends State<FavoriteButton> {
  @override
  void initState() {
    super.initState();
    FavStore.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) => ValueListenableBuilder<Set<String>>(
        valueListenable: FavStore.ids,
        builder: (_, set, __) {
          final on = set.contains(widget.productId);
          return InkWell(
            customBorder: const CircleBorder(),
            onTap: () => FavStore.toggle(context, widget.productId),
            child: Container(
              width: widget.size,
              height: widget.size,
              decoration: const BoxDecoration(color: Colors.white, shape: BoxShape.circle, boxShadow: [BoxShadow(color: Color(0x22000000), blurRadius: 4)]),
              child: Icon(on ? Icons.favorite : Icons.favorite_border, size: widget.size * 0.6, color: on ? maliRed : Colors.black54),
            ),
          );
        },
      );
}

const _green2 = Color(0xFF14B53A);

/// Accueil client, conforme à la maquette : bannière, accès rapides, catégories, meilleures offres.
class ShopHome extends StatefulWidget {
  final void Function(int tab) onGo; // 0 accueil, 1 catégories, 2 favoris, 3 commandes, 4 compte
  final VoidCallback onContact;
  const ShopHome({super.key, required this.onGo, required this.onContact});
  @override
  State<ShopHome> createState() => _ShopHomeState();
}

class _ShopHomeState extends State<ShopHome> {
  late Future<List<List<Map<String, dynamic>>>> _f = _load();
  final _search = TextEditingController();

  Future<List<List<Map<String, dynamic>>>> _load() async {
    final cats = await sb.from('categories').select().eq('active', true).order('position');
    final offers = await sb.from('products').select().eq('status', 'approved').not('promo_price', 'is', null).order('created_at', ascending: false).limit(8);
    final fresh = await sb.from('products').select().eq('status', 'approved').order('created_at', ascending: false).limit(8);
    final shops = await sb.from('shops').select('id, slug, name, logo_path, city').eq('status', 'active').order('created_at', ascending: false).limit(12);
    return [List<Map<String, dynamic>>.from(cats), List<Map<String, dynamic>>.from(offers), List<Map<String, dynamic>>.from(fresh), List<Map<String, dynamic>>.from(shops)];
  }

  void _openSearch([String? category, String? categoryName]) => Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => ProductsScreen(initialQuery: _search.text.trim(), categoryId: category, title: categoryName ?? 'Produits')));

  Future<void> _becomeSeller() => startSellerFlow(context);

  Widget _quick(IconData i, Color c, String label, VoidCallback onTap) => Expanded(
        child: Material(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          elevation: 1,
          child: InkWell(
            borderRadius: BorderRadius.circular(18),
            onTap: onTap,
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 4),
              child: Column(children: [
                Container(
                  width: 46,
                  height: 46,
                  decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(14)),
                  child: Icon(i, color: Colors.white, size: 26),
                ),
                const SizedBox(height: 6),
                Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, height: 1.15)),
              ]),
            ),
          ),
        ),
      );

  Widget _banner() => Container(
        height: 190,
        margin: const EdgeInsets.only(bottom: 12),
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(22),
          gradient: const LinearGradient(colors: [brandDark, brand]),
        ),
        child: Stack(children: [
          Positioned(right: 0, top: 0, bottom: 0, width: 210, child: Image.asset('assets/hero.jpg', fit: BoxFit.cover, alignment: Alignment.centerLeft)),
          Positioned.fill(
              child: DecoratedBox(
                  decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [brandDark, brandDark.withOpacity(0.92), Colors.transparent], stops: const [0, 0.55, 0.85])))),
          Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('MAYA', style: TextStyle(color: Colors.white, fontSize: 30, fontWeight: FontWeight.w900, letterSpacing: 1)),
              const Text('Le commerce,', style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w800)),
              const Text('plus proche de vous !', style: TextStyle(color: maliGold, fontSize: 16, fontWeight: FontWeight.w800)),
              const SizedBox(height: 6),
              for (final t in ['Produits de qualité', 'Vendeurs vérifiés', 'Livraison partout au Mali'])
                Row(children: [
                  const Icon(Icons.check_circle, color: _green2, size: 15),
                  const SizedBox(width: 5),
                  Text(t, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
                ]),
              const Spacer(),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: gold, minimumSize: const Size(0, 38), shape: const StadiumBorder()),
                onPressed: _openSearch,
                icon: const Icon(Icons.arrow_forward, size: 18),
                label: const Text('Commencer'),
                iconAlignment: IconAlignment.end,
              ),
            ]),
          ),
        ]),
      );

  @override
  Widget build(BuildContext context) => FutureBuilder<List<List<Map<String, dynamic>>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final cats = snap.data![0], offers = snap.data![1], fresh = snap.data![2], shops = snap.data![3];
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView(padding: const EdgeInsets.fromLTRB(12, 10, 12, 16), children: [
              TextField(
                controller: _search,
                textInputAction: TextInputAction.search,
                onSubmitted: (_) => _openSearch(),
                decoration: InputDecoration(
                  prefixIcon: const Icon(Icons.search),
                  hintText: 'Rechercher un produit, une boutique…',
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 12),
              _banner(),
              Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                _quick(Icons.shopping_cart, _green2, 'Acheter\nmaintenant', _openSearch),
                const SizedBox(width: 8),
                _quick(Icons.storefront, gold, 'Devenir\nvendeur', _becomeSeller),
                const SizedBox(width: 8),
                _quick(Icons.local_shipping, const Color(0xFF1F5BFF), 'Suivre ma\ncommande', () => widget.onGo(3)),
                const SizedBox(width: 8),
                _quick(Icons.headset_mic, const Color(0xFF7B3FE4), 'Nous\ncontacter', widget.onContact),
              ]),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                    gradient: const LinearGradient(colors: [Color(0xFFFF7A00), Color(0xFFFFA23A)]), borderRadius: BorderRadius.circular(18)),
                child: Row(children: [
                  const Icon(Icons.storefront, color: Colors.white, size: 34),
                  const SizedBox(width: 12),
                  const Expanded(
                      child: Text('Vous vendez ? Ouvrez votre boutique sur MAYA et touchez des clients partout au Mali.',
                          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13, height: 1.25))),
                  const SizedBox(width: 8),
                  FilledButton(
                    style: FilledButton.styleFrom(backgroundColor: Colors.white, foregroundColor: brandDark, minimumSize: const Size(0, 40), padding: const EdgeInsets.symmetric(horizontal: 12)),
                    onPressed: _becomeSeller,
                    child: const Text('Devenir vendeur', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 12)),
                  ),
                ]),
              ),
              const SizedBox(height: 14),
              _head('Catégories', 'Voir toutes', () => widget.onGo(1), _green2),
              SizedBox(
                height: 104,
                child: ListView(scrollDirection: Axis.horizontal, children: [
                  for (final c in cats)
                    InkWell(
                      onTap: () => _openSearch(c['id'] as String, c['name'] as String),
                      child: SizedBox(
                        width: 86,
                        child: Column(children: [
                          CircleAvatar(radius: 32, backgroundColor: const Color(0xFFFFF1CF), child: Text('${c['icon']}', style: const TextStyle(fontSize: 30))),
                          const SizedBox(height: 4),
                          Text('${c['name']}', textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                        ]),
                      ),
                    ),
                ]),
              ),
              _head('🔥 Nos meilleures offres', 'Voir plus', _openSearch, gold),
              if (offers.isEmpty)
                const Padding(padding: EdgeInsets.all(16), child: Text('Les offres du moment arrivent bientôt.', textAlign: TextAlign.center)),
              if (offers.isNotEmpty)
                SizedBox(
                  height: 214,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final p in offers) SizedBox(width: 150, child: ProductCard(product: p)),
                  ]),
                ),
              if (shops.isNotEmpty) ...[
                _head('🏪 Nos boutiques', 'Toutes', () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ShopsDirectoryScreen())), brand),
                SizedBox(
                  height: 112,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final s in shops)
                      InkWell(
                        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopPage(slug: '${s['slug']}'))),
                        child: SizedBox(
                          width: 92,
                          child: Column(children: [
                            CircleAvatar(
                              radius: 32,
                              backgroundColor: const Color(0xFFE6F2E6),
                              backgroundImage: storageUrl('shop-assets', s['logo_path'] as String?) == null ? null : NetworkImage(storageUrl('shop-assets', s['logo_path'] as String?)!),
                              child: s['logo_path'] == null ? const Icon(Icons.storefront, color: brandDark) : null,
                            ),
                            const SizedBox(height: 4),
                            Text('${s['name']}', textAlign: TextAlign.center, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                          ]),
                        ),
                      ),
                  ]),
                ),
              ],
              if (fresh.isNotEmpty) ...[
                _head('✨ Nouveautés', 'Voir plus', _openSearch, _green2),
                SizedBox(
                  height: 214,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final p in fresh) SizedBox(width: 150, child: ProductCard(product: p)),
                  ]),
                ),
              ],
              const SizedBox(height: 8),
              Center(
                child: TextButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutMayaScreen())),
                  icon: const Icon(Icons.info_outline, size: 18),
                  label: const Text('À propos de MAYA · comment ça marche'),
                ),
              ),
            ]),
          );
        },
      );

  Widget _head(String t, String more, VoidCallback onMore, Color c) => Padding(
        padding: const EdgeInsets.only(bottom: 6, top: 4),
        child: Row(children: [
          Expanded(child: Text(t, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800))),
          TextButton(onPressed: onMore, style: TextButton.styleFrom(backgroundColor: c.withOpacity(0.15), foregroundColor: c), child: Text('$more →')),
        ]),
      );
}

class ProductCard extends StatelessWidget {
  final Map<String, dynamic> product;
  const ProductCard({super.key, required this.product});

  @override
  Widget build(BuildContext context) {
    final p = product;
    final price = n(p['price']), promo = p['promo_price'] == null ? null : n(p['promo_price']);
    final shown = promo ?? price;
    final pct = promo != null && price > 0 ? ((1 - promo / price) * 100).round() : 0;
    return Card(
      margin: const EdgeInsets.only(right: 8, bottom: 4),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(productId: '${p['id']}'))),
        child: Padding(
        padding: const EdgeInsets.all(8),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Expanded(
            child: Stack(children: [
              Positioned.fill(
                child: productImageUrl(p) == null
                    ? const Center(child: Icon(Icons.shopping_bag_outlined, size: 56, color: Color(0xFFB8C9B8)))
                    : ClipRRect(
                        borderRadius: BorderRadius.circular(12),
                        child: Image.network(productImageUrl(p)!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image))),
              ),
              Positioned(left: 0, top: 0, child: FavoriteButton(productId: '${p['id']}', size: 30)),
              if (pct > 0)
                Positioned(
                    right: 0,
                    top: 0,
                    child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(color: _green2, borderRadius: BorderRadius.circular(10)),
                        child: Text('-$pct%', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12)))),
            ]),
          ),
          Text('${p['name']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          const SizedBox(height: 4),
          Row(children: [
            Expanded(child: Text(money(shown, 'FCFA').replaceAll('XOF', 'FCFA'), style: const TextStyle(fontWeight: FontWeight.w800, color: brandDark, fontSize: 13))),
            InkWell(
              onTap: () => messageAdmin(context, 'Je souhaite commander : ${p['name']} (${money(shown)}).'),
              child: const CircleAvatar(radius: 16, backgroundColor: brand, child: Icon(Icons.shopping_cart_outlined, size: 17, color: Colors.white)),
            ),
          ]),
        ]),
      ),
      ),
    );
  }
}

class ProductsScreen extends StatefulWidget {
  final String initialQuery;
  final String? categoryId;
  final String title;
  const ProductsScreen({super.key, this.initialQuery = '', this.categoryId, this.title = 'Produits'});
  @override
  State<ProductsScreen> createState() => _ProductsScreenState();
}

class _ProductsScreenState extends State<ProductsScreen> {
  late final _q = TextEditingController(text: widget.initialQuery);
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    var q = sb.from('products').select().eq('status', 'approved');
    if (widget.categoryId != null) q = q.eq('category_id', widget.categoryId!);
    final t = _q.text.trim().replaceAll(RegExp(r'[%,()]'), '');
    if (t.isNotEmpty) q = q.ilike('name', '%$t%');
    return List<Map<String, dynamic>>.from(await q.order('created_at', ascending: false).limit(100));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _q,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => setState(() => _f = _load()),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher…', border: OutlineInputBorder()),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _f,
              builder: (context, snap) {
                if (snap.hasError) return errorView(snap.error);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                if (snap.data!.isEmpty) return const Center(child: Text('Aucun produit pour le moment.'));
                return GridView(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 230, childAspectRatio: 0.78),
                  padding: const EdgeInsets.all(8),
                  children: [for (final p in snap.data!) ProductCard(product: p)],
                );
              },
            ),
          ),
        ]),
      );
}

class CategoriesScreen extends StatelessWidget {
  const CategoriesScreen({super.key});
  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: sb.from('categories').select().eq('active', true).order('position'),
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final cats = List<Map<String, dynamic>>.from(snap.data!);
          return GridView(
            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 140, mainAxisSpacing: 12, crossAxisSpacing: 12),
            padding: const EdgeInsets.all(12),
            children: [
              for (final c in cats)
                InkWell(
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductsScreen(categoryId: c['id'] as String, title: '${c['name']}'))),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    CircleAvatar(radius: 34, backgroundColor: const Color(0xFFFFF1CF), child: Text('${c['icon']}', style: const TextStyle(fontSize: 32))),
                    const SizedBox(height: 6),
                    Text('${c['name']}', textAlign: TextAlign.center, maxLines: 2, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                  ]),
                ),
            ],
          );
        },
      );
}

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  late final Future<List<dynamic>> _f = sb.from('favorites').select('products(*)').eq('user_id', uid);
  @override
  Widget build(BuildContext context) => FutureBuilder<List<dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final items = [for (final r in snap.data!) if (r['products'] != null) Map<String, dynamic>.from(r['products'] as Map)];
          if (items.isEmpty) return const Center(child: Text('Aucun favori pour le moment.'));
          return GridView(gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 230, childAspectRatio: 0.78), padding: const EdgeInsets.all(8), children: [for (final p in items) ProductCard(product: p)]);
        },
      );
}

/// Cloche de notifications avec pastille du nombre d'alertes non lues.
class NotifBell extends StatelessWidget {
  const NotifBell({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<List<Map<String, dynamic>>>(
        stream: sb.from('notifications').stream(primaryKey: ['id']).eq('user_id', uid),
        builder: (context, snap) {
          final unread = (snap.data ?? []).where((x) => x['read_at'] == null).length;
          return IconButton(
            tooltip: 'Notifications',
            icon: Badge(isLabelVisible: unread > 0, label: Text('$unread'), child: const Icon(Icons.notifications_none)),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage())),
          );
        },
      );
}

/// Menu « Mon compte » : factures, paiements, livraisons, messages, profil.
class AccountHub extends StatelessWidget {
  final VoidCallback onMessages, onInvoices;
  final Widget profile;
  const AccountHub({super.key, required this.onMessages, required this.onInvoices, required this.profile});
  @override
  Widget build(BuildContext context) => Column(children: [
        ListTile(leading: const Icon(Icons.chat_bubble_outline), title: const Text('Messages avec MAYA'), onTap: onMessages),
        ListTile(leading: const Icon(Icons.receipt_long_outlined), title: const Text('Mes factures'), onTap: onInvoices),
        ListTile(leading: const Icon(Icons.local_shipping_outlined), title: const Text('Mes livraisons'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DeliveriesPage()))),
        ListTile(leading: const Icon(Icons.my_location, color: brand), title: const Text('Suivre mes colis'), subtitle: const Text('Carte, statut et contact du livreur'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MyDeliveriesScreen()))),
        ListTile(leading: const Icon(Icons.delivery_dining), title: const Text('Espace transporteur MAYA'), subtitle: const Text('Recevoir des missions de livraison'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CarrierSpaceScreen()))),
        ListTile(leading: const Icon(Icons.vpn_key_outlined), title: const Text('Rejoindre une livraison'), subtitle: const Text('Livreur invité par un vendeur : code + PIN'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const JoinDeliveryScreen()))),
        ListTile(leading: const Icon(Icons.storefront_outlined, color: gold), title: const Text('Devenir vendeur'), subtitle: const Text('Demande de boutique et suivi de validation'), onTap: () => startSellerFlow(context)),
        ListTile(leading: const Icon(Icons.info_outline), title: const Text('À propos de MAYA'), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutMayaScreen()))),
        const Divider(height: 1),
        Expanded(child: profile),
      ]);
}


/// Annuaire public de toutes les boutiques actives (consultable sans compte).
class ShopsDirectoryScreen extends StatefulWidget {
  const ShopsDirectoryScreen({super.key});
  @override
  State<ShopsDirectoryScreen> createState() => _ShopsDirectoryScreenState();
}

class _ShopsDirectoryScreenState extends State<ShopsDirectoryScreen> {
  final _q = TextEditingController();
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    var q = sb.from('shops').select('id, slug, name, description, logo_path, banner_path, city').eq('status', 'active');
    final t = _q.text.trim().replaceAll(RegExp(r'[%,()]'), '');
    if (t.isNotEmpty) q = q.ilike('name', '%$t%');
    return List<Map<String, dynamic>>.from(await q.order('created_at', ascending: false).limit(200));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Boutiques')),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: TextField(
              controller: _q,
              textInputAction: TextInputAction.search,
              onSubmitted: (_) => setState(() => _f = _load()),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher une boutique…', border: OutlineInputBorder()),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, dynamic>>>(
              future: _f,
              builder: (context, snap) {
                if (snap.hasError) return errorView(snap.error);
                if (!snap.hasData) return const Center(child: CircularProgressIndicator());
                if (snap.data!.isEmpty) return const Center(child: Text('Aucune boutique pour le moment.'));
                return GridView(
                  gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: 420, mainAxisExtent: 92, crossAxisSpacing: 8, mainAxisSpacing: 8),
                  padding: const EdgeInsets.all(8),
                  children: [
                    for (final s in snap.data!)
                      Material(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                        child: InkWell(
                          borderRadius: BorderRadius.circular(16),
                          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopPage(slug: '${s['slug']}'))),
                          child: Padding(
                            padding: const EdgeInsets.all(10),
                            child: Row(children: [
                              CircleAvatar(
                                radius: 30,
                                backgroundColor: const Color(0xFFE6F2E6),
                                backgroundImage: storageUrl('shop-assets', s['logo_path'] as String?) == null ? null : NetworkImage(storageUrl('shop-assets', s['logo_path'] as String?)!),
                                child: s['logo_path'] == null ? const Icon(Icons.storefront, color: brandDark) : null,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text('${s['name']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
                                  if ('${s['city'] ?? ''}'.isNotEmpty) Text('📍 ${s['city']}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
                                  if ('${s['description'] ?? ''}'.isNotEmpty) Text('${s['description']}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12)),
                                ]),
                              ),
                              const Icon(Icons.chevron_right),
                            ]),
                          ),
                        ),
                      ),
                  ],
                );
              },
            ),
          ),
        ]),
      );
}
