import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart' show FileOptions;
import 'common.dart';
import 'delivery_common.dart';
import 'delivery_mission.dart';

List<Map<String, dynamic>> _rows(dynamic v) =>
    v is List ? List<Map<String, dynamic>>.from(v.map((e) => Map<String, dynamic>.from(e as Map))) : <Map<String, dynamic>>[];

String _groups(String t) => RegExp(r'.{1,4}').allMatches(t).map((m) => m.group(0)).join('-');

/// Message d'invitation du livreur. Le code et le PIN sont à usage unique, valables 48 h, révocables.
String inviteMessage({required String orderNumber, required String token, required String pin, required String courierName}) =>
    'Bonjour $courierName, vous êtes désigné(e) pour livrer la commande $orderNumber sur MAYA.\n'
    '1) Ouvrez l\'application MAYA et créez un compte (ou connectez-vous) avec ce numéro.\n'
    '2) Compte > « Rejoindre une livraison ».\n'
    '3) Code : ${_groups(token)}  —  PIN : $pin\n'
    'Valable 48 h, une seule personne. Ne partagez pas ce message.';

/// Affiche le code d'invitation et permet de l'envoyer par SMS, WhatsApp ou de le copier.
Future<void> showInviteDialog(BuildContext context,
    {required String courierName, required String courierPhone, required String orderNumber, required String token, required String pin, dynamic expiresAt}) {
  final msg = inviteMessage(orderNumber: orderNumber, token: token, pin: pin, courierName: courierName);
  return showDialog<void>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Invitation du livreur'),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('Ce code et ce PIN ne seront plus affichés. Envoyez-les maintenant au livreur.', style: TextStyle(fontSize: 12.5)),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: const Color(0xFFF1F6F1), borderRadius: BorderRadius.circular(10)),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              SelectableText('Code : ${_groups(token)}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              SelectableText('PIN : $pin', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              if (expiresAt != null) Text('Valable jusqu\'au ${dt(expiresAt)}', style: const TextStyle(fontSize: 11.5)),
            ]),
          ),
          const SizedBox(height: 10),
          if (courierPhone.isNotEmpty) ...[
            FilledButton.icon(icon: const Icon(Icons.sms_outlined), label: const Text('Envoyer par SMS'), onPressed: () => openSms(ctx, courierPhone, msg)),
            const SizedBox(height: 6),
            OutlinedButton.icon(icon: const Icon(Icons.chat), label: const Text('Envoyer par WhatsApp'), onPressed: () => openWhatsApp(ctx, courierPhone, msg)),
            const SizedBox(height: 6),
          ],
          OutlinedButton.icon(icon: const Icon(Icons.copy), label: const Text('Copier le message'), onPressed: () => copyText(ctx, msg)),
          const SizedBox(height: 6),
          const Text('L\'envoi se fait depuis votre téléphone (SMS ou WhatsApp). MAYA n\'envoie pas de SMS automatiquement.', style: TextStyle(fontSize: 11, color: Colors.black54)),
        ]),
      ),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Terminé'))],
    ),
  );
}

// ======================================================================================
//  Organiser la livraison d'une commande : transporteur MAYA OU livreur du vendeur
// ======================================================================================
class OrganizeDeliveryScreen extends StatelessWidget {
  final String orderId, orderNumber;
  final String? clientCity;
  final bool startOnOwn;
  const OrganizeDeliveryScreen({super.key, required this.orderId, required this.orderNumber, this.clientCity, this.startOnOwn = false});

  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        initialIndex: startOnOwn ? 1 : 0,
        child: Scaffold(
          appBar: AppBar(
            title: Text('Livrer la commande $orderNumber'),
            bottom: const TabBar(
              indicatorColor: gold,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              tabs: [Tab(icon: Icon(Icons.local_shipping), text: 'Transporteur MAYA'), Tab(icon: Icon(Icons.person_pin_circle), text: 'Mon livreur')],
            ),
          ),
          body: TabBarView(children: [
            _FindCarrier(orderId: orderId, orderNumber: orderNumber, clientCity: clientCity),
            _OwnCourier(orderId: orderId, orderNumber: orderNumber, clientCity: clientCity),
          ]),
        ),
      );
}

void _openMission(BuildContext context, String id) =>
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MissionScreen(missionId: id)));

// ---------------------------------------------------------------- Option A
class _FindCarrier extends StatefulWidget {
  final String orderId, orderNumber;
  final String? clientCity;
  const _FindCarrier({required this.orderId, required this.orderNumber, this.clientCity});
  @override
  State<_FindCarrier> createState() => _FindCarrierState();
}

class _FindCarrierState extends State<_FindCarrier> {
  late final _city = TextEditingController(text: widget.clientCity ?? '');
  final _addr = TextEditingController();
  final _pickup = TextEditingController();
  double? _pLat, _pLng;
  List<Map<String, dynamic>>? _cands;
  bool _loading = false;

  Future<void> _search() async {
    setState(() => _loading = true);
    try {
      final r = await sb.rpc('delivery_candidates', params: {'p_order': widget.orderId, 'p_city': _city.text.trim()});
      if (mounted) setState(() => _cands = _rows(r));
    } catch (e) {
      if (mounted) snack(context, '$e');
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  Future<void> _gpsPickup() async {
    final pos = await askAndGetPosition(context, purpose: 'MAYA va lire votre position pour indiquer l\'emplacement de récupération du colis au transporteur.');
    if (pos != null && mounted) {
      setState(() {
        _pLat = pos.latitude;
        _pLng = pos.longitude;
      });
    }
  }

  Future<void> _request(String? carrierId) async {
    await guarded(context, () async {
      final r = Map<String, dynamic>.from(await sb.rpc('delivery_request', params: {
        'p_order': widget.orderId,
        'p_carrier': carrierId,
        'p_city': _city.text.trim().isEmpty ? null : _city.text.trim(),
        'p_address': _addr.text.trim().isEmpty ? null : _addr.text.trim(),
        'p_pickup_address': _pickup.text.trim().isEmpty ? null : _pickup.text.trim(),
        'p_pickup_lat': _pLat,
        'p_pickup_lng': _pLng,
      }) as Map);
      if (!mounted) return;
      final st = r['status'] as String?;
      snack(context, st == 'requested' ? 'Aucun transporteur MAYA disponible pour cette zone. Désignez votre livreur.' : 'Demande envoyée : ${deliveryLabel(st)}.');
      _openMission(context, r['mission_id'] as String);
    });
  }

  @override
  Widget build(BuildContext context) {
    final cands = _cands;
    return ListView(padding: const EdgeInsets.all(12), children: [
      const Text('MAYA recherche les transporteurs vérifiés qui couvrent la zone de livraison et sont disponibles. Le transporteur peut accepter ou refuser ; en cas de refus ou de silence, MAYA propose automatiquement un autre transporteur.',
          style: TextStyle(fontSize: 12.5)),
      const SizedBox(height: 10),
      TextField(controller: _city, decoration: const InputDecoration(labelText: 'Ville / zone de livraison', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: _addr, decoration: const InputDecoration(labelText: 'Adresse de livraison (facultatif, le client peut la préciser)', border: OutlineInputBorder())),
      const SizedBox(height: 8),
      TextField(controller: _pickup, decoration: const InputDecoration(labelText: 'Adresse de récupération (par défaut : celle de ma boutique)', border: OutlineInputBorder())),
      const SizedBox(height: 6),
      Row(children: [
        Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.my_location), label: Text(_pLat == null ? 'Position de mon magasin (GPS)' : 'Position GPS enregistrée ✓'), onPressed: _gpsPickup)),
      ]),
      const SizedBox(height: 10),
      FilledButton.icon(icon: const Icon(Icons.search), label: const Text('TROUVER UN TRANSPORTEUR'), onPressed: _loading ? null : _search),
      const SizedBox(height: 12),
      if (_loading) const Center(child: CircularProgressIndicator()),
      if (cands != null && cands.isEmpty)
        Card(
          color: const Color(0xFFFFF4E0),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('Aucun transporteur MAYA disponible pour cette zone.', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 6),
              const Text('Vous pouvez désigner votre propre livreur.'),
              TextButton.icon(icon: const Icon(Icons.person_add_alt_1), label: const Text('DÉSIGNER MON LIVREUR'), onPressed: () => DefaultTabController.of(context).animateTo(1)),
            ]),
          ),
        ),
      if (cands != null && cands.isNotEmpty) ...[
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.white),
          icon: const Icon(Icons.auto_awesome),
          label: const Text('LAISSER MAYA PROPOSER LE PLUS ADAPTÉ'),
          onPressed: () => _request(null),
        ),
        const SizedBox(height: 8),
        const Text('Ou choisissez vous-même :', style: TextStyle(fontWeight: FontWeight.w600)),
        for (final c in cands) _candCard(c),
      ],
    ]);
  }

  Widget _candCard(Map<String, dynamic> c) => Card(
        margin: const EdgeInsets.only(top: 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text('${c['name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
              if (c['zone_match'] == true) const Chip(label: Text('Zone couverte', style: TextStyle(fontSize: 11)), visualDensity: VisualDensity.compact),
            ]),
            if (c['phone'] != null) Text('Téléphone : ${c['phone']}'),
            if (c['city'] != null || c['zones'] != null) Text('Zone d\'intervention : ${[c['city'], c['zones']].where((e) => e != null && '$e'.isNotEmpty).join(' · ')}'),
            if (c['transport'] != null) Text('Moyen de transport : ${c['transport']}'),
            Text('Tarif : ${c['base_fee'] == null ? 'à convenir' : money(c['base_fee'])}'),
            Text('Délai estimé : ${(c['delay_note'] as String?)?.isNotEmpty == true ? c['delay_note'] : 'non précisé'}'),
            Text('Missions en cours : ${c['active_missions'] ?? 0}', style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 6),
            Align(alignment: Alignment.centerRight, child: FilledButton(onPressed: () => _request(c['carrier_id'] as String), child: const Text('CHOISIR CE TRANSPORTEUR'))),
          ]),
        ),
      );
}

// ---------------------------------------------------------------- Option B
class _OwnCourier extends StatefulWidget {
  final String orderId, orderNumber;
  final String? clientCity;
  const _OwnCourier({required this.orderId, required this.orderNumber, this.clientCity});
  @override
  State<_OwnCourier> createState() => _OwnCourierState();
}

class _OwnCourierState extends State<_OwnCourier> {
  final _name = TextEditingController();
  final _phone = TextEditingController(text: '+223 ');
  final _transport = TextEditingController();
  final _city = TextEditingController();
  final _zone = TextEditingController();
  final _fee = TextEditingController();
  late final _dropCity = TextEditingController(text: widget.clientCity ?? '');
  final _dropAddr = TextEditingController();
  final _pickup = TextEditingController();
  DateTime? _est;
  String? _courierId; // livreur choisi dans le carnet (inchangé)
  String? _photoPath;
  File? _photoFile;
  bool _save = true;
  bool _filling = false;
  List<Map<String, dynamic>> _book = [];

  @override
  void initState() {
    super.initState();
    _loadBook();
    for (final c in [_name, _phone]) {
      c.addListener(() {
        if (!_filling && _courierId != null) setState(() => _courierId = null);
      });
    }
  }

  Future<void> _loadBook() async {
    try {
      final r = await sb.from('delivery_couriers').select().eq('seller_id', uid).order('full_name');
      if (mounted) setState(() => _book = _rows(r));
    } catch (_) {}
  }

  void _fromBook(Map<String, dynamic> k) {
    _filling = true;
    setState(() {
      _courierId = k['id'] as String;
      _name.text = k['full_name'] as String? ?? '';
      _phone.text = k['phone'] as String? ?? '';
      _transport.text = k['transport'] as String? ?? '';
      _city.text = k['city'] as String? ?? '';
      _zone.text = k['zone'] as String? ?? '';
      _fee.text = k['default_fee'] == null ? '' : '${n(k['default_fee']).round()}';
      _photoPath = k['photo_path'] as String?;
      _photoFile = null;
    });
    _filling = false;
  }

  Future<void> _pickPhoto() async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 70, maxWidth: 800);
    if (x == null) return;
    setState(() {
      _photoFile = File(x.path);
      _courierId = null;
    });
  }

  Future<void> _submit() async {
    final digits = _phone.text.replaceAll(RegExp(r'\D'), '');
    if (_name.text.trim().length < 2) return snack(context, 'Le nom et le prénom du livreur sont obligatoires.');
    if (digits.length < 8) return snack(context, 'Le numéro de téléphone du livreur est obligatoire.');
    await guarded(context, () async {
      String? photo = _photoPath;
      if (_photoFile != null) {
        photo = '$uid/${DateTime.now().millisecondsSinceEpoch}.jpg';
        await sb.storage.from('courier-photos').upload(photo, _photoFile!, fileOptions: const FileOptions(contentType: 'image/jpeg'));
      }
      final r = Map<String, dynamic>.from(await sb.rpc('delivery_assign_own', params: {
        'p_order': widget.orderId,
        'p_courier': _courierId,
        'p_name': _name.text.trim(),
        'p_phone': _phone.text.trim(),
        'p_photo': photo,
        'p_transport': _transport.text.trim().isEmpty ? null : _transport.text.trim(),
        'p_city': _city.text.trim().isEmpty ? null : _city.text.trim(),
        'p_zone': _zone.text.trim().isEmpty ? null : _zone.text.trim(),
        'p_fee': num.tryParse(_fee.text.replaceAll(RegExp(r'[^0-9.]'), '')),
        'p_est': _est?.toUtc().toIso8601String(),
        'p_save': _save,
        'p_dropoff_city': _dropCity.text.trim().isEmpty ? null : _dropCity.text.trim(),
        'p_address': _dropAddr.text.trim().isEmpty ? null : _dropAddr.text.trim(),
        'p_pickup_address': _pickup.text.trim().isEmpty ? null : _pickup.text.trim(),
        'p_pickup_lat': null,
        'p_pickup_lng': null,
      }) as Map);
      if (!mounted) return;
      final inv = Map<String, dynamic>.from(r['invite'] as Map);
      await showInviteDialog(context,
          courierName: r['courier_name'] as String? ?? _name.text.trim(),
          courierPhone: r['courier_phone'] as String? ?? _phone.text.trim(),
          orderNumber: widget.orderNumber,
          token: inv['token'] as String,
          pin: inv['pin'] as String,
          expiresAt: inv['expires_at']);
      if (mounted) _openMission(context, r['mission_id'] as String);
    });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(12), children: [
        const Text('Vous désignez votre propre livreur. Il reçoit un code d\'invitation à usage unique pour consulter sa mission. Vous restez responsable de ce livreur.',
            style: TextStyle(fontSize: 12.5)),
        const SizedBox(height: 10),
        if (_book.isNotEmpty) ...[
          const Text('Mon carnet de livreurs', style: TextStyle(fontWeight: FontWeight.w600)),
          Wrap(spacing: 6, children: [
            for (final k in _book)
              ChoiceChip(label: Text('${k['full_name']}'), selected: _courierId == k['id'], onSelected: (_) => _fromBook(k)),
          ]),
          const SizedBox(height: 8),
        ],
        TextField(controller: _name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nom et prénom du livreur *', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        TextField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Numéro de téléphone *', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        Row(children: [
          CircleAvatar(radius: 26, backgroundImage: _photoFile != null ? FileImage(_photoFile!) : null, child: _photoFile == null ? const Icon(Icons.person) : null),
          const SizedBox(width: 10),
          Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.photo_camera_outlined), label: Text(_photoFile != null || _photoPath != null ? 'Changer la photo' : 'Photo (facultatif)'), onPressed: _pickPhoto)),
        ]),
        const SizedBox(height: 8),
        TextField(controller: _transport, decoration: const InputDecoration(labelText: 'Moyen de transport (moto, voiture, vélo…)', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: TextField(controller: _city, decoration: const InputDecoration(labelText: 'Ville', border: OutlineInputBorder()))),
          const SizedBox(width: 8),
          Expanded(child: TextField(controller: _zone, decoration: const InputDecoration(labelText: 'Zone d\'intervention', border: OutlineInputBorder()))),
        ]),
        const SizedBox(height: 8),
        TextField(controller: _fee, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tarif de livraison (FCFA)', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          icon: const Icon(Icons.schedule),
          label: Text(_est == null ? 'Date et heure estimées de livraison' : 'Livraison estimée : ${dt(_est!.toIso8601String())}'),
          onPressed: () async {
            final d = await pickDateTime(context, initial: _est);
            if (d != null) setState(() => _est = d);
          },
        ),
        const SizedBox(height: 8),
        TextField(controller: _dropCity, decoration: const InputDecoration(labelText: 'Ville de livraison (client)', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        TextField(controller: _dropAddr, decoration: const InputDecoration(labelText: 'Adresse de livraison (facultatif)', border: OutlineInputBorder())),
        const SizedBox(height: 8),
        TextField(controller: _pickup, decoration: const InputDecoration(labelText: 'Adresse de récupération (par défaut : ma boutique)', border: OutlineInputBorder())),
        CheckboxListTile(contentPadding: EdgeInsets.zero, value: _save, onChanged: (v) => setState(() => _save = v ?? true), title: const Text('Enregistrer ce livreur dans mon carnet')),
        FilledButton.icon(icon: const Icon(Icons.send), label: const Text('DÉSIGNER CE LIVREUR ET ENVOYER L\'INVITATION'), onPressed: _submit),
      ]);
}

// ======================================================================================
//  Carnet de livreurs du vendeur
// ======================================================================================
class CourierBookScreen extends StatefulWidget {
  const CourierBookScreen({super.key});
  @override
  State<CourierBookScreen> createState() => _CourierBookScreenState();
}

class _CourierBookScreenState extends State<CourierBookScreen> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async => _rows(await sb.from('delivery_couriers').select().eq('seller_id', uid).order('full_name'));
  void _reload() => setState(() => _f = _load());

  Future<void> _edit([Map<String, dynamic>? k]) async {
    final name = TextEditingController(text: k?['full_name'] as String?);
    final phone = TextEditingController(text: (k?['phone'] as String?) ?? '+223 ');
    final transport = TextEditingController(text: k?['transport'] as String?);
    final city = TextEditingController(text: k?['city'] as String?);
    final zone = TextEditingController(text: k?['zone'] as String?);
    final fee = TextEditingController(text: k?['default_fee'] == null ? '' : '${n(k!['default_fee']).round()}');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(k == null ? 'Ajouter un livreur' : 'Modifier le livreur'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom et prénom *')),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone *')),
            TextField(controller: transport, decoration: const InputDecoration(labelText: 'Moyen de transport')),
            TextField(controller: city, decoration: const InputDecoration(labelText: 'Ville')),
            TextField(controller: zone, decoration: const InputDecoration(labelText: 'Zone d\'intervention')),
            TextField(controller: fee, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tarif habituel (FCFA)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              if (name.text.trim().length < 2 || phone.text.replaceAll(RegExp(r'\D'), '').length < 8) {
                snack(ctx, 'Nom et téléphone obligatoires.');
                return;
              }
              Navigator.pop(ctx, true);
            },
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    String? nz(TextEditingController c) => c.text.trim().isEmpty ? null : c.text.trim();
    final row = {
      'full_name': name.text.trim(),
      'phone': phone.text.trim(),
      'transport': nz(transport),
      'city': nz(city),
      'zone': nz(zone),
      'default_fee': num.tryParse(fee.text.replaceAll(RegExp(r'[^0-9.]'), '')),
    };
    await guarded(context, () async {
      if (k == null) {
        await sb.from('delivery_couriers').insert({...row, 'seller_id': uid});
      } else {
        await sb.from('delivery_couriers').update(row).eq('id', k['id']);
      }
      _reload();
    });
  }

  Future<void> _delete(Map<String, dynamic> k) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Retirer ce livreur du carnet ?'),
        content: Text('${k['full_name']} sera retiré de votre carnet. Ses missions passées restent dans l\'historique.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(ctx, true), child: const Text('Retirer')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.from('delivery_couriers').delete().eq('id', k['id']);
      _reload();
    });
  }

  Future<void> _history(Map<String, dynamic> k) async {
    List<Map<String, dynamic>> ms = [];
    try {
      ms = _rows(await sb.from('delivery_missions').select('id, status, created_at, delivered_at, fee, orders(number)').eq('courier_id', k['id']).order('created_at', ascending: false).limit(100));
    } catch (e) {
      if (mounted) snack(context, '$e');
    }
    if (!mounted) return;
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => DraggableScrollableSheet(
        expand: false,
        initialChildSize: 0.6,
        builder: (_, sc) => ListView(controller: sc, padding: const EdgeInsets.all(12), children: [
          Text('Missions de ${k['full_name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
          if (ms.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucune mission pour ce livreur.')),
          for (final m in ms)
            ListTile(
              title: Text('Commande ${(m['orders'] as Map?)?['number'] ?? ''}'),
              subtitle: Text('${dt(m['created_at'])}${m['fee'] != null ? ' · ${money(m['fee'])}' : ''}'),
              trailing: DeliveryStatusChip(m['status'] as String),
              onTap: () {
                Navigator.pop(ctx);
                Navigator.push(context, MaterialPageRoute(builder: (_) => MissionScreen(missionId: m['id'] as String)));
              },
            ),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Mes livreurs')),
        floatingActionButton: FloatingActionButton.extended(icon: const Icon(Icons.person_add), label: const Text('Livreur'), onPressed: () => _edit()),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final list = snap.data!;
            if (list.isEmpty) {
              return const Center(
                  child: Padding(padding: EdgeInsets.all(24), child: Text('Votre carnet est vide. Ajoutez vos livreurs habituels : ils ne reçoivent aucun accès aux commandes tant que vous ne les désignez pas pour une mission.', textAlign: TextAlign.center)));
            }
            return ListView(padding: const EdgeInsets.fromLTRB(12, 12, 12, 90), children: [
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text('Un livreur du carnet n\'a accès à aucune commande tant que vous ne le désignez pas pour une mission précise.', style: TextStyle(fontSize: 12.5)),
              ),
              for (final k in list)
                Card(
                  child: ListTile(
                    leading: const CircleAvatar(child: Icon(Icons.two_wheeler)),
                    title: Text('${k['full_name']}'),
                    subtitle: Text([k['phone'], k['transport'], k['zone'] ?? k['city'], if (k['default_fee'] != null) money(k['default_fee'])].where((e) => e != null && '$e'.isNotEmpty).join(' · ')),
                    onTap: () => _history(k),
                    trailing: PopupMenuButton<String>(
                      onSelected: (v) {
                        if (v == 'call') callPhone(context, k['phone'] as String?);
                        if (v == 'edit') _edit(k);
                        if (v == 'history') _history(k);
                        if (v == 'del') _delete(k);
                      },
                      itemBuilder: (_) => const [
                        PopupMenuItem(value: 'call', child: Text('Appeler')),
                        PopupMenuItem(value: 'history', child: Text('Historique des missions')),
                        PopupMenuItem(value: 'edit', child: Text('Modifier')),
                        PopupMenuItem(value: 'del', child: Text('Retirer du carnet')),
                      ],
                    ),
                  ),
                ),
            ]);
          },
        ),
      );
}
