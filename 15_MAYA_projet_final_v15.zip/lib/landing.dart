import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'auth.dart';
import 'common.dart';
import 'config.dart';
import 'delivery_courier.dart' show MyDeliveriesScreen;
import 'guest.dart' show requireAuth, AboutMayaScreen;
import 'my_shop.dart' show ShopPage;
import 'seller_apply.dart' show startSellerFlow;
import 'shop.dart' show ShopHome, ProductsScreen, ShopsDirectoryScreen;

// ======================================================================================
//  Page d'accueil MAYA (visiteurs) — d'après la maquette : en-tête, héros, 8 étapes d'achat,
//  engagements, avantages acheteurs / vendeurs, FAQ, contact, pied de page.
// ======================================================================================
const _title = Color(0xFF2B1A80);
const _ink = Color(0xFF1F1B4D);
const _pill = Color(0xFF32008F);
const _yellow = Color(0xFFF6BC2E);
const _footer = Color(0xFF28064E);
const _footer2 = Color(0xFF3E116E);
const _lav = Color(0xFFF4EEFB);
const _pageBg = Color(0xFFFCF9FE);
const _muted = Color(0xFF5D5A7A);

/// Logo vectoriel : panier jaune + « MAYA » + « Marketplace Africaine ».
class MayaWordmark extends StatelessWidget {
  final bool light;
  final double size;
  const MayaWordmark({super.key, this.light = false, this.size = 1});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        Icon(Icons.shopping_cart_outlined, color: _yellow, size: 38 * size),
        SizedBox(width: 6 * size),
        Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: [
          Text('MAYA', style: TextStyle(fontSize: 28 * size, height: 1, fontWeight: FontWeight.w900, letterSpacing: 0.5, color: light ? Colors.white : _title)),
          Text('Marketplace Africaine', style: TextStyle(fontSize: 10 * size, fontWeight: FontWeight.w600, color: light ? Colors.white70 : _title)),
        ]),
      ]);
}

class LandingScreen extends StatefulWidget {
  final void Function(int tab) onGo; // 0 accueil, 1 catégories, 2 favoris, 3 commandes, 4 compte
  final VoidCallback onContact;
  const LandingScreen({super.key, required this.onGo, required this.onContact});
  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen> {
  final _scroll = ScrollController();
  final _faqKey = GlobalKey();
  final _search = TextEditingController();

  @override
  void dispose() {
    _scroll.dispose();
    _search.dispose();
    super.dispose();
  }

  // ---------------------------------------------------------------- Actions (tout est branché sur l'existant)
  void _push(Widget w) => Navigator.push(context, MaterialPageRoute(builder: (_) => w));
  void _top() => _scroll.animateTo(0, duration: const Duration(milliseconds: 400), curve: Curves.easeOut);
  void _toFaq() {
    final c = _faqKey.currentContext;
    if (c != null) Scrollable.ensureVisible(c, duration: const Duration(milliseconds: 450), curve: Curves.easeOut, alignment: 0.05);
  }

  void _shops() => _push(const ShopsDirectoryScreen());
  void _products([String q = '']) => _push(ProductsScreen(initialQuery: q, title: q.isEmpty ? 'Produits' : 'Recherche'));
  void _explore() => _push(Scaffold(
        appBar: AppBar(title: const Text('Explorer MAYA'), bottom: const MaliStripe()),
        body: ShopHome(
          onGo: (t) {
            Navigator.pop(context);
            widget.onGo(t);
          },
          onContact: widget.onContact,
        ),
      ));
  void _login([bool register = false]) => _push(AuthScreen(initialRegister: register));
  void _seller() => startSellerFlow(context);
  void _about() => _push(const AboutMayaScreen());

  void _runSearch() {
    final q = _search.text.trim();
    if (q.isEmpty) {
      _products();
    } else {
      _push(_SearchResults(query: q));
    }
  }

  Future<void> _needAccount(String reason, VoidCallback then) async {
    if (await requireAuth(context, reason: reason) && mounted) then();
  }

  Future<void> _open(String url) async {
    if (url.isEmpty) {
      snack(context, 'Cette page sera bientôt disponible.');
      return;
    }
    final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
    if (!ok && mounted) snack(context, 'Impossible d\'ouvrir le lien.');
  }

  void _contact() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Contacter MAYA', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: _title)),
            const SizedBox(height: 4),
            const Text('Notre équipe vous répond. Choisissez le moyen qui vous convient.', style: TextStyle(color: _muted)),
            const SizedBox(height: 10),
            ListTile(
              leading: const CircleAvatar(backgroundColor: _lav, child: Icon(Icons.chat_bubble_outline, color: brand)),
              title: const Text('Écrire à MAYA dans l\'application'),
              subtitle: const Text('Messages, photos, vocaux (compte requis)'),
              onTap: () {
                Navigator.pop(ctx);
                widget.onContact();
              },
            ),
            if (supportWhatsapp.isNotEmpty)
              ListTile(
                leading: const CircleAvatar(backgroundColor: Color(0xFFE8F5E9), child: Icon(Icons.chat, color: Color(0xFF25D366))),
                title: const Text('WhatsApp'),
                onTap: () {
                  Navigator.pop(ctx);
                  _open('https://wa.me/$supportWhatsapp');
                },
              ),
            if (supportPhone.isNotEmpty)
              ListTile(
                leading: const CircleAvatar(backgroundColor: _lav, child: Icon(Icons.call, color: brand)),
                title: Text('Appeler $supportPhone'),
                onTap: () {
                  Navigator.pop(ctx);
                  _open('tel:$supportPhone');
                },
              ),
            if (supportEmail.isNotEmpty)
              ListTile(
                leading: const CircleAvatar(backgroundColor: _lav, child: Icon(Icons.email_outlined, color: brand)),
                title: Text(supportEmail),
                onTap: () {
                  Navigator.pop(ctx);
                  _open('mailto:$supportEmail');
                },
              ),
          ]),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- Mise en page
  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final wide = w >= 1000;
    final mobile = w < 640;
    return Material(
      color: _pageBg,
      child: Column(children: [
        _header(wide, mobile),
        Expanded(
          child: SingleChildScrollView(
            controller: _scroll,
            child: Column(children: [
              _hero(w, wide, mobile),
              _contentBox(child: _steps(w)),
              _engagements(w, wide, mobile),
              _contentBox(child: _whyAndSellers(w, wide, mobile)),
              _contentBox(key: _faqKey, child: _faqAndContact(w, wide, mobile)),
              _footerBlock(w, wide, mobile),
            ]),
          ),
        ),
      ]),
    );
  }

  Widget _contentBox({required Widget child, Key? key}) => Center(
        key: key,
        child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1240), child: Padding(padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10), child: child)),
      );

  // ---------------------------------------------------------------- En-tête
  Widget _header(bool wide, bool mobile) {
    final searchField = SizedBox(
      height: 44,
      child: TextField(
        controller: _search,
        textInputAction: TextInputAction.search,
        onSubmitted: (_) => _runSearch(),
        style: const TextStyle(fontSize: 13.5),
        decoration: InputDecoration(
          hintText: 'Rechercher un produit, une boutique...',
          hintStyle: const TextStyle(fontSize: 13, color: _muted),
          filled: true,
          fillColor: const Color(0xFFF6F3FA),
          contentPadding: const EdgeInsets.only(left: 14),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2DAF0))),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: const BorderSide(color: Color(0xFFE2DAF0))),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(4),
            child: Material(color: brand, borderRadius: BorderRadius.circular(9), child: InkWell(borderRadius: BorderRadius.circular(9), onTap: _runSearch, child: const SizedBox(width: 38, child: Icon(Icons.search, color: Colors.white, size: 20)))),
          ),
        ),
      ),
    );
    Widget navLink(IconData i, String t, VoidCallback f) => TextButton.icon(
          onPressed: f,
          icon: Icon(i, size: 17, color: _ink),
          label: Text(t, style: const TextStyle(color: _ink, fontWeight: FontWeight.w600, fontSize: 13.5)),
        );
    final loginBtn = OutlinedButton(
      onPressed: _login,
      style: OutlinedButton.styleFrom(minimumSize: const Size(0, 40), foregroundColor: brand, side: const BorderSide(color: brand, width: 1.5), padding: const EdgeInsets.symmetric(horizontal: 16), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
      child: const Text('Se connecter', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
    );
    final signBtn = FilledButton(
      onPressed: () => _login(true),
      style: FilledButton.styleFrom(minimumSize: const Size(0, 40), backgroundColor: brand, padding: const EdgeInsets.symmetric(horizontal: 18), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10))),
      child: const Text('S\'inscrire', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
    );
    final menu = PopupMenuButton<String>(
      tooltip: 'Menu',
      icon: const Icon(Icons.menu, color: _ink),
      onSelected: (v) {
        switch (v) {
          case 'explore':
            _explore();
          case 'shops':
            _shops();
          case 'help':
            _toFaq();
          case 'login':
            _login();
          case 'signup':
            _login(true);
          case 'seller':
            _seller();
        }
      },
      itemBuilder: (_) => const [
        PopupMenuItem(value: 'explore', child: Text('Explorer')),
        PopupMenuItem(value: 'shops', child: Text('Boutiques')),
        PopupMenuItem(value: 'help', child: Text('Aide')),
        PopupMenuItem(value: 'seller', child: Text('Devenir vendeur')),
        PopupMenuDivider(),
        PopupMenuItem(value: 'login', child: Text('Se connecter')),
        PopupMenuItem(value: 'signup', child: Text('S\'inscrire')),
      ],
    );
    return Material(
      color: Colors.white,
      elevation: 3,
      shadowColor: Colors.black26,
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: EdgeInsets.symmetric(horizontal: mobile ? 10 : 20, vertical: 8),
          child: wide
              ? Row(children: [
                  InkWell(onTap: _top, child: const MayaWordmark()),
                  const SizedBox(width: 28),
                  Expanded(child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 520), child: searchField)),
                  const SizedBox(width: 12),
                  navLink(Icons.visibility_outlined, 'Explorer', _explore),
                  navLink(Icons.storefront_outlined, 'Boutiques', _shops),
                  navLink(Icons.help_outline, 'Aide', _toFaq),
                  const SizedBox(width: 8),
                  loginBtn,
                  const SizedBox(width: 8),
                  signBtn,
                ])
              : Column(mainAxisSize: MainAxisSize.min, children: [
                  Row(children: [
                    InkWell(onTap: _top, child: MayaWordmark(size: mobile ? 0.85 : 1)),
                    const Spacer(),
                    if (!mobile) ...[loginBtn, const SizedBox(width: 8)],
                    signBtn,
                    menu,
                  ]),
                  const SizedBox(height: 8),
                  searchField,
                ]),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- Héros
  Widget _heroBtn(String label, IconData icon, {required VoidCallback onTap, bool filled = false, bool yellow = false, double? width}) {
    final bg = yellow ? _yellow : (filled ? brand : Colors.white);
    final fg = yellow ? const Color(0xFF3B2A00) : (filled ? Colors.white : brand);
    return SizedBox(
      width: width,
      child: Material(
        color: bg,
        elevation: filled || yellow ? 3 : 0,
        shadowColor: Colors.black38,
        borderRadius: BorderRadius.circular(14),
        child: InkWell(
          borderRadius: BorderRadius.circular(14),
          onTap: onTap,
          child: Container(
            constraints: const BoxConstraints(minHeight: 56),
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(14), border: filled || yellow ? null : Border.all(color: brand, width: 1.6)),
            child: Row(mainAxisSize: width == null ? MainAxisSize.min : MainAxisSize.max, children: [
              Icon(icon, color: fg, size: 22),
              const SizedBox(width: 8),
              Flexible(child: Text(label, style: TextStyle(color: fg, fontWeight: FontWeight.w800, fontSize: 13, height: 1.15))),
              const SizedBox(width: 6),
              if (label != 'Se connecter') Icon(Icons.arrow_forward, color: fg, size: 18),
            ]),
          ),
        ),
      ),
    );
  }

  Widget _hero(double w, bool wide, bool mobile) {
    final textBlock = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text.rich(
        TextSpan(children: [
          TextSpan(text: 'MAYA,', style: TextStyle(color: brand, fontSize: wide ? 54 : (mobile ? 30 : 42))),
          TextSpan(text: ' votre marketplace pour découvrir, acheter et vendre plus facilement.', style: TextStyle(color: _ink, fontSize: wide ? 40 : (mobile ? 24 : 32))),
        ]),
        style: const TextStyle(fontWeight: FontWeight.w900, height: 1.12),
      ),
      const SizedBox(height: 14),
      Text('Découvrez des boutiques, comparez les produits, passez vos commandes et suivez vos livraisons depuis une seule plateforme.',
          style: TextStyle(fontSize: mobile ? 14.5 : 17, height: 1.4, color: _ink)),
      const SizedBox(height: 20),
      LayoutBuilder(builder: (context, c) {
        final two = c.maxWidth < 520;
        final bw = two ? (c.maxWidth - 10) / 2 : null;
        return Wrap(spacing: 10, runSpacing: 10, children: [
          _heroBtn('Découvrir les boutiques', Icons.shopping_cart_outlined, onTap: _shops, filled: true, width: bw),
          _heroBtn('Explorer les produits', Icons.grid_view_rounded, onTap: _explore, width: bw),
          _heroBtn('Devenir vendeur', Icons.storefront_outlined, onTap: _seller, yellow: true, width: bw),
          _heroBtn('Se connecter', Icons.person, onTap: _login, width: bw),
        ]);
      }),
    ]);

    Widget photo(double h) => ShaderMask(
          blendMode: BlendMode.dstIn,
          shaderCallback: (r) => const LinearGradient(colors: [Colors.transparent, Colors.black, Colors.black, Colors.transparent], stops: [0, 0.2, 0.93, 1]).createShader(r),
          child: Image.asset('assets/landing/hero_woman.png', height: h, fit: BoxFit.cover, alignment: Alignment.centerLeft, filterQuality: FilterQuality.high),
        );

    return Container(
      decoration: const BoxDecoration(gradient: LinearGradient(colors: [Colors.white, Color(0xFFF6EFF6)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1240),
          child: wide
              ? SizedBox(
                  height: 420,
                  child: Stack(children: [
                    Positioned(right: 0, top: 0, bottom: 0, width: 620, child: photo(420)),
                    Padding(padding: const EdgeInsets.fromLTRB(24, 28, 0, 20), child: SizedBox(width: 640, child: textBlock)),
                  ]),
                )
              : Column(children: [
                  Padding(padding: EdgeInsets.fromLTRB(mobile ? 16 : 24, 22, mobile ? 16 : 24, 14), child: textBlock),
                  SizedBox(width: double.infinity, height: mobile ? 250 : 320, child: photo(mobile ? 250 : 320)),
                ]),
        ),
      ),
    );
  }

  // ---------------------------------------------------------------- Titre en pastille
  Widget _pillTitle(String t, {Color color = _pill, double size = 19}) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 8),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(12)),
        child: Text(t, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: size)),
      );

  BoxDecoration _cardBox({Color color = Colors.white}) => BoxDecoration(
        color: color,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFECE5F7)),
        boxShadow: const [BoxShadow(color: Color(0x143E0AA1), blurRadius: 14, offset: Offset(0, 4))],
      );

  // ---------------------------------------------------------------- Comment acheter sur MAYA ? (8 étapes)
  Widget _steps(double w) {
    final steps = <(IconData, Color, String, String, VoidCallback)>[
      (Icons.storefront, const Color(0xFFF08A1C), 'Découvrez\nles boutiques', 'et produits librement, sans inscription.', _shops),
      (Icons.image_search, const Color(0xFFF08A1C), 'Consultez les photos, vidéos,', 'prix et informations des produits.', _explore),
      (Icons.person_add_alt_1, const Color(0xFF2F6FD6), 'Créez un compte', 'ou connectez-vous pour acheter.', () => _login(true)),
      (Icons.forum_outlined, const Color(0xFF2F6FD6), 'Contactez le vendeur', 'et validez la proposition de commande.', () => _needAccount('Connectez-vous ou créez un compte pour contacter un vendeur et commander.', () => widget.onGo(3))),
      (Icons.receipt_long, const Color(0xFF2F6FD6), 'Consultez le récapitulatif', '(quantités, prix, frais, total).', () => _needAccount('Connectez-vous pour consulter vos commandes.', () => widget.onGo(3))),
      (Icons.two_wheeler, const Color(0xFFF08A1C), 'Organisez la livraison', 'avec un transporteur MAYA ou un livreur.', _toFaq),
      (Icons.location_on, const Color(0xFFE5392F), 'Suivez votre colis', 'et communiquez avec le livreur.', () => _needAccount('Connectez-vous pour suivre vos colis.', () => _push(const MyDeliveriesScreen()))),
      (Icons.check_circle, const Color(0xFF1FA04A), 'Confirmez la réception', 'ou signalez un problème.', () => _needAccount('Connectez-vous pour confirmer la réception de vos commandes.', () => widget.onGo(3))),
    ];
    Widget step(int i) {
      final s = steps[i];
      return InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: s.$5,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 4),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            CircleAvatar(radius: 12, backgroundColor: brand, child: Text('${i + 1}', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 12.5))),
            const SizedBox(height: 8),
            Container(
              width: 54,
              height: 54,
              decoration: BoxDecoration(color: s.$2.withOpacity(0.12), borderRadius: BorderRadius.circular(14)),
              child: Icon(s.$1, color: s.$2, size: 30),
            ),
            const SizedBox(height: 8),
            Text(s.$3, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, height: 1.2, color: _ink)),
            const SizedBox(height: 3),
            Text(s.$4, textAlign: TextAlign.center, style: const TextStyle(fontSize: 11.5, height: 1.25, color: _muted)),
          ]),
        ),
      );
    }

    return Stack(clipBehavior: Clip.none, children: [
      Container(
        margin: const EdgeInsets.only(top: 18),
        padding: const EdgeInsets.fromLTRB(10, 30, 10, 14),
        decoration: _cardBox(),
        child: LayoutBuilder(builder: (context, c) {
          if (c.maxWidth >= 980) {
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              for (var i = 0; i < 8; i++) ...[
                Expanded(child: step(i)),
                if (i < 7) const Padding(padding: EdgeInsets.only(top: 52), child: Icon(Icons.east, color: Color(0xFF7C5CC4), size: 20)),
              ],
            ]);
          }
          final cols = c.maxWidth >= 640 ? 4 : 2;
          final cw = (c.maxWidth - 8 * (cols - 1)) / cols;
          return Wrap(spacing: 8, runSpacing: 14, children: [for (var i = 0; i < 8; i++) SizedBox(width: cw, child: step(i))]);
        }),
      ),
      Positioned(top: 0, left: 0, right: 0, child: Center(child: _pillTitle('Comment acheter sur MAYA ?'))),
    ]);
  }

  // ---------------------------------------------------------------- Engagements et garanties
  void _info(String title, String body, IconData icon, Color color) {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(22))),
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 18, 20, 16),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              CircleAvatar(radius: 22, backgroundColor: color.withOpacity(0.12), child: Icon(icon, color: color)),
              const SizedBox(width: 12),
              Expanded(child: Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800, color: _title))),
            ]),
            const SizedBox(height: 12),
            Text(body, style: const TextStyle(fontSize: 14.5, height: 1.45, color: _ink)),
            const SizedBox(height: 14),
            Align(alignment: Alignment.centerRight, child: TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer'))),
          ]),
        ),
      ),
    );
  }

  Widget _engagements(double w, bool wide, bool mobile) {
    final items = <(IconData, Color, String, String, String)>[
      (Icons.verified_user, const Color(0xFF1FA04A), 'Vendeurs vérifiés', 'Les vendeurs sont contrôlés avant d\'être autorisés.',
          'Chaque vendeur dépose une demande avec une pièce d\'identité. L\'administration MAYA l\'examine et ne valide que les dossiers conformes : tant que ce n\'est pas fait, le vendeur ne peut rien publier. Les produits sont aussi validés avant leur mise en ligne.'),
      (Icons.lock, const Color(0xFF2F6FD6), 'Transactions sécurisées', 'Des informations claires et protégées.',
          'Les paiements sont confirmés uniquement par le serveur. L\'argent du vendeur reste bloqué jusqu\'à ce que VOUS confirmiez « Colis reçu » : une confirmation du livreur ou du vendeur ne suffit pas.'),
      (Icons.local_shipping, const Color(0xFF2F6FD6), 'Livraison suivie', 'Transporteur partenaire ou livreur désigné.',
          'Chaque livraison a un statut, un livreur identifié et, si le livreur l\'active, sa position sur une carte pendant la mission. Le client, le vendeur et le livreur disposent d\'une conversation privée liée à la commande.'),
      (Icons.headset_mic, const Color(0xFF2F6FD6), 'Assistance et signalement', 'Une équipe à votre écoute en cas de problème.',
          'En cas de colis non reçu, incomplet ou endommagé, vous ouvrez un signalement en un geste. L\'administration examine le litige et conserve l\'historique et les preuves.'),
      (Icons.privacy_tip, const Color(0xFF1FA04A), 'Protection des données', 'Vos informations restent confidentielles.',
          'Vos conversations, commandes et positions ne sont accessibles qu\'aux personnes concernées. Votre position GPS n\'est jamais suivie sans votre accord et s\'arrête à la fin de la livraison.'),
    ];
    Widget card(int i) {
      final it = items[i];
      return Material(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        elevation: 2,
        shadowColor: const Color(0x223E0AA1),
        child: InkWell(
          borderRadius: BorderRadius.circular(16),
          onTap: () => _info(it.$3, it.$5, it.$1, it.$2),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(it.$1, color: it.$2, size: 38),
              const SizedBox(height: 8),
              Text(it.$3, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 12.5, color: _ink, height: 1.2)),
              const SizedBox(height: 4),
              Text(it.$4, textAlign: TextAlign.center, style: const TextStyle(fontSize: 10.5, color: _muted, height: 1.25)),
            ]),
          ),
        ),
      );
    }

    final man = ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: Image.asset('assets/landing/delivery_man.png', fit: BoxFit.cover, filterQuality: FilterQuality.high),
    );

    return Container(
      margin: const EdgeInsets.only(top: 14),
      decoration: const BoxDecoration(gradient: LinearGradient(colors: [Color(0xFFEFE6FB), Color(0xFFF8F3FD)], begin: Alignment.topLeft, end: Alignment.bottomRight)),
      child: _contentBox(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _pillTitle('Nos engagements et garanties'),
          const SizedBox(height: 14),
          LayoutBuilder(builder: (context, c) {
            if (wide) {
              return Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                for (var i = 0; i < items.length; i++) ...[Expanded(child: card(i)), const SizedBox(width: 10)],
                SizedBox(width: 330, height: 180, child: man),
              ]);
            }
            final cols = c.maxWidth >= 640 ? 3 : 2;
            final cw = (c.maxWidth - 10 * (cols - 1)) / cols;
            return Column(children: [
              Wrap(spacing: 10, runSpacing: 10, children: [for (var i = 0; i < items.length; i++) SizedBox(width: cw, child: card(i))]),
              const SizedBox(height: 12),
              SizedBox(width: double.infinity, height: mobile ? 190 : 260, child: man),
            ]);
          }),
        ]),
      ),
    );
  }

  // ---------------------------------------------------------------- Pourquoi choisir MAYA ? / Pour les vendeurs
  Widget _checks(List<String> items) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        for (final t in items)
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 3.5),
            child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Icon(Icons.check_circle, color: _yellow, size: 21),
              const SizedBox(width: 9),
              Expanded(child: Text(t, style: const TextStyle(fontSize: 14, color: _ink, height: 1.25))),
            ]),
          ),
      ]);

  Widget _whyAndSellers(double w, bool wide, bool mobile) {
    final why = Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardBox(color: const Color(0xFFF6F0FD)),
      child: LayoutBuilder(builder: (context, c) {
        final stack = c.maxWidth < 430;
        final img = ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset('assets/landing/cart.png', fit: BoxFit.cover, filterQuality: FilterQuality.high));
        final list = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _pillTitle('Pourquoi choisir MAYA ?', size: 17),
          const SizedBox(height: 10),
          _checks(const [
            'Découverte de nombreuses boutiques',
            'Comparaison des produits et des prix',
            'Boutiques personnalisables',
            'Communication directe avec les vendeurs',
            'Commandes centralisées',
            'Plusieurs possibilités de livraison',
            'Suivi des commandes',
            'Assistance en cas de difficulté',
          ]),
        ]);
        return stack
            ? Column(children: [list, const SizedBox(height: 12), SizedBox(height: 230, width: 170, child: img)])
            : Row(crossAxisAlignment: CrossAxisAlignment.center, children: [Expanded(child: list), const SizedBox(width: 12), SizedBox(width: 170, height: 240, child: img)]);
      }),
    );

    final sellers = Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardBox(),
      child: LayoutBuilder(builder: (context, c) {
        final stack = c.maxWidth < 430;
        final img = ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.asset('assets/landing/shop.png', fit: BoxFit.cover, filterQuality: FilterQuality.high));
        final list = Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          _pillTitle('Pour les vendeurs', size: 17),
          const SizedBox(height: 10),
          const Text('Rejoignez MAYA et développez votre activité !', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 14.5, color: _ink)),
          const SizedBox(height: 6),
          _checks(const [
            'Créez votre compte et demandez l\'accès vendeur',
            'Complétez les informations de votre boutique',
            'Personnalisez votre vitrine',
            'Publiez vos produits',
            'Recevez et gérez vos commandes',
            'Organisez les livraisons',
          ]),
          const SizedBox(height: 12),
          FilledButton.icon(
            onPressed: _seller,
            style: FilledButton.styleFrom(backgroundColor: _pill, padding: const EdgeInsets.symmetric(horizontal: 22), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
            icon: const Text('Devenir vendeur', style: TextStyle(fontWeight: FontWeight.w800)),
            label: const Icon(Icons.arrow_forward, size: 18),
          ),
        ]);
        return stack
            ? Column(children: [list, const SizedBox(height: 12), SizedBox(height: 200, child: img)])
            : Row(crossAxisAlignment: CrossAxisAlignment.center, children: [Expanded(child: list), const SizedBox(width: 12), SizedBox(width: 170, height: 240, child: img)]);
      }),
    );

    return wide || w >= 900
        ? Row(crossAxisAlignment: CrossAxisAlignment.stretch, children: [Expanded(child: why), const SizedBox(width: 14), Expanded(child: sellers)])
        : Column(children: [why, const SizedBox(height: 12), sellers]);
  }

  // ---------------------------------------------------------------- FAQ + contact
  static const _faq = <(String, String)>[
    ('Est-il possible de consulter MAYA sans compte ?',
        'Oui. Vous pouvez parcourir librement les boutiques, les produits, les photos, vidéos et prix sans vous inscrire. Un compte est nécessaire uniquement pour commander, enregistrer des favoris, écrire à un vendeur ou vendre.'),
    ('Comment devenir vendeur ?',
        'Créez votre compte MAYA puis appuyez sur « Devenir vendeur ». Renseignez votre boutique et déposez une pièce d\'identité. L\'administration examine votre demande ; une fois validée, vous pouvez personnaliser votre vitrine et publier vos produits.'),
    ('Comment passer une commande ?',
        'Choisissez un produit, contactez le vendeur (ou MAYA) depuis la messagerie, puis validez la proposition de commande qu\'il vous envoie. Vous recevez le récapitulatif (quantités, prix, frais, total) et réglez avec le lien de paiement.'),
    ('Comment fonctionne la livraison ?',
        'Le vendeur choisit : soit un transporteur partenaire de MAYA (vérifié, disponible dans la zone de livraison), soit son propre livreur. Dès que le livreur accepte, une conversation à trois (vendeur, client, livreur) s\'ouvre et vous pouvez suivre la livraison.'),
    ('Puis-je choisir mon propre livreur ?',
        'Oui, si vous êtes vendeur : « Désigner mon livreur » vous permet d\'ajouter votre livreur (nom, téléphone, transport, tarif). Il reçoit un code d\'invitation sécurisé, sans obligation de créer un compte vendeur. Vous restez responsable de ce livreur.'),
    ('Comment suivre mon colis ?',
        'Ouvrez votre commande puis appuyez sur « Suivre mon colis » : statut, contact du livreur, heure estimée et, si le livreur partage sa position, la carte en direct. Vous pouvez aussi partager votre propre position pour faciliter la livraison.'),
    ('Que faire si je ne reçois pas ma commande ?',
        'Dans votre commande, appuyez sur « Colis non reçu ». Un signalement est ouvert, le paiement du vendeur reste bloqué et l\'administration traite le litige.'),
    ('Comment contacter l\'administration ?',
        'Utilisez « Nous contacter » : messagerie MAYA dans l\'application (compte requis) et, selon leur disponibilité, WhatsApp, téléphone ou e-mail.'),
  ];

  Widget _faqTile(int i) => Theme(
        data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
        child: Container(
          margin: const EdgeInsets.only(bottom: 6),
          decoration: BoxDecoration(border: Border(bottom: BorderSide(color: Colors.black.withOpacity(0.07)))),
          child: ExpansionTile(
            tilePadding: const EdgeInsets.symmetric(horizontal: 6),
            childrenPadding: const EdgeInsets.fromLTRB(6, 0, 6, 12),
            expandedAlignment: Alignment.centerLeft,
            iconColor: brand,
            collapsedIconColor: brand,
            title: Text(_faq[i].$1, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13.5, color: _ink)),
            children: [Text(_faq[i].$2, style: const TextStyle(fontSize: 13.5, height: 1.45, color: _muted))],
          ),
        ),
      );

  Widget _faqAndContact(double w, bool wide, bool mobile) {
    final faq = Container(
      padding: const EdgeInsets.all(16),
      decoration: _cardBox(),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          const CircleAvatar(radius: 17, backgroundColor: brand, child: Text('?', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w900, fontSize: 19))),
          const SizedBox(width: 10),
          const Text('Questions fréquentes', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: _title)),
        ]),
        const SizedBox(height: 10),
        LayoutBuilder(builder: (context, c) {
          if (c.maxWidth >= 640) {
            return Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Expanded(child: Column(children: [for (var i = 0; i < 4; i++) _faqTile(i)])),
              const SizedBox(width: 20),
              Expanded(child: Column(children: [for (var i = 4; i < 8; i++) _faqTile(i)])),
            ]);
          }
          return Column(children: [for (var i = 0; i < 8; i++) _faqTile(i)]);
        }),
      ]),
    );

    final contact = Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [Color(0xFFEDE4FB), Color(0xFFE2D6F7)], begin: Alignment.topLeft, end: Alignment.bottomRight),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(children: [
        Expanded(
          flex: 6,
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Une question ?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: _title)),
            const SizedBox(height: 4),
            const Text('Notre équipe est là pour vous aider !', style: TextStyle(fontSize: 15, color: _ink, fontWeight: FontWeight.w600)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: _contact,
              style: FilledButton.styleFrom(backgroundColor: _pill, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              icon: const Text('Nous contacter', style: TextStyle(fontWeight: FontWeight.w800)),
              label: const Icon(Icons.arrow_forward, size: 18),
            ),
          ]),
        ),
        const SizedBox(width: 8),
        Expanded(flex: 4, child: ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.asset('assets/landing/support_woman.png', fit: BoxFit.cover, filterQuality: FilterQuality.high))),
      ]),
    );

    return wide || w >= 900
        ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [Expanded(flex: 7, child: faq), const SizedBox(width: 14), Expanded(flex: 3, child: contact)])
        : Column(children: [faq, const SizedBox(height: 12), contact]);
  }

  // ---------------------------------------------------------------- Pied de page
  Widget _footerBlock(double w, bool wide, bool mobile) {
    Widget link(String t, VoidCallback f) => InkWell(
          onTap: f,
          child: Padding(padding: const EdgeInsets.symmetric(vertical: 4.5), child: Text(t, style: const TextStyle(color: Colors.white70, fontSize: 13.5))),
        );
    Widget col(String title, List<Widget> children) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 15)),
          const SizedBox(height: 6),
          ...children,
        ]);
    Widget social(IconData i, Color c, String label, VoidCallback f) => Tooltip(
          message: label,
          child: InkWell(
            onTap: f,
            borderRadius: BorderRadius.circular(10),
            child: Container(width: 38, height: 38, decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(10)), child: Icon(i, color: Colors.white, size: 21)),
          ),
        );

    final links = col('Liens utiles', [link('Accueil', _top), link('Boutiques', _shops), link('Produits', () => _products()), link('Devenir vendeur', _seller)]);
    final assist = col('Assistance', [
      link('FAQ', _toFaq),
      link('Nous contacter', _contact),
      link('Conditions d\'utilisation', () => _push(const LegalScreen(privacy: false))),
      link('Politique de confidentialité', () => _push(const LegalScreen(privacy: true))),
      link('À propos de MAYA', _about),
    ]);
    final follow = col('Suivez-nous', [
      const SizedBox(height: 4),
      Wrap(spacing: 8, runSpacing: 8, children: [
        social(Icons.facebook, const Color(0xFF1877F2), 'Facebook', () => _open(socialFacebook)),
        social(Icons.chat, const Color(0xFF25D366), 'WhatsApp', () => _open(supportWhatsapp.isEmpty ? '' : 'https://wa.me/$supportWhatsapp')),
        social(Icons.play_arrow_rounded, const Color(0xFFE62117), 'YouTube', () => _open(socialYoutube)),
        social(Icons.music_note, Colors.black, 'TikTok', () => _open(socialTiktok)),
      ]),
    ]);
    final badge = Row(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.shield_outlined, color: _yellow, size: 52),
      const SizedBox(width: 8),
      Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: const [
        Text('MAYA', style: TextStyle(color: _yellow, fontWeight: FontWeight.w900, fontSize: 22)),
        Text('Achetez. Vendez.\nEn toute confiance.', style: TextStyle(color: Colors.white70, fontSize: 11.5, height: 1.2)),
      ]),
    ]);

    return Container(
      margin: const EdgeInsets.only(top: 18),
      color: _footer,
      child: Column(children: [
        Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 1240),
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 26, 20, 22),
              child: wide
                  ? Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const Expanded(flex: 3, child: Align(alignment: Alignment.topLeft, child: MayaWordmark(light: true, size: 1.2))),
                      Expanded(flex: 2, child: links),
                      Expanded(flex: 3, child: assist),
                      Expanded(flex: 2, child: follow),
                      Expanded(flex: 3, child: Align(alignment: Alignment.topRight, child: badge)),
                    ])
                  : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      const MayaWordmark(light: true, size: 1.1),
                      const SizedBox(height: 18),
                      Wrap(spacing: 40, runSpacing: 18, children: [links, assist, follow]),
                      const SizedBox(height: 18),
                      badge,
                    ]),
            ),
          ),
        ),
        Container(
          width: double.infinity,
          color: _footer2,
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
          child: Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 1240),
              child: Wrap(alignment: WrapAlignment.spaceBetween, crossAxisAlignment: WrapCrossAlignment.center, runSpacing: 8, spacing: 16, children: [
                Text('© ${DateTime.now().year} MAYA. Tous droits réservés. Une marketplace innovante au service du commerce en Afrique.', style: const TextStyle(color: Colors.white70, fontSize: 11.5)),
                const Text('Ensemble, faisons grandir le commerce !', style: TextStyle(color: _yellow, fontStyle: FontStyle.italic, fontWeight: FontWeight.w700, fontSize: 15, decoration: TextDecoration.underline, decorationColor: _yellow)),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}

// ======================================================================================
//  Résultats de recherche : boutiques correspondantes + accès aux produits
// ======================================================================================
class _SearchResults extends StatelessWidget {
  final String query;
  const _SearchResults({required this.query});

  Future<List<Map<String, dynamic>>> _shops() async {
    final t = query.replaceAll(RegExp(r'[%,()]'), '');
    return List<Map<String, dynamic>>.from(await sb.from('shops').select('id, slug, name, city').eq('status', 'active').ilike('name', '%$t%').limit(20));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text('Recherche : $query'), bottom: const MaliStripe()),
        body: ListView(padding: const EdgeInsets.all(14), children: [
          FilledButton.icon(
            icon: const Icon(Icons.search),
            label: Text('Voir les produits pour « $query »'),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductsScreen(initialQuery: query, title: 'Recherche'))),
          ),
          const SizedBox(height: 16),
          const Text('Boutiques correspondantes', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
          FutureBuilder<List<Map<String, dynamic>>>(
            future: _shops(),
            builder: (context, snap) {
              if (snap.hasError) return Padding(padding: const EdgeInsets.all(12), child: Text('Erreur : ${snap.error}'));
              if (!snap.hasData) return const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator()));
              if (snap.data!.isEmpty) return const Padding(padding: EdgeInsets.symmetric(vertical: 14), child: Text('Aucune boutique ne porte ce nom.'));
              return Column(children: [
                for (final s in snap.data!)
                  Card(
                    child: ListTile(
                      leading: const CircleAvatar(backgroundColor: _lav, child: Icon(Icons.storefront, color: brand)),
                      title: Text('${s['name']}'),
                      subtitle: s['city'] == null ? null : Text('${s['city']}'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopPage(slug: '${s['slug']}'))),
                    ),
                  ),
              ]);
            },
          ),
        ]),
      );
}

// ======================================================================================
//  Conditions d'utilisation et politique de confidentialité
// ======================================================================================
class LegalScreen extends StatelessWidget {
  final bool privacy;
  const LegalScreen({super.key, required this.privacy});

  static const _terms = <(String, String)>[
    ('1. Objet', 'MAYA est une marketplace qui met en relation des acheteurs, des vendeurs et des livreurs. Consulter MAYA est libre ; l\'achat, la vente et la messagerie nécessitent un compte.'),
    ('2. Compte', 'Vous fournissez des informations exactes (nom, ville, téléphone, e-mail) et protégez votre mot de passe. Vous êtes responsable des actions faites avec votre compte.'),
    ('3. Vendeurs', 'L\'accès vendeur est accordé après examen d\'une demande et d\'une pièce d\'identité. Les produits sont soumis à validation. Le vendeur décrit ses produits avec exactitude et reste responsable du livreur qu\'il désigne lui-même.'),
    ('4. Commandes et paiements', 'Une commande est confirmée par le récapitulatif envoyé au client. Le paiement est confirmé uniquement par le serveur. Les gains du vendeur sont bloqués jusqu\'à la confirmation « Colis reçu » du client.'),
    ('5. Livraison', 'La livraison est assurée par un transporteur partenaire MAYA vérifié ou par un livreur désigné par le vendeur. Le client confirme la réception ; en cas de problème il ouvre un signalement que l\'administration examine.'),
    ('6. Comportements interdits', 'Fraude, contenus illicites ou trompeurs, harcèlement et usage détourné des coordonnées d\'autrui sont interdits et peuvent entraîner la suspension du compte, de la boutique ou du livreur.'),
    ('7. Responsabilité', 'MAYA met en relation et sécurise les étapes décrites ci-dessus, mais n\'est pas partie au contrat de vente entre acheteur et vendeur, sauf mention contraire.'),
    ('8. Modifications', 'Ces conditions peuvent évoluer ; la date de dernière mise à jour est indiquée en bas de page.'),
  ];

  static const _priv = <(String, String)>[
    ('1. Données collectées', 'Nom, ville, téléphone, e-mail, commandes, messages et pièces justificatives des vendeurs. Les positions GPS ne sont lues qu\'avec votre accord.'),
    ('2. Utilisation', 'Vos données servent à gérer votre compte, vos commandes, les livraisons, la messagerie, la prévention de la fraude et l\'assistance.'),
    ('3. Partage', 'Vos informations ne sont visibles que des personnes concernées par une commande (vendeur, livreur) et de l\'administration MAYA. Elles ne sont pas vendues.'),
    ('4. Position GPS', 'Le partage de position est volontaire, limité à la durée de la mission, arrêtable à tout moment et supprimé à la fin ou à l\'annulation de la livraison. Le suivi fonctionne tant que l\'application reste ouverte.'),
    ('5. Sécurité', 'Les accès aux données sont restreints côté serveur par des règles de sécurité par utilisateur ; les pièces d\'identité sont stockées dans un espace privé.'),
    ('6. Vos droits', 'Vous pouvez consulter et corriger vos informations dans votre compte, et demander leur suppression en contactant l\'administration.'),
    ('7. Contact', 'Pour toute question sur vos données, utilisez « Nous contacter ».'),
  ];

  @override
  Widget build(BuildContext context) {
    final list = privacy ? _priv : _terms;
    return Scaffold(
      appBar: AppBar(title: Text(privacy ? 'Politique de confidentialité' : 'Conditions d\'utilisation'), bottom: const MaliStripe()),
      body: Align(
        alignment: Alignment.topCenter,
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 800),
          child: ListView(padding: const EdgeInsets.all(18), children: [
            for (final s in list) ...[
              Text(s.$1, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16, color: _title)),
              const SizedBox(height: 4),
              Text(s.$2, style: const TextStyle(fontSize: 14.5, height: 1.5)),
              const SizedBox(height: 14),
            ],
            const Text('Dernière mise à jour : 16/11/2026', style: TextStyle(fontSize: 12, color: Colors.black54)),
          ]),
        ),
      ),
    );
  }
}
