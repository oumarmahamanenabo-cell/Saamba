import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'common.dart';

const maxImages = 10;
const maxVideos = 2;
const maxVideoBytes = 30 * 1024 * 1024;

class MediaItem {
  String? id; // null = pas encore enregistré en base
  final String kind; // image | video
  String? path; // chemin dans le stockage (élément existant)
  File? file; // fichier local à envoyer
  MediaItem({this.id, required this.kind, this.path, this.file});
}

String _bucket(String kind) => kind == 'video' ? 'product-videos' : 'product-images';

/// Charge les médias d'un produit (avec reprise de l'ancienne photo unique si besoin).
Future<List<MediaItem>> loadProductMedia(Map<String, dynamic> product) async {
  final rows = await sb.from('product_media').select().eq('product_id', product['id']).order('is_primary', ascending: false).order('position');
  final items = [for (final r in rows) MediaItem(id: r['id'] as String, kind: r['kind'] as String, path: r['path'] as String)];
  final legacy = product['image_path'] as String?;
  if (items.isEmpty && legacy != null && legacy.isNotEmpty) items.add(MediaItem(kind: 'image', path: legacy));
  return items;
}

/// Enregistre les changements : suppressions, envois, ordre et image principale.
Future<void> saveProductMedia(String productId, List<MediaItem> items, List<MediaItem> removed) async {
  for (final r in removed) {
    if (r.id != null) await sb.from('product_media').delete().eq('id', r.id!);
    if (r.path != null) {
      try {
        await sb.storage.from(_bucket(r.kind)).remove([r.path!]);
      } catch (_) {}
    }
  }
  var imageSeen = false;
  for (var i = 0; i < items.length; i++) {
    final it = items[i];
    final primary = it.kind == 'image' && !imageSeen;
    if (it.kind == 'image') imageSeen = true;
    if (it.file != null) {
      final low = it.file!.path.toLowerCase();
      final ext = it.kind == 'video'
          ? (low.endsWith('.mov') ? 'mov' : (low.endsWith('.webm') ? 'webm' : 'mp4'))
          : (low.endsWith('.png') ? 'png' : (low.endsWith('.webp') ? 'webp' : 'jpg'));
      final path = '$uid/${productId}_${DateTime.now().microsecondsSinceEpoch}_$i.$ext';
      await sb.storage.from(_bucket(it.kind)).upload(path, it.file!, fileOptions: FileOptions(contentType: mimeFor(path)));
      await sb.from('product_media').insert({
        'product_id': productId,
        'owner_id': uid,
        'kind': it.kind,
        'path': path,
        'position': i,
        'is_primary': primary,
        'size_bytes': await it.file!.length(),
      });
    } else if (it.id == null && it.path != null) {
      await sb.from('product_media').insert({
        'product_id': productId,
        'owner_id': uid,
        'kind': it.kind,
        'path': it.path,
        'position': i,
        'is_primary': primary,
      });
    } else if (it.id != null) {
      await sb.from('product_media').update({'position': i, 'is_primary': primary}).eq('id', it.id!);
    }
  }
}

/// Éditeur : plusieurs photos (galerie du téléphone), vidéos, aperçu, ordre, image principale.
class MediaEditor extends StatefulWidget {
  final List<MediaItem> items;
  final List<MediaItem> removed;
  const MediaEditor({super.key, required this.items, required this.removed});
  @override
  State<MediaEditor> createState() => _MediaEditorState();
}

class _MediaEditorState extends State<MediaEditor> {
  int _count(String k) => widget.items.where((e) => e.kind == k).length;

  Future<void> _addImages() async {
    final room = maxImages - _count('image');
    if (room <= 0) return snack(context, 'Maximum $maxImages photos par produit.');
    final xs = await ImagePicker().pickMultiImage(imageQuality: 70, maxWidth: 1280);
    if (xs.isEmpty) return;
    setState(() {
      for (final x in xs.take(room)) {
        widget.items.add(MediaItem(kind: 'image', file: File(x.path)));
      }
    });
    if (xs.length > room && mounted) snack(context, 'Seules $room photos ont été ajoutées (maximum $maxImages).');
  }

  Future<void> _addVideo() async {
    if (_count('video') >= maxVideos) return snack(context, 'Maximum $maxVideos vidéos par produit.');
    final x = await ImagePicker().pickVideo(source: ImageSource.gallery, maxDuration: const Duration(seconds: 45));
    if (x == null) return;
    final f = File(x.path);
    if (await f.length() > maxVideoBytes) {
      if (mounted) snack(context, 'Vidéo trop lourde (30 Mo maximum). Choisissez une vidéo plus courte.');
      return;
    }
    if (mounted) setState(() => widget.items.add(MediaItem(kind: 'video', file: f)));
  }

  void _move(int i, int d) {
    final j = i + d;
    if (j < 0 || j >= widget.items.length) return;
    setState(() {
      final it = widget.items.removeAt(i);
      widget.items.insert(j, it);
    });
  }

  void _remove(int i) => setState(() => widget.removed.add(widget.items.removeAt(i)));

  void _makePrimary(int i) => setState(() {
        final it = widget.items.removeAt(i);
        widget.items.insert(0, it);
      });

  Widget _tile(int i) {
    final it = widget.items[i];
    final firstImage = it.kind == 'image' && widget.items.indexWhere((e) => e.kind == 'image') == i;
    Widget thumb;
    if (it.kind == 'video') {
      thumb = Container(color: Colors.black87, child: const Center(child: Icon(Icons.play_circle_outline, color: Colors.white, size: 40)));
    } else if (it.file != null) {
      thumb = Image.file(it.file!, fit: BoxFit.cover);
    } else {
      final url = sb.storage.from('product-images').getPublicUrl(it.path!);
      thumb = Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image));
    }
    return Container(
      width: 112,
      margin: const EdgeInsets.only(right: 8),
      decoration: softBox(),
      child: Column(children: [
        Expanded(
          child: Stack(children: [
            Positioned.fill(child: ClipRRect(borderRadius: const BorderRadius.vertical(top: Radius.circular(14)), child: thumb)),
            if (firstImage)
              Positioned(left: 4, top: 4, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), decoration: BoxDecoration(color: brand, borderRadius: BorderRadius.circular(8)), child: const Text('Principale', style: TextStyle(color: Colors.white, fontSize: 10)))),
            Positioned(right: 0, top: 0, child: InkWell(onTap: () => _remove(i), child: const Padding(padding: EdgeInsets.all(4), child: CircleAvatar(radius: 12, backgroundColor: maliRed, child: Icon(Icons.close, size: 14, color: Colors.white))))),
          ]),
        ),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
          InkWell(onTap: () => _move(i, -1), child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.chevron_left, size: 20))),
          if (it.kind == 'image' && !firstImage) InkWell(onTap: () => _makePrimary(i), child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.star_border, size: 20))),
          InkWell(onTap: () => _move(i, 1), child: const Padding(padding: EdgeInsets.all(6), child: Icon(Icons.chevron_right, size: 20))),
        ]),
      ]),
    );
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(
          height: 150,
          child: widget.items.isEmpty
              ? Container(decoration: softBox(), child: const Center(child: Text('Aucune photo ni vidéo. Ajoutez-en ci-dessous.')))
              : ListView.builder(scrollDirection: Axis.horizontal, itemCount: widget.items.length, itemBuilder: (_, i) => _tile(i)),
        ),
        const SizedBox(height: 8),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: _addImages, icon: const Icon(Icons.add_photo_alternate_outlined), label: Text('Photos (${_count('image')}/$maxImages)'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: _addVideo, icon: const Icon(Icons.videocam_outlined), label: Text('Vidéo (${_count('video')}/$maxVideos)'))),
        ]),
        const Padding(padding: EdgeInsets.only(top: 4), child: Text('La première photo est la photo principale. Les photos sont réduites automatiquement avant l\'envoi.', style: TextStyle(fontSize: 11, color: Colors.black54))),
      ]);
}
