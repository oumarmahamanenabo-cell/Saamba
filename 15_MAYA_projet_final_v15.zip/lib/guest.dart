import 'package:flutter/material.dart';
import 'auth.dart';
import 'common.dart';
import 'delivery_courier.dart' show JoinDeliveryScreen;
import 'seller_apply.dart';

bool get isLoggedIn => sb.auth.currentUser != null;

/// Garde d'accès côté application : si le visiteur n'est pas connecté, affiche une fenêtre élégante
/// (Se connecter / Créer un compte) puis ouvre l'écran de connexion.
/// Retourne `true` seulement si une session est ouverte à la fin.
/// (La vraie protection est dans la base : RLS + fonctions réservées aux comptes connectés.)
Future<bool> requireAuth(
  BuildContext context, {
  String reason = 'Cette fonctionnalité est réservée aux membres MAYA.',
  String? banner,
}) async {
  if (isLoggedIn) return true;
  // Le navigateur est capturé avant les attentes : il reste valide même si l'écran d'origine disparaît après la connexion.
  final nav = Navigator.of(context);
  final choice = await showDialog<String>(
    context: context,
    builder: (ctx) => Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
      insetPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 24),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 420),
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 22, 22, 14),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const LogoBadge(size: 64),
            const SizedBox(height: 12),
            const Text('Rejoignez MAYA', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w800, color: brandDark)),
            const SizedBox(height: 8),
            Text(reason, textAlign: TextAlign.center, style: const TextStyle(fontSize: 14, height: 1.35)),
            const SizedBox(height: 6),
            const Text('Parcourir les boutiques et les produits reste libre, sans compte.',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 18),
            SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: () => Navigator.pop(ctx, 'login'), icon: const Icon(Icons.login), label: const Text('Se connecter'))),
            const SizedBox(height: 8),
            SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(onPressed: () => Navigator.pop(ctx, 'register'), icon: const Icon(Icons.person_add_alt_1), label: const Text('Créer un compte'))),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Plus tard')),
          ]),
        ),
      ),
    ),
  );
  if (choice == null) return false;
  await nav.push<bool>(MaterialPageRoute(builder: (_) => AuthScreen(initialRegister: choice == 'register', banner: banner)));
  return isLoggedIn;
}

/// Onglet « Mon compte » du visiteur : connexion, création de compte, devenir vendeur, informations.
class GuestAccount extends StatelessWidget {
  const GuestAccount({super.key});

  Future<void> _open(BuildContext context, bool register) =>
      Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => AuthScreen(initialRegister: register)));

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
        const MayaFullLogo(width: 220),
        const SizedBox(height: 10),
        const Text('Vous naviguez en visiteur', textAlign: TextAlign.center, style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: brandDark)),
        const SizedBox(height: 6),
        const Text(
          'Découvrez librement toutes les boutiques et tous les produits. Un compte est nécessaire pour commander, '
          'ajouter des favoris, écrire à un vendeur ou vendre sur MAYA.',
          textAlign: TextAlign.center,
          style: TextStyle(height: 1.4),
        ),
        const SizedBox(height: 16),
        FilledButton.icon(onPressed: () => _open(context, false), icon: const Icon(Icons.login), label: const Text('Se connecter')),
        const SizedBox(height: 8),
        OutlinedButton.icon(onPressed: () => _open(context, true), icon: const Icon(Icons.person_add_alt_1), label: const Text('Créer un compte')),
        const SizedBox(height: 8),
        FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.white),
          onPressed: () => startSellerFlow(context),
          icon: const Icon(Icons.storefront),
          label: const Text('Devenir vendeur'),
        ),
        const SizedBox(height: 8),
        TextButton.icon(
          onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const JoinDeliveryScreen())),
          icon: const Icon(Icons.vpn_key_outlined),
          label: const Text('Livreur invité ? Rejoindre une livraison'),
        ),
        const SizedBox(height: 4),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.info_outline),
          title: const Text('À propos de MAYA'),
          subtitle: const Text('Comment ça marche, achat, vente, livraison'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AboutMayaScreen())),
        ),
      ]);
}

/// Pages de présentation et d'information de MAYA (publiques).
class AboutMayaScreen extends StatelessWidget {
  const AboutMayaScreen({super.key});

  Widget _block(IconData i, String t, String d) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: softBox(),
        child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
          CircleAvatar(backgroundColor: const Color(0xFFFFF1CF), child: Icon(i, color: brandDark)),
          const SizedBox(width: 12),
          Expanded(
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15)),
            const SizedBox(height: 3),
            Text(d, style: const TextStyle(height: 1.35)),
          ])),
        ]),
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('À propos de MAYA'), bottom: const MaliStripe()),
        body: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: ListView(padding: const EdgeInsets.all(14), children: [
              const HeroBanner(title: 'MAYA, le commerce plus proche de vous'),
              _block(Icons.travel_explore, 'Une marketplace ouverte à tous',
                  'Toutes les boutiques validées, leurs produits, photos, vidéos, prix et promotions sont consultables librement, sans inscription.'),
              _block(Icons.shopping_bag_outlined, 'Acheter en confiance',
                  'Pour commander, ajouter un favori ou écrire à un vendeur, créez un compte gratuit. Le paiement est sécurisé : le vendeur n\'est payé qu\'après votre confirmation de réception.'),
              _block(Icons.storefront_outlined, 'Vendre sur MAYA',
                  'Créez un compte, demandez à devenir vendeur, renseignez votre boutique et envoyez vos documents de vérification. Après validation par l\'administration, vous publiez et gérez vos produits, prix et commandes.'),
              _block(Icons.verified_user_outlined, 'Vendeurs et transporteurs vérifiés',
                  'Chaque vendeur est examiné avant de publier. Les produits sont validés avant d\'apparaître dans la boutique.'),
              _block(Icons.local_shipping_outlined, 'Livraison partout au Mali',
                  'Les colis sont suivis jusqu\'à votre réception. En cas de problème, un signalement est examiné par MAYA.'),
              const SizedBox(height: 8),
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.white),
                onPressed: () => startSellerFlow(context),
                icon: const Icon(Icons.storefront),
                label: const Text('Devenir vendeur'),
              ),
            ]),
          ),
        ),
      );
}
