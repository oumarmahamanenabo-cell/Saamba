import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:share_plus/share_plus.dart';
import 'package:video_player/video_player.dart';
import 'common.dart';
import 'config.dart';

String productLink(String id) => '$shareBaseUrl/product/$id';
String shopLink(String slug) => '$shareBaseUrl/boutique/$slug';

String? storageUrl(String bucket, String? path) =>
    (path == null || path.isEmpty) ? null : sb.storage.from(bucket).getPublicUrl(path);

Future<void> copyLink(BuildContext c, String link) async {
  await Clipboard.setData(ClipboardData(text: link));
  if (c.mounted) snack(c, 'Lien copié.');
}

/// Ouvre le menu de partage Android (WhatsApp, Facebook, Telegram, SMS, etc.).
Future<void> shareLink(BuildContext c, String text, {String? subject}) async {
  try {
    await Share.share(text, subject: subject);
  } catch (e) {
    if (c.mounted) snack(c, 'Partage impossible : $e');
  }
}

/// Galerie consultable par les clients : photos (plein écran au toucher) et vidéos.
class MediaGallery extends StatefulWidget {
  /// Éléments {kind: image|video, path: chemin de stockage}
  final List<Map<String, dynamic>> media;
  const MediaGallery({super.key, required this.media});
  @override
  State<MediaGallery> createState() => _MediaGalleryState();
}

class _MediaGalleryState extends State<MediaGallery> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final m = widget.media;
    if (m.isEmpty) {
      return Container(height: 240, color: const Color(0xFFEFF3EE), child: const Center(child: Icon(Icons.image_outlined, size: 64, color: Color(0xFFB8C9B8))));
    }
    return Column(children: [
      SizedBox(
        height: 280,
        child: PageView.builder(
          itemCount: m.length,
          onPageChanged: (v) => setState(() => _i = v),
          itemBuilder: (_, k) {
            final it = m[k];
            final isVideo = it['kind'] == 'video';
            final url = storageUrl(isVideo ? 'product-videos' : 'product-images', it['path'] as String?);
            if (url == null) return const Center(child: Icon(Icons.broken_image));
            if (isVideo) return VideoTile(url: url);
            return GestureDetector(
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => _FullImage(url: url))),
              child: Image.network(url, fit: BoxFit.cover, width: double.infinity, errorBuilder: (_, __, ___) => const Center(child: Icon(Icons.broken_image))),
            );
          },
        ),
      ),
      if (m.length > 1)
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
            for (var k = 0; k < m.length; k++)
              Container(
                width: 8,
                height: 8,
                margin: const EdgeInsets.symmetric(horizontal: 3),
                decoration: BoxDecoration(shape: BoxShape.circle, color: k == _i ? brand : const Color(0xFFCFD8CF)),
              ),
          ]),
        ),
    ]);
  }
}

class _FullImage extends StatelessWidget {
  final String url;
  const _FullImage({required this.url});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(backgroundColor: Colors.black, foregroundColor: Colors.white),
        body: Center(child: InteractiveViewer(child: Image.network(url, fit: BoxFit.contain, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image, color: Colors.white)))),
      );
}

/// Lecteur vidéo intégré à la fiche produit.
class VideoTile extends StatefulWidget {
  final String url;
  const VideoTile({super.key, required this.url});
  @override
  State<VideoTile> createState() => _VideoTileState();
}

class _VideoTileState extends State<VideoTile> {
  late final VideoPlayerController _c = VideoPlayerController.networkUrl(Uri.parse(widget.url));
  bool _ready = false, _failed = false;

  @override
  void initState() {
    super.initState();
    _c.initialize().then((_) {
      if (mounted) setState(() => _ready = true);
    }).catchError((_) {
      if (mounted) setState(() => _failed = true);
    });
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_failed) return const Center(child: Text('Vidéo indisponible'));
    if (!_ready) return const ColoredBox(color: Colors.black, child: Center(child: CircularProgressIndicator()));
    return ColoredBox(
      color: Colors.black,
      child: Stack(alignment: Alignment.center, children: [
        Center(child: AspectRatio(aspectRatio: _c.value.aspectRatio, child: VideoPlayer(_c))),
        IconButton(
          iconSize: 56,
          color: Colors.white,
          icon: Icon(_c.value.isPlaying ? Icons.pause_circle_outline : Icons.play_circle_outline),
          onPressed: () => setState(() => _c.value.isPlaying ? _c.pause() : _c.play()),
        ),
      ]),
    );
  }
}
