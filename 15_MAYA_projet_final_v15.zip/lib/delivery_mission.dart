import 'dart:async';
import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'chat.dart';
import 'common.dart';
import 'delivery_common.dart';
import 'delivery_seller.dart';

List<Map<String, dynamic>> _list(dynamic v) =>
    v is List ? List<Map<String, dynamic>>.from(v.map((e) => Map<String, dynamic>.from(e as Map))) : <Map<String, dynamic>>[];

/// Résultat d'une saisie de lieu : adresse écrite et/ou position GPS (jamais inventée).
class PlaceInput {
  final String? address;
  final LatLng? point;
  const PlaceInput(this.address, this.point);
}

/// Boîte de saisie d'un lieu : adresse écrite, position GPS actuelle (avec accord) ou repère déplacé sur la carte.
Future<PlaceInput?> askPlace(BuildContext context, {required String title, String? initialAddress, LatLng? initialPoint, String gpsPurpose = ''}) {
  final addr = TextEditingController(text: initialAddress);
  LatLng? point = initialPoint;
  return showDialog<PlaceInput>(
    context: context,
    builder: (ctx) => StatefulBuilder(
      builder: (ctx, setS) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
            TextField(controller: addr, maxLines: 2, decoration: const InputDecoration(labelText: 'Adresse écrite (quartier, rue, repère…)')),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              icon: const Icon(Icons.my_location),
              label: const Text('Partager ma position GPS actuelle'),
              onPressed: () async {
                final pos = await askAndGetPosition(ctx, purpose: gpsPurpose.isEmpty ? 'MAYA va lire votre position actuelle une seule fois.' : gpsPurpose);
                if (pos != null) setS(() => point = LatLng(pos.latitude, pos.longitude));
              },
            ),
            const SizedBox(height: 6),
            OutlinedButton.icon(
              icon: const Icon(Icons.pin_drop_outlined),
              label: const Text('Placer un repère sur la carte'),
              onPressed: () async {
                final p = await pickOnMap(ctx, start: point);
                if (p != null) setS(() => point = p);
              },
            ),
            if (point != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Row(children: [
                  const Icon(Icons.check_circle, color: brand, size: 18),
                  const SizedBox(width: 6),
                  Expanded(child: Text('Position GPS prête (${point!.latitude.toStringAsFixed(5)}, ${point!.longitude.toStringAsFixed(5)})', style: const TextStyle(fontSize: 12))),
                  IconButton(icon: const Icon(Icons.close, size: 18), onPressed: () => setS(() => point = null)),
                ]),
              ),
            const SizedBox(height: 4),
            const Text('Si le GPS n\'est pas disponible, une adresse écrite suffit.', style: TextStyle(fontSize: 11.5, color: Colors.black54)),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
          FilledButton(
            onPressed: () {
              final a = addr.text.trim();
              if (point == null && a.length < 3) {
                snack(ctx, 'Indiquez une adresse ou une position GPS.');
                return;
              }
              Navigator.pop(ctx, PlaceInput(a.isEmpty ? null : a, point));
            },
            child: const Text('Enregistrer'),
          ),
        ],
      ),
    ),
  );
}

// ======================================================================================
//  Page unique de suivi d'une mission (vendeur, client, transporteur / livreur, admin)
// ======================================================================================
class MissionScreen extends StatefulWidget {
  final String missionId;
  const MissionScreen({super.key, required this.missionId});
  @override
  State<MissionScreen> createState() => _MissionScreenState();
}

class _MissionScreenState extends State<MissionScreen> {
  Map<String, dynamic>? _m;
  Object? _err;
  Timer? _poll;
  StreamSubscription<Position>? _gps;
  DateTime _lastPush = DateTime.fromMillisecondsSinceEpoch(0);
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
    _poll = Timer.periodic(const Duration(seconds: 15), (_) {
      final s = _m?['status'] as String?;
      if (mounted && !_busy && (s == null || !deliveryFinalStatuses.contains(s))) _load(silent: true);
    });
  }

  @override
  void dispose() {
    _poll?.cancel();
    _gps?.cancel();
    super.dispose();
  }

  Future<void> _load({bool silent = false}) async {
    try {
      final r = await sb.rpc('delivery_mission_detail', params: {'p_mission': widget.missionId});
      if (!mounted) return;
      setState(() {
        _m = Map<String, dynamic>.from(r as Map);
        _err = null;
      });
      _syncGps();
    } catch (e) {
      if (mounted && !silent) setState(() => _err = e);
    }
  }

  /// Une action de l'utilisateur : exécution protégée puis rechargement.
  Future<void> _act(Future<void> Function() f) async {
    setState(() => _busy = true);
    try {
      await guarded(context, f);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
    await _load(silent: true);
  }

  String get _role => (_m?['role'] as String?) ?? '';
  String get _status => (_m?['status'] as String?) ?? '';

  // ---------------------------------------------------------------- GPS du livreur (premier plan uniquement)
  void _syncGps() {
    final m = _m;
    final want = m != null && _role == 'courier' && m['gps_enabled'] == true && deliveryActiveStatuses.contains(_status);
    if (want && _gps == null) {
      _startGps();
    } else if (!want && _gps != null) {
      _gps?.cancel();
      _gps = null;
    }
  }

  void _startGps() {
    try {
      _gps = Geolocator.getPositionStream(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, distanceFilter: 15)).listen(
        (p) async {
          if (DateTime.now().difference(_lastPush).inSeconds < 8) return;
          _lastPush = DateTime.now();
          try {
            await sb.rpc('delivery_live_update', params: {'p_mission': widget.missionId, 'p_lat': p.latitude, 'p_lng': p.longitude, 'p_accuracy': p.accuracy});
          } catch (_) {}
        },
        onError: (_) {},
      );
    } catch (_) {
      _gps = null;
    }
  }

  Future<void> _toggleGps(bool on) async {
    if (on) {
      final ok = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Partager ma position en direct ?'),
          content: const Text('Le vendeur et le client de cette livraison verront votre position sur la carte.\n\n'
              '• Le partage fonctionne tant que MAYA reste ouverte à l\'écran (pas de suivi en arrière-plan).\n'
              '• Il s\'arrête automatiquement quand la livraison est terminée ou annulée.\n'
              '• Vous pouvez l\'arrêter à tout moment.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Activer')),
          ],
        ),
      );
      if (ok != true || !mounted) return;
      if (!await ensureLocationPermission(context)) return;
    }
    await _act(() async {
      await sb.rpc('delivery_set_gps', params: {'p_mission': widget.missionId, 'p_enabled': on});
      if (on) {
        try {
          final p = await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 15)));
          await sb.rpc('delivery_live_update', params: {'p_mission': widget.missionId, 'p_lat': p.latitude, 'p_lng': p.longitude, 'p_accuracy': p.accuracy});
          _lastPush = DateTime.now();
        } catch (_) {}
      }
    });
  }

  // ---------------------------------------------------------------- Actions
  Future<void> _setStatus(String s, {String? note}) => _act(() async {
        await sb.rpc('delivery_update_status', params: {'p_mission': widget.missionId, 'p_status': s, 'p_note': note});
        if (mounted) snack(context, deliveryLabel(s));
      });

  Future<void> _courierRespond(bool accept) async {
    DateTime? est;
    if (accept) {
      final choice = await showDialog<String>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Accepter la livraison'),
          content: const Text('Voulez-vous indiquer la date et l\'heure estimées de livraison ?'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
            TextButton(onPressed: () => Navigator.pop(ctx, 'skip'), child: const Text('Accepter sans heure')),
            FilledButton(onPressed: () => Navigator.pop(ctx, 'pick'), child: const Text('Choisir l\'heure')),
          ],
        ),
      );
      if (choice == null || !mounted) return;
      if (choice == 'pick') {
        est = await pickDateTime(context);
        if (est == null) return;
      }
    } else {
      final sure = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Refuser cette mission ?'),
          content: const Text('Le vendeur sera prévenu et devra désigner un autre livreur.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Retour')),
            FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(ctx, true), child: const Text('Refuser')),
          ],
        ),
      );
      if (sure != true) return;
    }
    await _act(() async {
      await sb.rpc('delivery_courier_respond', params: {'p_mission': widget.missionId, 'p_accept': accept, 'p_est': est?.toUtc().toIso8601String()});
      if (mounted) snack(context, accept ? 'Mission acceptée. La conversation de livraison est ouverte.' : 'Mission refusée.');
    });
  }

  Future<void> _setEta() async {
    final cur = DateTime.tryParse('${_m?['est_delivery_at']}')?.toLocal();
    final d = await pickDateTime(context, initial: cur != null && cur.isAfter(DateTime.now()) ? cur : null);
    if (d == null) return;
    await _act(() async {
      await sb.rpc('delivery_set_eta', params: {'p_mission': widget.missionId, 'p_est': d.toUtc().toIso8601String()});
    });
  }

  Future<void> _incident() async {
    String kind = 'client_absent';
    final note = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Signaler un incident ou un retard'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(
                value: kind,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Type'),
                items: [for (final e in deliveryIncidentKinds.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                onChanged: (v) => setS(() => kind = v ?? kind),
              ),
              TextField(controller: note, maxLines: 3, decoration: const InputDecoration(labelText: 'Précisions (cause, durée…)')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Signaler')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    await _act(() async {
      await sb.rpc('delivery_report_incident', params: {'p_mission': widget.missionId, 'p_kind': kind, 'p_note': note.text.trim()});
      if (mounted) snack(context, 'Signalement enregistré. Les personnes concernées sont prévenues.');
    });
  }

  Future<void> _resume() async {
    final t = await askText(context, 'Incident résolu : un commentaire ? (facultatif)');
    if (t == null) return;
    await _act(() async {
      await sb.rpc('delivery_resume', params: {'p_mission': widget.missionId, 'p_note': t});
    });
  }

  Future<void> _cancel() async {
    final t = await askText(context, 'Motif de l\'annulation');
    if (t == null) return;
    await _act(() async {
      await sb.rpc('delivery_cancel', params: {'p_mission': widget.missionId, 'p_reason': t});
    });
  }

  Future<void> _setPickup() async {
    final r = await askPlace(context,
        title: 'Lieu de récupération du colis',
        initialAddress: _m?['pickup_address'] as String?,
        initialPoint: latLngOf(_m?['pickup_lat'], _m?['pickup_lng']),
        gpsPurpose: 'MAYA va lire votre position actuelle pour indiquer l\'emplacement de votre magasin au livreur.');
    if (r == null) return;
    await _act(() async {
      await sb.rpc('delivery_seller_set_pickup', params: {'p_mission': widget.missionId, 'p_address': r.address, 'p_lat': r.point?.latitude, 'p_lng': r.point?.longitude});
      if (mounted) snack(context, 'Lieu de récupération enregistré.');
    });
  }

  Future<void> _clientLocation() async {
    final r = await askPlace(context,
        title: 'Où livrer mon colis ?',
        initialAddress: _m?['dropoff_address'] as String?,
        initialPoint: latLngOf(_m?['dropoff_lat'], _m?['dropoff_lng']),
        gpsPurpose: 'MAYA va lire votre position actuelle pour la transmettre au vendeur et au livreur de votre commande.');
    if (r == null) return;
    await _act(() async {
      await sb.rpc('delivery_client_set_location',
          params: {'p_mission': widget.missionId, 'p_lat': r.point?.latitude, 'p_lng': r.point?.longitude, 'p_address': r.address, 'p_clear': false});
      if (mounted) snack(context, 'Lieu de livraison transmis.');
    });
  }

  Future<void> _clientClearLocation() => _act(() async {
        await sb.rpc('delivery_client_set_location', params: {'p_mission': widget.missionId, 'p_lat': null, 'p_lng': null, 'p_address': null, 'p_clear': true});
        if (mounted) snack(context, 'Votre position GPS a été retirée.');
      });

  Future<void> _confirmReception(bool received) async {
    String? note;
    if (received) {
      final sure = await showDialog<bool>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Confirmer la réception ?'),
          content: const Text('Ne confirmez que si vous avez réellement reçu votre colis et vérifié son contenu.\n\n'
              'Cette confirmation paie le vendeur et ne peut pas être annulée.'),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Retour')),
            FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Oui, j\'ai reçu mon colis')),
          ],
        ),
      );
      if (sure != true) return;
    } else {
      note = await askText(context, 'Que s\'est-il passé ? (facultatif)');
      if (note == null) return;
    }
    await _act(() async {
      await sb.rpc('confirm_delivery', params: {'p_order_id': _m!['order_id'], 'p_received': received, 'p_note': note});
      if (mounted) snack(context, received ? 'Réception confirmée. Merci !' : 'Signalement ouvert : l\'administration va traiter votre litige.');
    });
  }

  Future<void> _newInvite() async {
    await _act(() async {
      final r = Map<String, dynamic>.from(await sb.rpc('delivery_invite_create', params: {'p_mission': widget.missionId}) as Map);
      final c = _m?['courier'] as Map?;
      if (!mounted) return;
      await showInviteDialog(context,
          courierName: (c?['name'] as String?) ?? 'le livreur',
          courierPhone: (c?['phone'] as String?) ?? '',
          orderNumber: (_m?['order_number'] as String?) ?? '',
          token: r['token'] as String,
          pin: r['pin'] as String,
          expiresAt: r['expires_at']);
    });
  }

  Future<void> _revokeInvite() => _act(() async {
        await sb.rpc('delivery_invite_revoke', params: {'p_mission': widget.missionId});
        if (mounted) snack(context, 'Invitation révoquée.');
      });

  Future<void> _retrySearch() => _act(() async {
        await sb.rpc('delivery_retry_search', params: {'p_mission': widget.missionId});
      });

  Future<void> _ownCourier() async {
    final m = _m!;
    await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (_) => OrganizeDeliveryScreen(
                orderId: m['order_id'] as String, orderNumber: (m['order_number'] as String?) ?? '', clientCity: m['dropoff_city'] as String?, startOnOwn: true)));
    _load(silent: true);
  }

  void _openChat() {
    final id = _m?['conversation_id'] as String?;
    if (id == null) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(conversationId: id, title: 'Livraison ${_m?['order_number'] ?? ''}')));
  }

  // ---------------------------------------------------------------- Interface
  @override
  Widget build(BuildContext context) {
    final m = _m;
    final title = m == null ? 'Livraison' : (_role == 'client' ? 'Suivre mon colis' : 'Livraison ${m['order_number']}');
    if (_err != null && m == null) return Scaffold(appBar: AppBar(title: Text(title)), body: errorView(_err));
    if (m == null) return Scaffold(appBar: AppBar(title: Text(title)), body: const Center(child: CircularProgressIndicator()));
    return Scaffold(
      appBar: AppBar(title: Text(title), actions: [IconButton(tooltip: 'Actualiser', icon: const Icon(Icons.refresh), onPressed: () => _load())]),
      body: RefreshIndicator(
        onRefresh: () => _load(),
        child: ListView(padding: const EdgeInsets.all(12), children: [
          _header(m),
          const SizedBox(height: 10),
          _trackingCard(m),
          const SizedBox(height: 10),
          ..._actions(m),
          _contacts(m),
          _details(m),
          _offersCard(m),
          _incidentsCard(m),
          _timeline(m),
          const SizedBox(height: 30),
        ]),
      ),
    );
  }

  Widget _card(String title, List<Widget> children, {Color? color}) => Card(
        color: color,
        margin: const EdgeInsets.only(bottom: 10),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            ...children,
          ]),
        ),
      );

  static const _flow = ['carrier_confirmed', 'picked_up', 'in_progress', 'near_client', 'arrived', 'delivered'];

  Widget _header(Map<String, dynamic> m) {
    final s = m['status'] as String;
    final idx = s == 'delivered' ? _flow.length : (_flow.indexOf(s) >= 0 ? _flow.indexOf(s) : (s == 'incident' ? 1 : -1));
    final own = m['kind'] == 'own_courier';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text('Commande ${m['order_number']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 17))),
            DeliveryStatusChip(s),
          ]),
          const SizedBox(height: 6),
          Text(own ? 'Livreur personnel du vendeur (le vendeur en est responsable)' : 'Transporteur partenaire MAYA', style: const TextStyle(fontSize: 12.5, color: Colors.black54)),
          if (m['fee'] != null) Text('Tarif de livraison : ${money(m['fee'])}', style: const TextStyle(fontSize: 12.5)),
          const SizedBox(height: 10),
          if (!deliveryFinalStatuses.contains(s) || s == 'delivered')
            Row(children: [
              for (var i = 0; i < _flow.length; i++) ...[
                Expanded(child: Container(height: 5, decoration: BoxDecoration(color: i < idx ? brand : Colors.black12, borderRadius: BorderRadius.circular(3)))),
                if (i < _flow.length - 1) const SizedBox(width: 3),
              ],
            ]),
          if (!deliveryFinalStatuses.contains(s) || s == 'delivered')
            const Padding(padding: EdgeInsets.only(top: 4), child: Text('Confirmé · Récupéré · En cours · Proche · Arrivé · Livré', style: TextStyle(fontSize: 10.5, color: Colors.black45))),
          if (s == 'cancelled' && (m['cancel_reason'] as String?)?.isNotEmpty == true) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Motif : ${m['cancel_reason']}')),
        ]),
      ),
    );
  }

  Widget _trackingCard(Map<String, dynamic> m) {
    final live = m['live'] as Map?;
    final liveP = live == null ? null : latLngOf(live['lat'], live['lng']);
    final pickup = latLngOf(m['pickup_lat'], m['pickup_lng']);
    final drop = latLngOf(m['dropoff_lat'], m['dropoff_lng']);
    final s = m['status'] as String;
    final active = deliveryActiveStatuses.contains(s);
    final est = m['est_delivery_at'];
    final isLate = est != null && active && DateTime.tryParse('$est')!.isBefore(DateTime.now());
    final hasAnyPoint = liveP != null || pickup != null || drop != null;
    return _card('Suivi', [
      if (hasAnyPoint) DeliveryMap(pickup: pickup, dropoff: drop, courier: liveP),
      if (hasAnyPoint) const SizedBox(height: 4),
      if (hasAnyPoint)
        const Text('Carte : OpenStreetMap. Le tracé exact de la route n\'est pas affiché ; seuls les points réellement partagés le sont.', style: TextStyle(fontSize: 10.5, color: Colors.black45)),
      const SizedBox(height: 6),
      if (liveP != null) ...[
        Row(children: [
          const Icon(Icons.gps_fixed, color: gold, size: 18),
          const SizedBox(width: 6),
          Expanded(child: Text('Position du livreur · dernière mise à jour GPS : ${ago(live!['updated_at'])} (${dt(live['updated_at'])})', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13))),
        ]),
        if (drop != null) Text('Distance à vol d\'oiseau jusqu\'au lieu de livraison : ${distanceText(distanceMeters(liveP, drop))}', style: const TextStyle(fontSize: 12.5)),
      ] else if (active)
        Row(children: const [
          Icon(Icons.location_off, color: Colors.black45, size: 18),
          SizedBox(width: 6),
          Expanded(child: Text('Position en direct non disponible : le livreur n\'a pas activé le partage de sa position. Le statut et le contact restent disponibles.', style: TextStyle(fontSize: 12.5))),
        ])
      else if (!hasAnyPoint)
        const Text('Aucune position partagée pour le moment.', style: TextStyle(fontSize: 12.5, color: Colors.black54)),
      const SizedBox(height: 6),
      if (est != null)
        Text('Heure estimée de livraison (indiquée par le livreur ou le vendeur) : ${dt(est)}${isLate ? ' — dépassée' : ''}',
            style: TextStyle(fontSize: 12.5, color: isLate ? Colors.red : null, fontWeight: isLate ? FontWeight.bold : null))
      else
        const Text('Heure estimée : non communiquée.', style: TextStyle(fontSize: 12.5, color: Colors.black54)),
      if (m['dropoff_address'] != null) Text('Lieu de livraison : ${m['dropoff_address']}${m['dropoff_city'] != null ? ' (${m['dropoff_city']})' : ''}', style: const TextStyle(fontSize: 12.5)),
      if (m['pickup_address'] != null) Text('Lieu de récupération : ${m['pickup_address']}', style: const TextStyle(fontSize: 12.5)),
    ]);
  }

  List<Widget> _actions(Map<String, dynamic> m) {
    final s = _status;
    final role = _role;
    final final_ = deliveryFinalStatuses.contains(s);
    final out = <Widget>[];
    Widget btn(String label, IconData icon, VoidCallback f, {Color? color, bool outlined = false}) {
      final child = Text(label);
      return Padding(
        padding: const EdgeInsets.only(bottom: 8),
        child: SizedBox(
          width: double.infinity,
          child: outlined
              ? OutlinedButton.icon(icon: Icon(icon), label: child, onPressed: _busy ? null : f)
              : FilledButton.icon(style: color == null ? null : FilledButton.styleFrom(backgroundColor: color), icon: Icon(icon), label: child, onPressed: _busy ? null : f),
        ),
      );
    }

    // --- Mission confiée à un livreur personnel : réponse du livreur
    if (role == 'courier' && s == 'own_courier_assigned') {
      out.add(_card('Nouvelle mission', [
        const Text('Le vendeur vous a désigné pour cette livraison. Acceptez-vous la mission ?'),
        const SizedBox(height: 8),
        btn('ACCEPTER LA LIVRAISON', Icons.check, () => _courierRespond(true)),
        btn('Refuser', Icons.close, () => _courierRespond(false), outlined: true),
      ], color: const Color(0xFFFFF4E0)));
    }

    // --- Actions du livreur / transporteur
    if (role == 'courier' && !final_ && s != 'own_courier_assigned') {
      final a = <Widget>[];
      if (s == 'carrier_confirmed') a.add(btn('COLIS RÉCUPÉRÉ', Icons.inventory_2, () => _setStatus('picked_up')));
      if (s == 'picked_up') a.add(btn('DÉMARRER LA LIVRAISON', Icons.play_arrow, () => _setStatus('in_progress')));
      if (s == 'in_progress') a.add(btn('Je suis proche du client', Icons.near_me, () => _setStatus('near_client'), outlined: true));
      if (s == 'in_progress' || s == 'near_client') a.add(btn('JE SUIS ARRIVÉ', Icons.flag, () => _setStatus('arrived'), outlined: s == 'near_client' ? false : true));
      if (s == 'in_progress' || s == 'near_client' || s == 'arrived') a.add(btn('COLIS LIVRÉ', Icons.done_all, () => _setStatus('delivered')));
      if (deliveryActiveStatuses.contains(s)) {
        a.add(SwitchListTile(
          contentPadding: EdgeInsets.zero,
          title: const Text('Partager ma position en direct'),
          subtitle: const Text('Fonctionne tant que MAYA reste ouverte. S\'arrête à la fin de la livraison.', style: TextStyle(fontSize: 11.5)),
          value: m['gps_enabled'] == true,
          onChanged: _busy ? null : _toggleGps,
        ));
      }
      if (a.isNotEmpty) out.add(_card('Mes actions', a));
    }

    // --- Incident en cours
    if (s == 'incident' && (role == 'courier' || role == 'seller' || role == 'admin')) {
      out.add(_card('Incident en cours', [
        const Text('La livraison est en pause. Quand le problème est réglé, reprenez la livraison.'),
        const SizedBox(height: 8),
        btn('REPRENDRE LA LIVRAISON', Icons.play_circle_outline, _resume),
      ], color: const Color(0xFFFFEBEE)));
    }

    // --- Client : lieu de livraison + confirmation de réception
    if (role == 'client' && !final_) {
      out.add(_card('Mon lieu de livraison', [
        Text(m['dropoff_shared_at'] != null ? 'Vous avez partagé votre lieu de livraison ${ago(m['dropoff_shared_at'])}.' : 'Aidez le livreur : partagez votre position GPS ou une adresse précise.',
            style: const TextStyle(fontSize: 13)),
        const SizedBox(height: 8),
        btn('PARTAGER MA POSITION / MON ADRESSE', Icons.my_location, _clientLocation),
        if (m['dropoff_lat'] != null) btn('Retirer ma position GPS', Icons.location_off, _clientClearLocation, outlined: true),
      ]));
    }
    if (role == 'client' && s == 'delivered' && m['client_confirmation'] != 'received') {
      if (m['client_confirmation'] == 'not_received') {
        out.add(_card('Signalement en cours', [const Text('Vous avez signalé un colis non reçu. L\'administration traite votre litige.')], color: const Color(0xFFFFEBEE)));
      } else {
        out.add(_card('AVEZ-VOUS REÇU VOTRE COLIS ?', [
          const Text('Le livreur indique avoir livré. La livraison n\'est terminée que lorsque VOUS confirmez.', style: TextStyle(fontSize: 13)),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: FilledButton(onPressed: _busy ? null : () => _confirmReception(true), child: const Text('COLIS REÇU'))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: _busy ? null : () => _confirmReception(false), child: const Text('COLIS NON REÇU'))),
          ]),
        ], color: const Color(0xFFFFF4E0)));
      }
    }
    if (s == 'delivered' && m['received_confirmed_at'] != null) {
      out.add(_card('Livraison terminée', [Text('Réception confirmée par le client le ${dt(m['received_confirmed_at'])}.')], color: const Color(0xFFE8F5E9)));
    }
    if (s == 'not_received') {
      out.add(_card('Colis signalé non reçu', [const Text('Un signalement est ouvert chez l\'administration MAYA, qui traite le litige. L\'historique est conservé.')], color: const Color(0xFFFFEBEE)));
    }

    // --- Vendeur
    if (role == 'seller' && !final_) {
      final a = <Widget>[];
      if (s == 'requested' && m['kind'] == 'maya_carrier') {
        a.add(const Text('Aucun transporteur MAYA n\'a pris la mission pour le moment.', style: TextStyle(fontSize: 13)));
        a.add(const SizedBox(height: 8));
        a.add(btn('Relancer la recherche MAYA', Icons.search, _retrySearch));
      }
      if (['requested', 'searching', 'awaiting_acceptance', 'carrier_selected'].contains(s)) {
        a.add(btn('DÉSIGNER MON LIVREUR', Icons.person_add_alt_1, _ownCourier, outlined: true));
      }
      if (s == 'carrier_confirmed') a.add(btn('Marquer le colis comme récupéré', Icons.inventory_2, () => _setStatus('picked_up'), outlined: true));
      a.add(btn('Indiquer le lieu de récupération', Icons.store, _setPickup, outlined: true));
      if (a.isNotEmpty) out.add(_card('Actions du vendeur', a));
    }

    // --- Invitation du livreur externe (SMS / WhatsApp)
    final inv = m['invite'] as Map?;
    if ((role == 'seller' || role == 'admin') && m['kind'] == 'own_courier' && !final_) {
      final claimed = inv?['claimed'] == true || m['courier']?['joined'] == true;
      out.add(_card('Invitation du livreur', [
        Text(claimed
            ? 'Le livreur a rejoint la mission avec son invitation.'
            : inv == null
                ? 'Aucune invitation active.'
                : inv['active'] == true
                    ? 'Invitation envoyée : valable jusqu\'au ${dt(inv['expires_at'])}. Elle ne peut être utilisée que par une personne, avec le code PIN.'
                    : inv['revoked'] == true
                        ? 'Invitation révoquée.'
                        : 'Invitation expirée.', style: const TextStyle(fontSize: 13)),
        const SizedBox(height: 8),
        if (!claimed) btn('Nouvelle invitation (SMS / WhatsApp)', Icons.sms_outlined, _newInvite),
        if (!claimed && inv?['active'] == true) btn('Révoquer l\'invitation', Icons.link_off, _revokeInvite, outlined: true),
      ]));
    }

    // --- Actions communes
    final common = <Widget>[];
    if (m['conversation_id'] != null) common.add(btn('CONVERSATION DE LIVRAISON', Icons.chat_bubble_outline, _openChat));
    if (!final_ && (role == 'courier' || role == 'seller' || role == 'admin') && ['carrier_confirmed', 'picked_up', 'in_progress', 'near_client', 'arrived'].contains(s)) {
      common.add(btn('Signaler un incident ou un retard', Icons.report_problem_outlined, _incident, outlined: true));
    }
    if (!final_ && (role == 'courier' || role == 'seller' || role == 'admin') && s != 'own_courier_assigned' && s != 'requested' && s != 'searching' && s != 'awaiting_acceptance') {
      common.add(btn('Modifier l\'heure estimée', Icons.schedule, _setEta, outlined: true));
    }
    if (!final_ && (role == 'seller' || role == 'admin')) common.add(btn('Annuler la livraison', Icons.cancel_outlined, _cancel, outlined: true));
    if (common.isNotEmpty) out.add(Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: common));
    return out;
  }

  Widget _contacts(Map<String, dynamic> m) {
    final c = m['courier'] as Map?;
    final s = m['seller'] as Map?;
    final cl = m['client'] as Map?;
    if (c == null && s == null && cl == null) return const SizedBox.shrink();
    final photo = m['courier'] is Map ? (m['courier'] as Map)['photo_path'] as String? : null;
    return _card('Contacts', [
      if (c != null)
        Row(children: [
          if (photo != null && photo.isNotEmpty) Padding(padding: const EdgeInsets.only(right: 10), child: _CourierPhoto(photo)),
          Expanded(
              child: ContactRow(
                  icon: Icons.two_wheeler,
                  role: m['kind'] == 'own_courier' ? 'Livreur' : 'Transporteur',
                  name: c['name'] as String?,
                  phone: c['phone'] as String?,
                  extra: [if (c['transport'] != null) '${c['transport']}', if (c['verified'] == true) 'vérifié MAYA'].join(' · '))),
        ]),
      if (s != null) ContactRow(icon: Icons.storefront, role: 'Vendeur', name: s['name'] as String?, phone: s['phone'] as String?),
      if (cl != null) ContactRow(icon: Icons.person, role: 'Client', name: cl['name'] as String?, phone: cl['phone'] as String?, extra: cl['city'] as String?),
    ]);
  }

  Widget _details(Map<String, dynamic> m) {
    final items = _list(m['items']);
    if (items.isEmpty) return const SizedBox.shrink();
    return _card('Colis', [for (final it in items) Text('• ${it['name']} × ${n(it['quantity'])} ${it['unit'] ?? ''}')]);
  }

  Widget _offersCard(Map<String, dynamic> m) {
    final offers = _list(m['offers']);
    if (offers.isEmpty) return const SizedBox.shrink();
    const lab = {'pending': 'En attente de réponse', 'accepted': 'Accepté', 'refused': 'Refusé', 'expired': 'Sans réponse', 'cancelled': 'Annulé'};
    return _card('Demandes envoyées aux transporteurs MAYA', [
      for (final o in offers)
        ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          title: Text('${o['carrier'] ?? 'Transporteur'}'),
          subtitle: Text('${lab[o['status']] ?? o['status']} · ${dt(o['at'])}${o['proposed_fee'] != null ? ' · ${money(o['proposed_fee'])}' : ''}'),
        ),
    ]);
  }

  Widget _incidentsCard(Map<String, dynamic> m) {
    final inc = _list(m['incidents']);
    if (inc.isEmpty) return const SizedBox.shrink();
    return _card('Incidents', [
      for (final i in inc)
        ListTile(
          dense: true,
          contentPadding: EdgeInsets.zero,
          leading: Icon(i['status'] == 'open' ? Icons.error : Icons.check_circle, color: i['status'] == 'open' ? Colors.red : brand),
          title: Text(deliveryIncidentKinds[i['kind']] ?? '${i['kind']}'),
          subtitle: Text('${dt(i['at'])} · signalé par ${i['reported_role'] ?? ''}${(i['note'] as String?)?.isNotEmpty == true ? '\n${i['note']}' : ''}'),
        ),
    ]);
  }

  Widget _timeline(Map<String, dynamic> m) {
    final ev = _list(m['events']);
    if (ev.isEmpty) return const SizedBox.shrink();
    return _card('Historique (date, heure, auteur)', [
      for (final e in ev.reversed)
        Padding(
          padding: const EdgeInsets.only(bottom: 6),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Icon(Icons.circle, size: 9, color: deliveryColor(e['status'] as String?)),
            const SizedBox(width: 8),
            Expanded(
              child: Text('${dt(e['at'])} · ${e['actor_role'] ?? 'système'}\n${(e['status_label'] as String?) ?? ''}${(e['note'] as String?)?.isNotEmpty == true ? ((e['status_label'] as String?)?.isNotEmpty == true ? ' — ' : '') + '${e['note']}' : ''}',
                  style: const TextStyle(fontSize: 12.5)),
            ),
          ]),
        ),
    ]);
  }
}

/// Photo (facultative) du livreur : bucket privé, lue par lien signé temporaire.
class _CourierPhoto extends StatelessWidget {
  final String path;
  const _CourierPhoto(this.path);
  @override
  Widget build(BuildContext context) => FutureBuilder<String>(
        future: sb.storage.from('courier-photos').createSignedUrl(path, 3600),
        builder: (context, snap) {
          if (!snap.hasData) return const CircleAvatar(radius: 26, child: Icon(Icons.person));
          return CircleAvatar(radius: 26, backgroundImage: NetworkImage(snap.data!));
        },
      );
}
