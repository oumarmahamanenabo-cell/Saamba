import 'package:flutter/material.dart';
import 'common.dart';
import 'delivery_common.dart';
import 'delivery_mission.dart';
import 'guest.dart' show requireAuth, isLoggedIn;

List<Map<String, dynamic>> _rows(dynamic v) =>
    v is List ? List<Map<String, dynamic>>.from(v.map((e) => Map<String, dynamic>.from(e as Map))) : <Map<String, dynamic>>[];

const _roleLabels = {'seller': 'Vendeur', 'client': 'Client', 'courier': 'Livreur'};

// ======================================================================================
//  « Mes livraisons » : missions et demandes reçues, pour tout compte (vendeur, client, transporteur, livreur invité)
// ======================================================================================
class MyDeliveriesScreen extends StatelessWidget {
  const MyDeliveriesScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Mes livraisons')), body: const DeliveriesBody());
}

class DeliveriesBody extends StatefulWidget {
  const DeliveriesBody({super.key});
  @override
  State<DeliveriesBody> createState() => _DeliveriesBodyState();
}

class _DeliveriesBodyState extends State<DeliveriesBody> {
  late Future<Map<String, dynamic>> _f = _load();
  Future<Map<String, dynamic>> _load() async => Map<String, dynamic>.from(await sb.rpc('delivery_my_missions') as Map);
  void _reload() => setState(() => _f = _load());

  Future<void> _respond(Map<String, dynamic> o, bool accept) async {
    final fee = TextEditingController(text: o['proposed_fee'] == null ? '' : '${n(o['proposed_fee']).round()}');
    final note = TextEditingController();
    DateTime? est;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(accept ? 'Accepter la mission' : 'Refuser la mission'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (accept) ...[
                TextField(controller: fee, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Votre tarif (FCFA)')),
                const SizedBox(height: 8),
                OutlinedButton.icon(
                  icon: const Icon(Icons.schedule),
                  label: Text(est == null ? 'Heure estimée de livraison' : dt(est!.toIso8601String())),
                  onPressed: () async {
                    final d = await pickDateTime(ctx);
                    if (d != null) setS(() => est = d);
                  },
                ),
              ],
              TextField(controller: note, maxLines: 2, decoration: InputDecoration(labelText: accept ? 'Message pour le vendeur (facultatif)' : 'Motif (facultatif)')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(style: accept ? null : FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(ctx, true), child: Text(accept ? 'Accepter' : 'Refuser')),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      final r = Map<String, dynamic>.from(await sb.rpc('delivery_offer_respond', params: {
        'p_offer': o['offer_id'],
        'p_accept': accept,
        'p_fee': accept ? num.tryParse(fee.text.replaceAll(RegExp(r'[^0-9.]'), '')) : null,
        'p_est': est?.toUtc().toIso8601String(),
        'p_note': note.text.trim().isEmpty ? null : note.text.trim(),
      }) as Map);
      if (!mounted) return;
      if (r['result'] == 'accepted') {
        snack(context, 'Mission acceptée. La conversation à trois est ouverte.');
        await Navigator.push(context, MaterialPageRoute(builder: (_) => MissionScreen(missionId: r['mission_id'] as String)));
      } else {
        snack(context, 'Mission refusée.');
      }
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final offers = _rows(snap.data!['offers']);
          final ms = _rows(snap.data!['missions']);
          final open = ms.where((m) => !deliveryFinalStatuses.contains(m['status'])).toList();
          final done = ms.where((m) => deliveryFinalStatuses.contains(m['status'])).toList();
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              if (offers.isNotEmpty) ...[
                const Text('Demandes de mission à traiter', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                for (final o in offers) _offerCard(o),
                const SizedBox(height: 10),
              ],
              const Text('Livraisons en cours', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              if (open.isEmpty) const Padding(padding: EdgeInsets.symmetric(vertical: 12), child: Text('Aucune livraison en cours.')),
              for (final m in open) _missionTile(m),
              if (done.isNotEmpty) ...[
                const SizedBox(height: 12),
                const Text('Livraisons terminées', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                for (final m in done) _missionTile(m),
              ],
            ]),
          );
        },
      );

  Widget _offerCard(Map<String, dynamic> o) {
    final items = _rows(o['items']);
    return Card(
      color: const Color(0xFFFFF4E0),
      margin: const EdgeInsets.only(top: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Commande ${o['order_number']} · ${o['seller_name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
          if (o['dropoff_city'] != null) Text('Livraison à : ${o['dropoff_city']}'),
          if (o['pickup_address'] != null) Text('Récupération : ${o['pickup_address']}'),
          for (final it in items) Text('• ${it['name']} × ${n(it['quantity'])} ${it['unit'] ?? ''}', style: const TextStyle(fontSize: 12.5)),
          if (o['proposed_fee'] != null) Text('Tarif proposé : ${money(o['proposed_fee'])}'),
          Text('Répondre avant le ${dt(o['expires_at'])}', style: const TextStyle(fontSize: 12, color: Colors.deepOrange)),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(child: FilledButton(onPressed: () => _respond(o, true), child: const Text('ACCEPTER'))),
            const SizedBox(width: 8),
            Expanded(child: FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => _respond(o, false), child: const Text('REFUSER'))),
          ]),
        ]),
      ),
    );
  }

  Widget _missionTile(Map<String, dynamic> m) => Card(
        margin: const EdgeInsets.only(top: 8),
        child: ListTile(
          title: Text('Commande ${m['order_number']}  ·  ${_roleLabels[m['role']] ?? ''}'),
          subtitle: Padding(
            padding: const EdgeInsets.only(top: 4),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Wrap(children: [DeliveryStatusChip(m['status'] as String)]),
              if (m['courier_name'] != null) Text('Livreur : ${m['courier_name']}', style: const TextStyle(fontSize: 12)),
              Text('Mis à jour ${ago(m['updated_at'])}', style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
            ]),
          ),
          trailing: const Icon(Icons.chevron_right),
          onTap: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => MissionScreen(missionId: m['id'] as String)));
            _reload();
          },
        ),
      );
}

// ======================================================================================
//  Espace transporteur MAYA (inscription, disponibilité, demandes, missions)
// ======================================================================================
const _verifLabels = {
  'pending': 'En attente de vérification par l\'administration MAYA',
  'docs_required': 'Documents à fournir à l\'administration MAYA',
  'in_review': 'Dossier en cours d\'examen',
  'verified': 'Transporteur vérifié',
  'refused': 'Dossier refusé',
  'suspended': 'Compte suspendu',
};

class CarrierSpaceScreen extends StatefulWidget {
  const CarrierSpaceScreen({super.key});
  @override
  State<CarrierSpaceScreen> createState() => _CarrierSpaceScreenState();
}

class _CarrierSpaceScreenState extends State<CarrierSpaceScreen> {
  late Future<Map<String, dynamic>?> _f = _load();
  Key _bodyKey = UniqueKey();

  Future<Map<String, dynamic>?> _load() async => await sb.from('carriers').select().eq('user_id', uid).maybeSingle();
  void _reload() => setState(() {
        _f = _load();
        _bodyKey = UniqueKey();
      });

  Future<void> _edit(Map<String, dynamic>? c) async {
    final owner = TextEditingController(text: c?['owner_name'] as String?);
    final company = TextEditingController(text: c?['company_name'] as String?);
    final phone = TextEditingController(text: (c?['phone'] as String?) ?? '+223 ');
    final city = TextEditingController(text: c?['city'] as String?);
    final zones = TextEditingController(text: c?['zones'] as String?);
    final vehicle = TextEditingController(text: c?['vehicle_types'] as String?);
    final fee = TextEditingController(text: c?['base_fee'] == null ? '' : '${n(c!['base_fee']).round()}');
    final delay = TextEditingController(text: c?['delay_note'] as String?);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(c == null ? 'Devenir transporteur MAYA' : 'Mes informations'),
        content: SingleChildScrollView(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(controller: owner, decoration: const InputDecoration(labelText: 'Nom et prénom *')),
            TextField(controller: company, decoration: const InputDecoration(labelText: 'Nom de l\'entreprise (facultatif)')),
            TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone *')),
            TextField(controller: city, decoration: const InputDecoration(labelText: 'Ville de base')),
            TextField(controller: zones, decoration: const InputDecoration(labelText: 'Zones d\'intervention * (ex. Bamako, Kati, Ségou)')),
            TextField(controller: vehicle, decoration: const InputDecoration(labelText: 'Moyen de transport (moto, camionnette…)')),
            TextField(controller: fee, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Tarif de base (FCFA)')),
            TextField(controller: delay, decoration: const InputDecoration(labelText: 'Délai habituel (ex. 24 h)')),
          ]),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('carrier_register', params: {
        'p_owner': owner.text.trim(),
        'p_company': company.text.trim(),
        'p_phone': phone.text.trim(),
        'p_city': city.text.trim(),
        'p_zones': zones.text.trim(),
        'p_vehicle': vehicle.text.trim(),
        'p_base_fee': num.tryParse(fee.text.replaceAll(RegExp(r'[^0-9.]'), '')),
        'p_delay_note': delay.text.trim(),
      });
      if (mounted) snack(context, c == null ? 'Demande envoyée. L\'administration va vérifier votre dossier.' : 'Informations enregistrées.');
      _reload();
    });
  }

  Future<void> _avail(bool v) => guarded(context, () async {
        await sb.rpc('carrier_set_availability', params: {'p_available': v});
        _reload();
      });

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Espace transporteur')),
        body: FutureBuilder<Map<String, dynamic>?>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            final c = snap.data;
            if (c == null) {
              return ListView(padding: const EdgeInsets.all(16), children: [
                const Text('Devenez transporteur MAYA', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                const Text('Recevez des demandes de livraison des vendeurs de votre zone. Après votre inscription, l\'administration MAYA vérifie votre dossier : vous ne recevez des missions qu\'une fois vérifié.'),
                const SizedBox(height: 16),
                FilledButton.icon(icon: const Icon(Icons.app_registration), label: const Text('S\'INSCRIRE COMME TRANSPORTEUR'), onPressed: () => _edit(null)),
                const SizedBox(height: 12),
                const Text('Vous avez reçu un code d\'invitation d\'un vendeur ? Utilisez plutôt « Rejoindre une livraison » dans votre compte.', style: TextStyle(fontSize: 12.5, color: Colors.black54)),
              ]);
            }
            final verified = c['verification_status'] == 'verified';
            return Column(children: [
              Card(
                margin: const EdgeInsets.all(12),
                color: verified ? const Color(0xFFE8F5E9) : const Color(0xFFFFF4E0),
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${(c['company_name'] as String?)?.isNotEmpty == true ? c['company_name'] : c['owner_name']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                    Text(_verifLabels[c['verification_status']] ?? '${c['verification_status']}', style: TextStyle(fontWeight: FontWeight.w600, color: verified ? brand : Colors.deepOrange)),
                    if ((c['verification_reason'] as String?)?.isNotEmpty == true) Text('Motif : ${c['verification_reason']}'),
                    Text('Zones : ${c['zones'] ?? '—'}', style: const TextStyle(fontSize: 12.5)),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Je suis disponible pour de nouvelles missions'),
                      subtitle: Text(verified ? 'Désactivez-le pour ne plus recevoir de demandes.' : 'Disponible après vérification de votre dossier.', style: const TextStyle(fontSize: 11.5)),
                      value: c['available'] == true,
                      onChanged: verified ? _avail : null,
                    ),
                    Align(alignment: Alignment.centerRight, child: TextButton.icon(icon: const Icon(Icons.edit), label: const Text('Modifier mes informations'), onPressed: () => _edit(c))),
                  ]),
                ),
              ),
              Expanded(child: DeliveriesBody(key: _bodyKey)),
            ]);
          },
        ),
      );
}

// ======================================================================================
//  Livreur invité : rejoindre une mission avec le code et le PIN reçus par SMS / WhatsApp
// ======================================================================================
class JoinDeliveryScreen extends StatefulWidget {
  const JoinDeliveryScreen({super.key});
  @override
  State<JoinDeliveryScreen> createState() => _JoinDeliveryScreenState();
}

class _JoinDeliveryScreenState extends State<JoinDeliveryScreen> {
  final _code = TextEditingController();
  final _pin = TextEditingController();
  String? _err;
  bool _busy = false;

  Future<void> _go() async {
    if (!isLoggedIn) {
      final ok = await requireAuth(context, reason: 'Créez un compte (ou connectez-vous) avec le numéro sur lequel vous avez reçu l\'invitation pour rejoindre la livraison.');
      if (!ok || !mounted) return;
    }
    final code = _code.text.replaceAll(RegExp(r'[^0-9A-Fa-f]'), '');
    if (code.length < 8 || _pin.text.trim().length != 6) {
      setState(() => _err = 'Saisissez le code d\'invitation et le PIN à 6 chiffres.');
      return;
    }
    setState(() {
      _busy = true;
      _err = null;
    });
    try {
      final r = Map<String, dynamic>.from(await sb.rpc('delivery_invite_claim', params: {'p_token': code, 'p_pin': _pin.text.trim()}) as Map);
      if (!mounted) return;
      if (r['ok'] == true) {
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => MissionScreen(missionId: r['mission_id'] as String)));
      } else {
        setState(() => _err = '${r['error'] ?? 'Invitation refusée'}${r['attempts_left'] != null ? ' (${r['attempts_left']} essai(s) restant(s))' : ''}');
      }
    } catch (e) {
      if (mounted) setState(() => _err = '$e'.replaceFirst('PostgrestException(message: ', '').split(',').first);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Rejoindre une livraison')),
        body: ListView(padding: const EdgeInsets.all(16), children: [
          const Text('Un vendeur vous a désigné comme livreur ?', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Saisissez le code et le PIN reçus par SMS ou WhatsApp. Ils sont à usage unique, valables 48 h, et vous donnent accès uniquement à cette mission.'),
          const SizedBox(height: 16),
          TextField(controller: _code, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Code d\'invitation', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: _pin, keyboardType: TextInputType.number, maxLength: 6, decoration: const InputDecoration(labelText: 'PIN (6 chiffres)', border: OutlineInputBorder())),
          if (_err != null) Padding(padding: const EdgeInsets.only(bottom: 8), child: Text(_err!, style: const TextStyle(color: Colors.red))),
          FilledButton.icon(icon: const Icon(Icons.login), label: Text(isLoggedIn ? 'REJOINDRE LA MISSION' : 'CONTINUER (créer un compte)'), onPressed: _busy ? null : _go),
          const SizedBox(height: 12),
          const Text('Après 5 PIN incorrects, l\'invitation est bloquée et le vendeur doit en générer une nouvelle.', style: TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
      );
}
