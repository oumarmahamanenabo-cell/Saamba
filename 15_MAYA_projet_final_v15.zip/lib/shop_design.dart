import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';
import 'my_shop.dart' show MyShopScreen;
import 'seller_products.dart' show productImageUrl;
import 'shop_media.dart';

// =====================================================================
// Personnalisation des boutiques MAYA
//  - ShopDesign : modèle JSON stocké dans shops.design_draft / shops.design
//  - ShopView : rendu d'une boutique (page publique, aperçu, administration)
//  - ShopDesignEditor : éditeur vendeur (aperçu en direct, Enregistrer, Publier)
//  - AdminShopsScreen : consultation et modération par l'administrateur
// =====================================================================

const _fontFamilies = <String, String?>{'modern': null, 'elegant': 'serif', 'technical': 'monospace', 'condensed': 'sans-serif-condensed'};
const _fontLabels = <String, String>{'modern': 'Moderne', 'elegant': 'Élégante', 'technical': 'Technique', 'condensed': 'Compacte'};
const _radiusLabels = <String, String>{'sharp': 'Carrés', 'soft': 'Arrondis', 'round': 'Très arrondis'};
const _layoutLabels = <String, String>{'grid2': 'Grille', 'grid3': 'Grille compacte', 'list': 'Liste', 'large': 'Grande vitrine'};
const _layoutIcons = <String, IconData>{'grid2': Icons.grid_view, 'grid3': Icons.apps, 'list': Icons.view_list, 'large': Icons.view_agenda_outlined};
const _sectionLabels = <String, String>{'featured': 'Produits en vedette', 'promos': 'Promotions', 'new': 'Nouveautés', 'catalog': 'Catalogue et catégories'};
const _defaultOrder = <String>['featured', 'promos', 'new', 'catalog'];

double _radiusOf(String r) => r == 'sharp' ? 4 : (r == 'round' ? 26 : 14);

class _Tpl {
  final String label, desc, primary, secondary, font, layout, radius;
  final IconData icon;
  final List<String> order;
  const _Tpl(this.label, this.desc, this.icon, this.primary, this.secondary, this.font, this.layout, this.radius, this.order);
}

const _tpls = <String, _Tpl>{
  'classic': _Tpl('Classique', 'Tous commerces', Icons.storefront_outlined, '#0F7A28', '#FF7A00', 'modern', 'grid2', 'soft', ['featured', 'promos', 'new', 'catalog']),
  'fashion': _Tpl('Mode et vêtements', 'Boutiques, tissus, chaussures', Icons.checkroom_outlined, '#1B1B1B', '#C8963E', 'elegant', 'grid2', 'sharp', ['new', 'featured', 'catalog', 'promos']),
  'food': _Tpl('Alimentation', 'Épicerie, produits frais', Icons.restaurant_outlined, '#2E7D32', '#E65100', 'modern', 'grid2', 'round', ['promos', 'featured', 'catalog', 'new']),
  'electronics': _Tpl('Électronique', 'Téléphones, accessoires', Icons.devices_other_outlined, '#0D47A1', '#00ACC1', 'technical', 'grid3', 'soft', ['promos', 'featured', 'new', 'catalog']),
  'beauty': _Tpl('Cosmétiques et beauté', 'Soins, parfums, coiffure', Icons.spa_outlined, '#8E2457', '#E8A0BF', 'elegant', 'large', 'round', ['featured', 'new', 'promos', 'catalog']),
  'wholesale': _Tpl('Grossiste', 'Vente en gros, listes de prix', Icons.inventory_2_outlined, '#37474F', '#FF7A00', 'condensed', 'list', 'sharp', ['catalog', 'promos', 'featured', 'new']),
};

const _palette = <String>[
  '#0F7A28', '#14B53A', '#0A4D1C', '#2E7D32', '#0D47A1', '#1976D2', '#00ACC1', '#37474F',
  '#1B1B1B', '#6D4C41', '#8E2457', '#C2185B', '#CE1126', '#E65100', '#FF7A00', '#C8963E',
  '#FCD116', '#E8A0BF', '#7B1FA2', '#5E35B1',
];

final _hexRe = RegExp(r'^#[0-9A-Fa-f]{6}$');

Color parseHex(String h, [Color fallback = brand]) {
  final m = RegExp(r'^#?([0-9A-Fa-f]{6})$').firstMatch(h.trim());
  if (m == null) return fallback;
  return Color(0xFF000000 | int.parse(m.group(1)!, radix: 16));
}

Color onColor(Color c) => ThemeData.estimateBrightnessForColor(c) == Brightness.dark ? Colors.white : Colors.black87;

class SectionCfg {
  final String id;
  bool on;
  SectionCfg(this.id, this.on);
}

class CategoryCfg {
  String name;
  List<String> products;
  CategoryCfg(this.name, this.products);
}

class ShopDesign {
  String template, primary, secondary, font, layout, radius, tagline;
  List<SectionCfg> sections;
  List<String> featured;
  List<CategoryCfg> categories;

  ShopDesign({
    required this.template,
    required this.primary,
    required this.secondary,
    required this.font,
    required this.layout,
    required this.radius,
    this.tagline = '',
    required this.sections,
    List<String>? featured,
    List<CategoryCfg>? categories,
  })  : featured = featured ?? [],
        categories = categories ?? [];

  factory ShopDesign.preset(String key) {
    final t = _tpls[key] ?? _tpls['classic']!;
    return ShopDesign(
      template: _tpls.containsKey(key) ? key : 'classic',
      primary: t.primary,
      secondary: t.secondary,
      font: t.font,
      layout: t.layout,
      radius: t.radius,
      sections: [for (final id in t.order) SectionCfg(id, true)],
    );
  }

  /// Applique un modèle (couleurs, police, disposition, style, ordre des sections)
  /// en conservant les catégories, produits en vedette et slogan.
  void applyTemplate(String key) {
    final t = _tpls[key];
    if (t == null) return;
    template = key;
    primary = t.primary;
    secondary = t.secondary;
    font = t.font;
    layout = t.layout;
    radius = t.radius;
    final on = {for (final s in sections) s.id: s.on};
    sections = [for (final id in t.order) SectionCfg(id, on[id] ?? true)];
  }

  factory ShopDesign.fromJson(dynamic j) {
    final d = ShopDesign.preset('classic');
    if (j is! Map) return d;
    String pick(String k, Iterable<String> allowed, String def) {
      final v = j[k];
      return v is String && allowed.contains(v) ? v : def;
    }

    d.template = pick('template', _tpls.keys, d.template);
    d.font = pick('font', _fontFamilies.keys, d.font);
    d.layout = pick('layout', _layoutLabels.keys, d.layout);
    d.radius = pick('radius', _radiusLabels.keys, d.radius);
    if (j['primary'] is String && _hexRe.hasMatch(j['primary'] as String)) d.primary = (j['primary'] as String).toUpperCase();
    if (j['secondary'] is String && _hexRe.hasMatch(j['secondary'] as String)) d.secondary = (j['secondary'] as String).toUpperCase();
    if (j['tagline'] is String) d.tagline = j['tagline'] as String;
    if (j['sections'] is List) {
      final seen = <String>{};
      final list = <SectionCfg>[];
      for (final s in (j['sections'] as List)) {
        if (s is Map && s['id'] is String && _defaultOrder.contains(s['id']) && seen.add(s['id'] as String)) {
          list.add(SectionCfg(s['id'] as String, s['on'] != false));
        }
      }
      for (final id in _defaultOrder) {
        if (!seen.contains(id)) list.add(SectionCfg(id, true));
      }
      d.sections = list;
    }
    if (j['featured'] is List) d.featured = [for (final x in (j['featured'] as List)) if (x is String) x];
    if (j['categories'] is List) {
      d.categories = [
        for (final c in (j['categories'] as List))
          if (c is Map && c['name'] is String)
            CategoryCfg(c['name'] as String, [for (final x in ((c['products'] is List) ? c['products'] as List : const [])) if (x is String) x]),
      ];
    }
    return d;
  }

  Map<String, dynamic> toJson() => {
        'template': template,
        'primary': primary,
        'secondary': secondary,
        'font': font,
        'layout': layout,
        'radius': radius,
        'tagline': tagline.trim(),
        'sections': [for (final s in sections) {'id': s.id, 'on': s.on}],
        'featured': featured,
        'categories': [for (final c in categories) {'name': c.name.trim(), 'products': c.products}],
      };
}

bool _isNew(Map<String, dynamic> p) {
  final d = DateTime.tryParse('${p['created_at']}');
  return d != null && DateTime.now().difference(d).inDays <= 14;
}

bool _isPromo(Map<String, dynamic> p) {
  final price = n(p['price']);
  final promo = p['promo_price'] == null ? 0 : n(p['promo_price']);
  return promo > 0 && promo < price;
}

// =====================================================================
// Rendu d'une boutique (public, aperçu, administration)
// =====================================================================
class ShopView extends StatefulWidget {
  final Map<String, dynamic> shop;
  final ShopDesign design;
  final List<Map<String, dynamic>> products;
  final void Function(Map<String, dynamic> product) onProductTap;
  const ShopView({super.key, required this.shop, required this.design, required this.products, required this.onProductTap});
  @override
  State<ShopView> createState() => _ShopViewState();
}

class _ShopViewState extends State<ShopView> {
  int? _cat;

  String _digitsOf(String s) => s.replaceAll(RegExp(r'[^0-9]'), '');
  Future<void> _open(String url) => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);

  Widget _title(String t, Color primary, Color secondary) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 18, 16, 8),
        child: Row(children: [
          Container(width: 5, height: 18, decoration: BoxDecoration(color: secondary, borderRadius: BorderRadius.circular(3))),
          const SizedBox(width: 8),
          Expanded(child: Text(t, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17, color: primary))),
        ]),
      );

  Widget _carousel(List<Map<String, dynamic>> items) {
    final d = widget.design;
    final big = d.layout == 'large';
    final w = big ? 220.0 : 150.0, h = big ? 290.0 : 225.0;
    return SizedBox(
      height: h,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: items.length,
        separatorBuilder: (_, __) => const SizedBox(width: 10),
        itemBuilder: (_, i) => SizedBox(width: w, child: _ShopCard(p: items[i], d: d, onTap: () => widget.onProductTap(items[i]))),
      ),
    );
  }

  Widget _catalog(List<Map<String, dynamic>> all, Color primary, Color secondary) {
    final d = widget.design;
    final ids = {for (final p in all) '${p['id']}'};
    final cats = [for (final c in d.categories) if (c.products.any(ids.contains)) c];
    var sel = _cat;
    if (sel != null && sel >= cats.length) sel = null;
    final items = sel == null ? all : [for (final p in all) if (cats[sel].products.contains('${p['id']}')) p];
    final Widget body;
    if (items.isEmpty) {
      body = const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Aucun produit à afficher ici pour le moment.')));
    } else if (d.layout == 'list') {
      body = Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(children: [
          for (final p in items) Padding(padding: const EdgeInsets.only(bottom: 8), child: SizedBox(height: 96, child: _ShopCard(p: p, d: d, row: true, onTap: () => widget.onProductTap(p)))),
        ]),
      );
    } else {
      final ext = d.layout == 'grid3' ? 150.0 : (d.layout == 'large' ? 480.0 : 210.0);
      final ratio = d.layout == 'grid3' ? 0.68 : (d.layout == 'large' ? 1.0 : 0.74);
      body = GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent: ext, childAspectRatio: ratio, crossAxisSpacing: 10, mainAxisSpacing: 10),
        itemCount: items.length,
        itemBuilder: (_, i) => _ShopCard(p: items[i], d: d, big: d.layout == 'large', onTap: () => widget.onProductTap(items[i])),
      );
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      _title('Catalogue · ${all.length} produit(s)', primary, secondary),
      if (cats.isNotEmpty)
        SizedBox(
          height: 46,
          child: ListView(scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12), children: [
            for (var i = -1; i < cats.length; i++)
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(i == -1 ? 'Tous' : cats[i].name),
                  selected: (sel ?? -1) == i,
                  selectedColor: primary,
                  labelStyle: TextStyle(color: (sel ?? -1) == i ? onColor(primary) : null, fontWeight: FontWeight.w600),
                  onSelected: (_) => setState(() => _cat = i == -1 ? null : i),
                ),
              ),
          ]),
        ),
      const SizedBox(height: 8),
      body,
    ]);
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.design, s = widget.shop;
    final primary = parseHex(d.primary), secondary = parseHex(d.secondary);
    final all = widget.products;
    final byId = {for (final p in all) '${p['id']}': p};
    final banner = storageUrl('shop-assets', s['banner_path'] as String?);
    final logo = storageUrl('shop-assets', s['logo_path'] as String?);
    final wa = _digitsOf('${s['whatsapp'] ?? ''}');
    final tel = '${s['phone'] ?? ''}'.trim();
    final width = MediaQuery.of(context).size.width;
    final bannerH = (width * 0.32).clamp(130.0, 240.0);

    final children = <Widget>[
      Stack(clipBehavior: Clip.none, children: [
        SizedBox(
          height: bannerH,
          width: double.infinity,
          child: banner == null
              ? DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(colors: [primary, Color.lerp(primary, secondary, 0.65)!])))
              : Image.network(banner, fit: BoxFit.cover, errorBuilder: (_, __, ___) => ColoredBox(color: primary)),
        ),
        Positioned(
          left: 16,
          bottom: -34,
          child: Container(
            decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white, border: Border.all(color: Colors.white, width: 3), boxShadow: const [BoxShadow(color: Colors.black26, blurRadius: 6)]),
            child: CircleAvatar(radius: 34, backgroundColor: primary, backgroundImage: logo == null ? null : NetworkImage(logo), child: logo == null ? Icon(Icons.store, color: onColor(primary), size: 32) : null),
          ),
        ),
      ]),
      const SizedBox(height: 42),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('${s['name'] ?? ''}', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: primary)),
          if (d.tagline.trim().isNotEmpty) Padding(padding: const EdgeInsets.only(top: 2), child: Text(d.tagline.trim(), style: TextStyle(fontWeight: FontWeight.w700, color: secondary))),
          if ('${s['description'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('${s['description']}')),
          if ('${s['city'] ?? ''}'.isNotEmpty || '${s['address'] ?? ''}'.isNotEmpty)
            Padding(padding: const EdgeInsets.only(top: 6), child: Text('📍 ${[s['city'], s['address']].where((e) => e != null && '$e'.isNotEmpty).join(' · ')}')),
          const SizedBox(height: 10),
          Wrap(spacing: 8, runSpacing: 8, children: [
            if (wa.isNotEmpty)
              FilledButton.icon(
                style: FilledButton.styleFrom(backgroundColor: secondary, foregroundColor: onColor(secondary)),
                onPressed: () => _open('https://wa.me/$wa'),
                icon: const Icon(Icons.chat_outlined),
                label: const Text('WhatsApp'),
              ),
            if (tel.isNotEmpty)
              OutlinedButton.icon(
                style: OutlinedButton.styleFrom(foregroundColor: primary, side: BorderSide(color: primary)),
                onPressed: () => _open('tel:$tel'),
                icon: const Icon(Icons.call_outlined),
                label: const Text('Appeler'),
              ),
          ]),
        ]),
      ),
    ];

    if (all.isEmpty) {
      children.add(const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Cette boutique n\'a pas encore de produit publié.'))));
    } else {
      for (final sec in d.sections) {
        if (!sec.on) continue;
        if (sec.id == 'featured') {
          final items = [for (final id in d.featured) if (byId[id] != null) byId[id]!];
          if (items.isEmpty) continue;
          children..add(_title(_sectionLabels['featured']!, primary, secondary))..add(_carousel(items));
        } else if (sec.id == 'promos') {
          final items = [for (final p in all) if (_isPromo(p)) p].take(12).toList();
          if (items.isEmpty) continue;
          children..add(_title(_sectionLabels['promos']!, primary, secondary))..add(_carousel(items));
        } else if (sec.id == 'new') {
          final items = [for (final p in all) if (_isNew(p)) p].take(12).toList();
          if (items.isEmpty) continue;
          children..add(_title(_sectionLabels['new']!, primary, secondary))..add(_carousel(items));
        } else if (sec.id == 'catalog') {
          children.add(_catalog(all, primary, secondary));
        }
      }
    }
    children.add(const SizedBox(height: 28));

    return DefaultTextStyle.merge(
      style: TextStyle(fontFamily: _fontFamilies[d.font]),
      child: ColoredBox(
        color: const Color(0xFFFAFAF8),
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 960),
            child: ListView(padding: EdgeInsets.zero, children: children),
          ),
        ),
      ),
    );
  }
}

class _ShopCard extends StatelessWidget {
  final Map<String, dynamic> p;
  final ShopDesign d;
  final bool row, big;
  final VoidCallback onTap;
  const _ShopCard({required this.p, required this.d, required this.onTap, this.row = false, this.big = false});

  @override
  Widget build(BuildContext context) {
    final primary = parseHex(d.primary), secondary = parseHex(d.secondary);
    final r = BorderRadius.circular(_radiusOf(d.radius));
    final price = n(p['price']);
    final num? promo = p['promo_price'] == null ? null : n(p['promo_price']);
    final hasPromo = promo != null && promo > 0 && promo < price;
    final num shown = hasPromo ? promo! : price;
    final pct = hasPromo && price > 0 ? ((1 - promo! / price) * 100).round() : 0;
    final url = productImageUrl(p);
    final out = n(p['stock']) <= 0;

    final Widget image = Stack(fit: StackFit.expand, children: [
      url == null
          ? const ColoredBox(color: Color(0xFFEFF3EE), child: Icon(Icons.shopping_bag_outlined, size: 40, color: Color(0xFFB8C9B8)))
          : Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFFEFF3EE), child: Icon(Icons.broken_image))),
      if (pct > 0)
        Positioned(
          right: 6,
          top: 6,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(color: secondary, borderRadius: BorderRadius.circular(10)),
            child: Text('-$pct%', style: TextStyle(color: onColor(secondary), fontWeight: FontWeight.w800, fontSize: 12)),
          ),
        ),
      if (out) Positioned(left: 6, top: 6, child: Container(padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2), color: Colors.black54, child: const Text('Rupture', style: TextStyle(color: Colors.white, fontSize: 11)))),
    ]);

    final priceRow = Row(children: [
      Flexible(child: Text(money(shown), maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w800, color: primary, fontSize: big ? 16 : 13))),
      if (hasPromo) Padding(padding: const EdgeInsets.only(left: 6), child: Text(money(price), style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.black45, fontSize: 11))),
    ]);

    return Material(
      color: Colors.white,
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: r),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        child: row
            ? Row(children: [
                SizedBox(width: 96, height: double.infinity, child: image),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(10),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text('${p['name']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
                      const SizedBox(height: 4),
                      priceRow,
                      Text('par ${p['unit'] ?? 'pièce'}', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                    ]),
                  ),
                ),
              ])
            : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Expanded(child: image),
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${p['name']}', maxLines: 2, overflow: TextOverflow.ellipsis, style: TextStyle(fontWeight: FontWeight.w600, fontSize: big ? 15 : 13)),
                    const SizedBox(height: 4),
                    priceRow,
                  ]),
                ),
              ]),
      ),
    );
  }
}

// =====================================================================
// Aperçu plein écran (vendeur / administrateur)
// =====================================================================
class ShopPreviewPage extends StatelessWidget {
  final Map<String, dynamic> shop;
  final ShopDesign design;
  final List<Map<String, dynamic>> products;
  final String banner;
  const ShopPreviewPage({super.key, required this.shop, required this.design, required this.products, this.banner = 'Aperçu : ceci n\'est pas encore visible par les clients.'});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Aperçu de la boutique')),
        body: Column(children: [
          Container(width: double.infinity, color: maliGold, padding: const EdgeInsets.all(8), child: Text(banner, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12))),
          Expanded(child: ShopView(shop: shop, design: design, products: products, onProductTap: (_) => snack(context, 'Aperçu : la fiche produit s\'ouvre pour les clients.'))),
        ]),
      );
}

// =====================================================================
// Éditeur vendeur
// =====================================================================
class ShopDesignEditor extends StatefulWidget {
  const ShopDesignEditor({super.key});
  @override
  State<ShopDesignEditor> createState() => _ShopDesignEditorState();
}

class _ShopDesignEditorState extends State<ShopDesignEditor> {
  Map<String, dynamic>? _shop;
  List<Map<String, dynamic>> _products = [];
  int _pending = 0;
  late ShopDesign _d = ShopDesign.preset('classic');
  bool _loading = true, _dirty = false, _busy = false, _bigPreview = false;
  String? _err;
  final _hexP = TextEditingController(), _hexS = TextEditingController(), _tagline = TextEditingController();

  @override
  void initState() {
    super.initState();
    _load(initial: true);
  }

  @override
  void dispose() {
    _hexP.dispose();
    _hexS.dispose();
    _tagline.dispose();
    super.dispose();
  }

  void _syncControllers() {
    _hexP.text = _d.primary;
    _hexS.text = _d.secondary;
    _tagline.text = _d.tagline;
  }

  Future<void> _load({bool initial = false}) async {
    try {
      final shop = await sb.from('shops').select().eq('owner_id', uid).maybeSingle();
      final rows = await sb.from('products').select('id, name, price, promo_price, unit, image_path, stock, created_at, status').eq('created_by', uid).order('created_at', ascending: false);
      if (!mounted) return;
      final all = [for (final r in rows) Map<String, dynamic>.from(r as Map)];
      setState(() {
        _shop = shop == null ? null : Map<String, dynamic>.from(shop);
        _products = [for (final p in all) if (p['status'] == 'approved') p];
        _pending = all.where((p) => p['status'] == 'pending').length;
        if (initial && shop != null) {
          _d = ShopDesign.fromJson(shop['design_draft'] ?? shop['design']);
          _syncControllers();
        }
        _loading = false;
        _err = null;
      });
    } catch (e) {
      if (mounted) setState(() {
            _err = '$e';
            _loading = false;
          });
    }
  }

  void _change(VoidCallback f) => setState(() {
        f();
        _dirty = true;
      });

  Future<bool> _save() async {
    var ok = false;
    setState(() => _busy = true);
    await guarded(context, () async {
      await sb.from('shops').update({'design_draft': _d.toJson()}).eq('id', _shop!['id']);
      ok = true;
    });
    if (!mounted) return false;
    setState(() {
      _busy = false;
      if (ok) {
        _dirty = false;
        _shop = {..._shop!, 'design_draft': _d.toJson()};
      }
    });
    return ok;
  }

  Future<void> _publish() async {
    if (_shop!['status'] == 'suspended') return snack(context, 'Votre boutique est suspendue par l\'administration : publication impossible.');
    final go = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Publier ma boutique ?'),
        content: const Text('Les clients verront immédiatement ce design sur la page publique de votre boutique. Vous pourrez le modifier à tout moment.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Publier')),
        ],
      ),
    );
    if (go != true || !mounted) return;
    if (!await _save()) return;
    if (!mounted) return;
    setState(() => _busy = true);
    await guarded(context, () async {
      await sb.rpc('publish_shop_design');
      await _load();
      if (mounted) snack(context, 'Boutique publiée.');
    });
    if (mounted) setState(() => _busy = false);
  }

  void _preview() => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopPreviewPage(shop: _shop!, design: _d, products: _products)));

  Future<void> _editIdentity() async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Logo, bannière et coordonnées')), body: const MyShopScreen(startEditing: true))));
    if (mounted) _load();
  }

  // ----- Sélecteur de produits (vedettes, catégories) -----
  Future<List<String>?> _pickProducts(String title, List<String> selected, {int? max}) {
    final sel = <String>{...selected};
    return showModalBottomSheet<List<String>>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, set) => SafeArea(
          child: SizedBox(
            height: MediaQuery.of(ctx).size.height * 0.75,
            child: Column(children: [
              Padding(padding: const EdgeInsets.all(12), child: Text(title, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
              Expanded(
                child: _products.isEmpty
                    ? const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Aucun produit publié pour le moment. Ajoutez des produits dans l\'onglet Produits (ils doivent être validés).', textAlign: TextAlign.center)))
                    : ListView(children: [
                        for (final p in _products)
                          CheckboxListTile(
                            value: sel.contains('${p['id']}'),
                            title: Text('${p['name']}', maxLines: 1, overflow: TextOverflow.ellipsis),
                            subtitle: Text(money(p['promo_price'] ?? p['price'])),
                            secondary: productImageUrl(p) == null ? const Icon(Icons.shopping_bag_outlined) : ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(productImageUrl(p)!, width: 44, height: 44, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image))),
                            onChanged: (v) {
                              final id = '${p['id']}';
                              if (v == true) {
                                if (max != null && sel.length >= max) {
                                  snack(ctx, 'Maximum $max produits.');
                                  return;
                                }
                                set(() => sel.add(id));
                              } else {
                                set(() => sel.remove(id));
                              }
                            },
                          ),
                      ]),
              ),
              Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity, child: FilledButton(onPressed: () => Navigator.pop(ctx, sel.toList()), child: Text('Valider (${sel.length})')))),
            ]),
          ),
        ),
      ),
    );
  }

  // ----- Onglet Modèle -----
  Widget _tabTemplates() => ListView(padding: const EdgeInsets.all(12), children: [
        const Text('Choisissez un modèle adapté à votre commerce. Vous pourrez ensuite tout ajuster.', style: TextStyle(color: Colors.black54)),
        const SizedBox(height: 8),
        for (final e in _tpls.entries)
          Card(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14), side: BorderSide(color: _d.template == e.key ? brand : Colors.transparent, width: 2)),
            child: ListTile(
              leading: CircleAvatar(backgroundColor: parseHex(e.value.primary), child: Icon(e.value.icon, color: onColor(parseHex(e.value.primary)))),
              title: Text(e.value.label, style: const TextStyle(fontWeight: FontWeight.w800)),
              subtitle: Text(e.value.desc),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                _dot(e.value.primary),
                _dot(e.value.secondary),
                if (_d.template == e.key) const Padding(padding: EdgeInsets.only(left: 6), child: Icon(Icons.check_circle, color: brand)),
              ]),
              onTap: () => _change(() {
                _d.applyTemplate(e.key);
                _syncControllers();
              }),
            ),
          ),
      ]);

  Widget _dot(String hex) => Container(width: 16, height: 16, margin: const EdgeInsets.only(left: 4), decoration: BoxDecoration(color: parseHex(hex), shape: BoxShape.circle, border: Border.all(color: Colors.black12)));

  // ----- Onglet Identité -----
  Widget _colorPicker(String label, String current, TextEditingController c, void Function(String) set) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
        const SizedBox(height: 6),
        Wrap(spacing: 8, runSpacing: 8, children: [
          for (final h in _palette)
            GestureDetector(
              onTap: () => _change(() {
                set(h);
                c.text = h;
              }),
              child: Container(
                width: 34,
                height: 34,
                decoration: BoxDecoration(color: parseHex(h), shape: BoxShape.circle, border: Border.all(color: current.toUpperCase() == h ? Colors.black : Colors.black12, width: current.toUpperCase() == h ? 3 : 1)),
              ),
            ),
        ]),
        const SizedBox(height: 8),
        SizedBox(
          width: 170,
          child: TextField(
            controller: c,
            maxLength: 7,
            decoration: const InputDecoration(labelText: 'Code couleur (#RRGGBB)', border: OutlineInputBorder(), counterText: ''),
            onChanged: (v) {
              final t = v.trim().startsWith('#') ? v.trim() : '#${v.trim()}';
              if (_hexRe.hasMatch(t)) _change(() => set(t.toUpperCase()));
            },
          ),
        ),
      ]);

  Widget _tabIdentity() => ListView(padding: const EdgeInsets.all(12), children: [
        OutlinedButton.icon(onPressed: _editIdentity, icon: const Icon(Icons.image_outlined), label: const Text('Logo, bannière, description, coordonnées', textAlign: TextAlign.center)),
        const Padding(padding: EdgeInsets.only(top: 4, bottom: 12), child: Text('Ces informations s\'enregistrent immédiatement.', style: TextStyle(fontSize: 11, color: Colors.black54))),
        TextField(
          controller: _tagline,
          maxLength: 120,
          decoration: const InputDecoration(labelText: 'Slogan (facultatif)', border: OutlineInputBorder()),
          onChanged: (v) => _change(() => _d.tagline = v),
        ),
        const SizedBox(height: 8),
        _colorPicker('Couleur principale', _d.primary, _hexP, (h) => _d.primary = h),
        const SizedBox(height: 16),
        _colorPicker('Couleur secondaire', _d.secondary, _hexS, (h) => _d.secondary = h),
        const SizedBox(height: 16),
        const Text('Police', style: TextStyle(fontWeight: FontWeight.w700)),
        Wrap(spacing: 8, children: [
          for (final e in _fontLabels.entries)
            ChoiceChip(
              label: Text(e.value, style: TextStyle(fontFamily: _fontFamilies[e.key])),
              selected: _d.font == e.key,
              onSelected: (_) => _change(() => _d.font = e.key),
            ),
        ]),
        const SizedBox(height: 16),
        const Text('Style des cartes', style: TextStyle(fontWeight: FontWeight.w700)),
        Wrap(spacing: 8, children: [
          for (final e in _radiusLabels.entries) ChoiceChip(label: Text(e.value), selected: _d.radius == e.key, onSelected: (_) => _change(() => _d.radius = e.key)),
        ]),
      ]);

  // ----- Onglet Organisation -----
  Future<void> _addCategory() async {
    final name = await askText(context, 'Nom de la catégorie', hint: 'Ex. Robes, Téléphones, Riz…', multiline: false);
    if (name == null || name.trim().isEmpty || !mounted) return;
    if (name.trim().length > 40) return snack(context, '40 caractères maximum.');
    if (_d.categories.length >= 20) return snack(context, 'Maximum 20 catégories.');
    if (_d.categories.any((c) => c.name.toLowerCase() == name.trim().toLowerCase())) return snack(context, 'Cette catégorie existe déjà.');
    _change(() => _d.categories.add(CategoryCfg(name.trim(), [])));
  }

  Future<void> _renameCategory(CategoryCfg c) async {
    final name = await askText(context, 'Renommer la catégorie', hint: c.name, multiline: false);
    if (name == null || name.trim().isEmpty || name.trim().length > 40) return;
    _change(() => c.name = name.trim());
  }

  Future<void> _assign(CategoryCfg c) async {
    final r = await _pickProducts('Produits de « ${c.name} »', c.products);
    if (r != null) _change(() => c.products = r);
  }

  Widget _tabOrganisation() => ListView(padding: const EdgeInsets.all(12), children: [
        const Text('Disposition des produits', style: TextStyle(fontWeight: FontWeight.w700)),
        Wrap(spacing: 8, children: [
          for (final e in _layoutLabels.entries)
            ChoiceChip(avatar: Icon(_layoutIcons[e.key], size: 18), label: Text(e.value), selected: _d.layout == e.key, onSelected: (_) => _change(() => _d.layout = e.key)),
        ]),
        const SizedBox(height: 16),
        const Text('Sections (glissez pour réordonner, interrupteur pour afficher)', style: TextStyle(fontWeight: FontWeight.w700)),
        ReorderableListView(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          onReorder: (a, b) => _change(() {
            if (b > a) b -= 1;
            _d.sections.insert(b, _d.sections.removeAt(a));
          }),
          children: [
            for (final s in _d.sections)
              SwitchListTile(
                key: ValueKey(s.id),
                contentPadding: const EdgeInsets.only(left: 4, right: 40),
                secondary: const Icon(Icons.drag_handle),
                title: Text(_sectionLabels[s.id] ?? s.id),
                value: s.on,
                onChanged: (v) => _change(() => s.on = v),
              ),
          ],
        ),
        const SizedBox(height: 12),
        OutlinedButton.icon(
          onPressed: () async {
            final r = await _pickProducts('Produits en vedette (12 max)', _d.featured, max: 12);
            if (r != null) _change(() => _d.featured = r);
          },
          icon: const Icon(Icons.star_outline),
          label: Text('Produits en vedette (${_d.featured.length}/12)'),
        ),
        const SizedBox(height: 16),
        Row(children: [
          const Expanded(child: Text('Catégories personnalisées', style: TextStyle(fontWeight: FontWeight.w700))),
          TextButton.icon(onPressed: _addCategory, icon: const Icon(Icons.add), label: const Text('Ajouter')),
        ]),
        if (_d.categories.isEmpty) const Text('Aucune catégorie. Ajoutez-en pour que vos clients filtrent vos produits.', style: TextStyle(color: Colors.black54)),
        for (final c in _d.categories)
          Card(
            child: ListTile(
              title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text('${c.products.length} produit(s)'),
              onTap: () => _assign(c),
              trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                IconButton(tooltip: 'Renommer', icon: const Icon(Icons.edit_outlined), onPressed: () => _renameCategory(c)),
                IconButton(tooltip: 'Supprimer', icon: const Icon(Icons.delete_outline), onPressed: () => _change(() => _d.categories.remove(c))),
              ]),
            ),
          ),
        if (_pending > 0) Padding(padding: const EdgeInsets.only(top: 12), child: Text('$_pending produit(s) en attente de validation : ils apparaîtront dans la boutique une fois validés par l\'administration.', style: const TextStyle(fontSize: 12, color: Colors.black54))),
      ]);

  @override
  Widget build(BuildContext context) {
    if (_loading) return Scaffold(appBar: AppBar(title: const Text('Personnaliser ma boutique')), body: const Center(child: CircularProgressIndicator()));
    if (_err != null) return Scaffold(appBar: AppBar(title: const Text('Personnaliser ma boutique')), body: Center(child: Column(mainAxisSize: MainAxisSize.min, children: [errorView(_err), FilledButton(onPressed: () => _load(initial: true), child: const Text('Réessayer'))])));
    if (_shop == null) return Scaffold(appBar: AppBar(title: const Text('Personnaliser ma boutique')), body: const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Créez d\'abord votre boutique dans l\'onglet Boutique (nom, logo, bannière).', textAlign: TextAlign.center))));
    final published = _shop!['published_at'] != null;
    final status = _dirty ? 'Modifications non enregistrées' : (published ? 'Dernière publication : ${dt(_shop!['published_at'])}' : 'Brouillon : pas encore publié');
    return PopScope(
      canPop: !_dirty,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        final leave = await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: const Text('Quitter sans enregistrer ?'),
            content: const Text('Vos modifications seront perdues.'),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Rester')),
              FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Quitter')),
            ],
          ),
        );
        if (leave == true && mounted) Navigator.of(context).pop();
      },
      child: Scaffold(
        appBar: AppBar(title: const Text('Personnaliser ma boutique'), actions: [
          IconButton(tooltip: _bigPreview ? 'Réduire l\'aperçu' : 'Agrandir l\'aperçu', icon: Icon(_bigPreview ? Icons.close_fullscreen : Icons.open_in_full), onPressed: () => setState(() => _bigPreview = !_bigPreview)),
        ]),
        body: Column(children: [
          Expanded(
            flex: _bigPreview ? 8 : 4,
            child: Stack(children: [
              ClipRect(child: ShopView(shop: _shop!, design: _d, products: _products, onProductTap: (_) {})),
              Positioned(
                left: 8,
                top: 8,
                child: Container(padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3), decoration: BoxDecoration(color: Colors.black54, borderRadius: BorderRadius.circular(10)), child: const Text('APERÇU EN DIRECT', style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.w700))),
              ),
            ]),
          ),
          if (!_bigPreview)
            Expanded(
              flex: 5,
              child: DefaultTabController(
                length: 3,
                child: Column(children: [
                  const Material(color: Colors.white, child: TabBar(tabs: [Tab(text: 'Modèle'), Tab(text: 'Identité'), Tab(text: 'Organisation')])),
                  Expanded(child: TabBarView(children: [_tabTemplates(), _tabIdentity(), _tabOrganisation()])),
                ]),
              ),
            ),
          Material(
            color: Colors.white,
            elevation: 8,
            child: SafeArea(
              top: false,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(10, 6, 10, 8),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  Text(status, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: _dirty ? maliRed : Colors.black54)),
                  const SizedBox(height: 6),
                  Row(children: [
                    Expanded(child: OutlinedButton(onPressed: _busy ? null : _save, child: const Text('Enregistrer', style: TextStyle(fontSize: 12)))),
                    const SizedBox(width: 6),
                    Expanded(child: OutlinedButton(onPressed: _busy ? null : _preview, child: const Text('Prévisualiser', style: TextStyle(fontSize: 12)))),
                    const SizedBox(width: 6),
                    Expanded(child: FilledButton(onPressed: _busy ? null : _publish, child: Text(_busy ? '…' : 'Publier', style: const TextStyle(fontSize: 12)))),
                  ]),
                ]),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}

// =====================================================================
// Administration : consulter et modérer les boutiques
// =====================================================================
class AdminShopsScreen extends StatefulWidget {
  const AdminShopsScreen({super.key});
  @override
  State<AdminShopsScreen> createState() => _AdminShopsScreenState();
}

class _AdminShopsScreenState extends State<AdminShopsScreen> {
  late Future<List<dynamic>> _f = _load();
  String _q = '';

  Future<List<dynamic>> _load() => sb.from('shops').select('*, profiles!owner_id(full_name, phone)').order('created_at', ascending: false).limit(300);
  void _reload() => setState(() => _f = _load());

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(10),
          child: TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher une boutique ou un vendeur', border: OutlineInputBorder()), onChanged: (v) => setState(() => _q = v.trim().toLowerCase())),
        ),
        Expanded(
          child: FutureBuilder<List<dynamic>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return errorView(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final rows = [for (final r in snap.data!) Map<String, dynamic>.from(r as Map)];
              final shown = [
                for (final s in rows)
                  if (_q.isEmpty || '${s['name']}'.toLowerCase().contains(_q) || '${(s['profiles'] as Map?)?['full_name'] ?? ''}'.toLowerCase().contains(_q)) s,
              ];
              if (shown.isEmpty) return const Center(child: Text('Aucune boutique.'));
              return RefreshIndicator(
                onRefresh: () async => _reload(),
                child: ListView(children: [
                  for (final s in shown)
                    ListTile(
                      leading: CircleAvatar(backgroundImage: storageUrl('shop-assets', s['logo_path'] as String?) == null ? null : NetworkImage(storageUrl('shop-assets', s['logo_path'] as String?)!), child: s['logo_path'] == null ? const Icon(Icons.store) : null),
                      title: Text('${s['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${(s['profiles'] as Map?)?['full_name'] ?? 'Vendeur'} · ${s['design'] != null ? 'design publié' : 'design par défaut'}${s['design_draft'] != null && s['design'] == null ? ' (brouillon)' : ''}'),
                      trailing: Text(s['status'] == 'suspended' ? 'SUSPENDUE' : 'ACTIVE', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 11, color: s['status'] == 'suspended' ? maliRed : maliGreen)),
                      onTap: () async {
                        await Navigator.push(context, MaterialPageRoute(builder: (_) => AdminShopReview(shop: s)));
                        if (mounted) _reload();
                      },
                    ),
                ]),
              );
            },
          ),
        ),
      ]);
}

class AdminShopReview extends StatefulWidget {
  final Map<String, dynamic> shop;
  const AdminShopReview({super.key, required this.shop});
  @override
  State<AdminShopReview> createState() => _AdminShopReviewState();
}

class _AdminShopReviewState extends State<AdminShopReview> {
  late Map<String, dynamic> _shop = widget.shop;
  List<Map<String, dynamic>> _products = [], _log = [];
  bool _loading = true, _draft = false;
  String? _err;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final s = await sb.from('shops').select().eq('id', _shop['id']).single();
      final rows = await sb.from('products').select('id, name, price, promo_price, unit, image_path, stock, created_at, status').eq('created_by', _shop['owner_id']).order('created_at', ascending: false);
      final log = await sb.from('shop_moderation_log').select().eq('shop_id', _shop['id']).order('created_at', ascending: false).limit(20);
      if (!mounted) return;
      setState(() {
        _shop = {..._shop, ...Map<String, dynamic>.from(s)};
        _products = [for (final r in rows) Map<String, dynamic>.from(r as Map)];
        _log = [for (final r in log) Map<String, dynamic>.from(r as Map)];
        _loading = false;
        _err = null;
      });
    } catch (e) {
      if (mounted) setState(() {
            _err = '$e';
            _loading = false;
          });
    }
  }

  Future<void> _act(String action, {required bool needNote, required String title}) async {
    String? note;
    if (needNote) {
      note = await askText(context, title, hint: 'Motif (visible par le vendeur)');
      if (note == null || note.isEmpty || !mounted) return;
    }
    await guarded(context, () async {
      await sb.rpc('admin_moderate_shop', params: {'p_shop': _shop['id'], 'p_action': action, 'p_note': note});
      await _load();
      if (mounted) snack(context, 'Action enregistrée.');
    });
  }

  @override
  Widget build(BuildContext context) {
    final suspended = _shop['status'] == 'suspended';
    return Scaffold(
      appBar: AppBar(title: Text('${_shop['name']}')),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _err != null
              ? errorView(_err)
              : Column(children: [
                  Padding(
                    padding: const EdgeInsets.all(8),
                    child: Wrap(spacing: 8, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
                      Text(suspended ? 'SUSPENDUE' : 'ACTIVE', style: TextStyle(fontWeight: FontWeight.w800, color: suspended ? maliRed : maliGreen)),
                      ChoiceChip(label: const Text('Version publiée'), selected: !_draft, onSelected: (_) => setState(() => _draft = false)),
                      ChoiceChip(label: const Text('Brouillon'), selected: _draft, onSelected: (_) => setState(() => _draft = true)),
                    ]),
                  ),
                  if ('${_shop['moderation_note'] ?? ''}'.isNotEmpty) Container(width: double.infinity, color: const Color(0xFFFFF3E0), padding: const EdgeInsets.all(8), child: Text('Note : ${_shop['moderation_note']}', style: const TextStyle(fontSize: 12))),
                  Expanded(
                    child: ShopView(
                      shop: _shop,
                      design: ShopDesign.fromJson(_draft ? (_shop['design_draft'] ?? _shop['design']) : _shop['design']),
                      products: [for (final p in _products) if (p['status'] == 'approved') p],
                      onProductTap: (_) {},
                    ),
                  ),
                  Material(
                    elevation: 8,
                    color: Colors.white,
                    child: SafeArea(
                      top: false,
                      child: Padding(
                        padding: const EdgeInsets.all(8),
                        child: Column(mainAxisSize: MainAxisSize.min, children: [
                          if (_log.isNotEmpty) Padding(padding: const EdgeInsets.only(bottom: 6), child: Text('Dernière action : ${_log.first['action']} · ${dt(_log.first['created_at'])}${_log.first['note'] != null ? ' · ${_log.first['note']}' : ''}', style: const TextStyle(fontSize: 11, color: Colors.black54), maxLines: 2, overflow: TextOverflow.ellipsis)),
                          Row(children: [
                            Expanded(
                              child: suspended
                                  ? FilledButton(onPressed: () => _act('activate', needNote: false, title: ''), child: const Text('Réactiver', style: TextStyle(fontSize: 12)))
                                  : FilledButton(style: FilledButton.styleFrom(backgroundColor: maliRed), onPressed: () => _act('suspend', needNote: true, title: 'Motif de la suspension'), child: const Text('Suspendre', style: TextStyle(fontSize: 12))),
                            ),
                            const SizedBox(width: 6),
                            Expanded(child: OutlinedButton(onPressed: () => _act('reset_design', needNote: true, title: 'Motif de la réinitialisation du design'), child: const Text('Réinitialiser design', style: TextStyle(fontSize: 12), textAlign: TextAlign.center))),
                          ]),
                        ]),
                      ),
                    ),
                  ),
                ]),
    );
  }
}
