import 'package:flutter/material.dart';
import 'common.dart';
import 'delivery_common.dart';
import 'delivery_mission.dart';

List<Map<String, dynamic>> _rows(dynamic v) =>
    v is List ? List<Map<String, dynamic>>.from(v.map((e) => Map<String, dynamic>.from(e as Map))) : <Map<String, dynamic>>[];

// ======================================================================================
//  Administration : toutes les livraisons, incidents, litiges, suspensions
// ======================================================================================
class AdminDeliveriesScreen extends StatelessWidget {
  const AdminDeliveriesScreen({super.key});
  @override
  Widget build(BuildContext context) => DefaultTabController(
        length: 2,
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Livraisons MAYA'),
            bottom: const TabBar(
              indicatorColor: gold,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white70,
              tabs: [Tab(icon: Icon(Icons.local_shipping), text: 'Toutes les livraisons'), Tab(icon: Icon(Icons.block), text: 'Livreurs suspendus')],
            ),
          ),
          body: const TabBarView(children: [_AllDeliveries(), _Blocks()]),
        ),
      );
}

class _AllDeliveries extends StatefulWidget {
  const _AllDeliveries();
  @override
  State<_AllDeliveries> createState() => _AllDeliveriesState();
}

class _AllDeliveriesState extends State<_AllDeliveries> {
  String? _kind, _status;
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async => _rows(await sb.rpc('admin_delivery_list', params: {'p_status': _status, 'p_kind': _kind}));
  void _reload() => setState(() => _f = _load());

  Future<void> _suspend(Map<String, dynamic> d) async {
    final phone = d['courier_phone'] as String?;
    if (phone == null || phone.isEmpty) return snack(context, 'Pas de numéro pour ce livreur.');
    final reason = await askText(context, 'Motif de la suspension de ${d['courier_name'] ?? 'ce livreur'}');
    if (reason == null || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('admin_delivery_block', params: {'p_phone': phone, 'p_reason': reason, 'p_block': true});
      if (mounted) snack(context, 'Livreur suspendu. Ses missions non terminées sont annulées.');
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: Row(children: [
            Expanded(
              child: DropdownButtonFormField<String?>(
                value: _kind,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Type de livraison', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: null, child: Text('Tous les types')),
                  DropdownMenuItem(value: 'maya_carrier', child: Text('Transporteur partenaire MAYA')),
                  DropdownMenuItem(value: 'own_courier', child: Text('Livreur personnel du vendeur')),
                ],
                onChanged: (v) {
                  _kind = v;
                  _reload();
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: DropdownButtonFormField<String?>(
                value: _status,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Statut', border: OutlineInputBorder()),
                items: [const DropdownMenuItem(value: null, child: Text('Tous les statuts')), for (final e in deliveryStatusLabels.entries) DropdownMenuItem(value: e.key, child: Text(e.value, overflow: TextOverflow.ellipsis))],
                onChanged: (v) {
                  _status = v;
                  _reload();
                },
              ),
            ),
          ]),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return errorView(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!;
              final incidents = list.fold<int>(0, (a, d) => a + (n(d['open_incidents']).toInt()));
              final disputes = list.where((d) => d['status'] == 'not_received').length;
              return RefreshIndicator(
                onRefresh: () async => _reload(),
                child: ListView(padding: const EdgeInsets.fromLTRB(8, 0, 8, 24), children: [
                  Wrap(spacing: 8, children: [
                    Chip(label: Text('${list.length} livraison(s)')),
                    Chip(label: Text('$incidents incident(s) ouvert(s)'), backgroundColor: incidents > 0 ? const Color(0xFFFFEBEE) : null),
                    Chip(label: Text('$disputes colis non reçu(s)'), backgroundColor: disputes > 0 ? const Color(0xFFFFEBEE) : null),
                  ]),
                  if (list.isEmpty) const Padding(padding: EdgeInsets.all(24), child: Center(child: Text('Aucune livraison.'))),
                  for (final d in list) _card(d),
                ]),
              );
            },
          ),
        ),
      ]);

  Widget _card(Map<String, dynamic> d) {
    final own = d['kind'] == 'own_courier';
    final kindColor = own ? gold : brand;
    return Card(
      margin: const EdgeInsets.only(top: 8),
      child: InkWell(
        onTap: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => MissionScreen(missionId: d['id'] as String)));
          _reload();
        },
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Expanded(child: Text('Commande ${d['order_number']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
              DeliveryStatusChip(d['status'] as String),
            ]),
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: kindColor.withOpacity(0.12), borderRadius: BorderRadius.circular(6), border: Border.all(color: kindColor)),
              child: Text('${d['kind_label']}', style: TextStyle(color: kindColor, fontWeight: FontWeight.bold, fontSize: 12)),
            ),
            const SizedBox(height: 6),
            Text('Vendeur : ${d['seller_name'] ?? ''}  ·  Client : ${d['client_name'] ?? ''}', style: const TextStyle(fontSize: 12.5)),
            Text('Livreur : ${d['courier_name'] ?? '—'}${d['courier_phone'] != null ? ' · ${d['courier_phone']}' : ''}', style: const TextStyle(fontSize: 12.5)),
            if (d['dropoff_city'] != null) Text('Destination : ${d['dropoff_city']}', style: const TextStyle(fontSize: 12.5)),
            if (d['fee'] != null) Text('Tarif : ${money(d['fee'])}', style: const TextStyle(fontSize: 12.5)),
            if (d['est_delivery_at'] != null) Text('Heure estimée : ${dt(d['est_delivery_at'])}', style: const TextStyle(fontSize: 12.5)),
            if (n(d['open_incidents']) > 0) Text('⚠ ${d['open_incidents']} incident(s) ouvert(s)', style: const TextStyle(color: Colors.red, fontWeight: FontWeight.bold)),
            Row(mainAxisAlignment: MainAxisAlignment.end, children: [
              if (d['courier_phone'] != null) IconButton(tooltip: 'Appeler le livreur', icon: const Icon(Icons.call, color: brand), onPressed: () => callPhone(context, d['courier_phone'] as String?)),
              if (d['courier_phone'] != null) TextButton.icon(icon: const Icon(Icons.block, color: Colors.red), label: const Text('Suspendre', style: TextStyle(color: Colors.red)), onPressed: () => _suspend(d)),
            ]),
          ]),
        ),
      ),
    );
  }
}

class _Blocks extends StatefulWidget {
  const _Blocks();
  @override
  State<_Blocks> createState() => _BlocksState();
}

class _BlocksState extends State<_Blocks> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async => _rows(await sb.rpc('admin_delivery_blocks'));
  void _reload() => setState(() => _f = _load());

  Future<void> _add() async {
    final phone = TextEditingController(text: '+223 ');
    final reason = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Suspendre un livreur'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone du livreur')),
          TextField(controller: reason, maxLines: 2, decoration: const InputDecoration(labelText: 'Motif *')),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
          FilledButton(style: FilledButton.styleFrom(backgroundColor: Colors.red), onPressed: () => Navigator.pop(ctx, true), child: const Text('Suspendre')),
        ],
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('admin_delivery_block', params: {'p_phone': phone.text.trim(), 'p_reason': reason.text.trim(), 'p_block': true});
      _reload();
    });
  }

  Future<void> _lift(Map<String, dynamic> b) => guarded(context, () async {
        await sb.rpc('admin_delivery_block', params: {'p_phone': b['phone_key'], 'p_reason': null, 'p_block': false});
        _reload();
      });

  @override
  Widget build(BuildContext context) => Scaffold(
        floatingActionButton: FloatingActionButton.extended(icon: const Icon(Icons.block), label: const Text('Suspendre'), onPressed: _add),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            final list = snap.data!;
            if (list.isEmpty) return const Center(child: Text('Aucun livreur suspendu.'));
            return ListView(padding: const EdgeInsets.fromLTRB(8, 8, 8, 90), children: [
              for (final b in list)
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.block, color: Colors.red),
                    title: Text('Numéro se terminant par ${b['phone_key']}'),
                    subtitle: Text('${b['reason']}\n${dt(b['at'])}'),
                    isThreeLine: true,
                    trailing: TextButton(onPressed: () => _lift(b), child: const Text('Lever')),
                  ),
                ),
            ]);
          },
        ),
      );
}
