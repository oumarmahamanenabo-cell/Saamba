const supabaseUrl = 'https://juaidyvcngqizxvnsxke.supabase.co';
const supabaseKey = 'sb_publishable_0hMHJrEkJ5uZyip61AvbYg_s9ZzMTrO';

/// Adresse publique utilisée pour les liens de partage (produits et boutiques).
/// Remplacez-la par le domaine où vous hébergez le dossier public_page/.
const shareBaseUrl = 'https://maya.app';

/// Coordonnées publiques de MAYA affichées sur la page d'accueil. Laisser vide ce qui n'existe pas encore :
/// un bouton sans lien configuré affiche « bientôt disponible » au lieu d'ouvrir un faux lien.
const supportWhatsapp = ''; // ex. '22370000000' (chiffres, indicatif pays inclus)
const supportPhone = ''; // ex. '+22370000000'
const supportEmail = ''; // ex. 'contact@maya.app'
const socialFacebook = ''; // ex. 'https://facebook.com/votrepage'
const socialYoutube = '';
const socialTiktok = '';
