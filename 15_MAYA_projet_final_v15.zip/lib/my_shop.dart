import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'chat.dart' show ChatScreen;
import 'common.dart';
import 'guest.dart';
import 'shop.dart' show messageAdmin, FavoriteButton;
import 'shop_design.dart';
import 'shop_media.dart';

// ======== Espace vendeur : ma boutique ========
class MyShopScreen extends StatefulWidget {
  /// Ouvre directement le formulaire (logo, bannière, coordonnées) ; se ferme après l'enregistrement.
  final bool startEditing;
  const MyShopScreen({super.key, this.startEditing = false});
  @override
  State<MyShopScreen> createState() => _MyShopScreenState();
}

class _MyShopScreenState extends State<MyShopScreen> {
  Map<String, dynamic>? _shop;
  bool _loading = true, _editing = false, _busy = false;
  String? _err;
  final _name = TextEditingController();
  final _desc = TextEditingController();
  final _phone = TextEditingController();
  final _wa = TextEditingController();
  final _email = TextEditingController();
  final _addr = TextEditingController();
  final _city = TextEditingController();
  File? _logo, _banner;

  @override
  void initState() {
    super.initState();
    _load();
  }

  void _fill(Map<String, dynamic> s) {
    _name.text = '${s['name'] ?? ''}';
    _desc.text = '${s['description'] ?? ''}';
    _phone.text = '${s['phone'] ?? ''}';
    _wa.text = '${s['whatsapp'] ?? ''}';
    _email.text = '${s['email'] ?? ''}';
    _addr.text = '${s['address'] ?? ''}';
    _city.text = '${s['city'] ?? ''}';
  }

  Future<void> _load() async {
    try {
      final r = await sb.from('shops').select().eq('owner_id', uid).maybeSingle();
      if (!mounted) return;
      setState(() {
        _shop = r;
        _loading = false;
        _err = null;
        _editing = r == null || widget.startEditing;
      });
      if (r != null) _fill(r);
    } catch (e) {
      if (mounted) setState(() {
            _err = '$e';
            _loading = false;
          });
    }
  }

  Future<void> _pick(bool logo) async {
    final x = await ImagePicker().pickImage(source: ImageSource.gallery, imageQuality: 75, maxWidth: logo ? 512 : 1600);
    if (x == null) return;
    setState(() => logo ? _logo = File(x.path) : _banner = File(x.path));
  }

  Future<String> _upload(File f, String prefix) async {
    final path = '$uid/${prefix}_${DateTime.now().microsecondsSinceEpoch}.jpg';
    await sb.storage.from('shop-assets').upload(path, f, fileOptions: const FileOptions(contentType: 'image/jpeg'));
    return path;
  }

  Future<void> _save() async {
    final name = _name.text.trim();
    if (name.length < 2) return snack(context, 'Le nom de la boutique est obligatoire (2 caractères minimum).');
    setState(() => _busy = true);
    await guarded(context, () async {
      String? logo = _shop?['logo_path'] as String?;
      String? banner = _shop?['banner_path'] as String?;
      if (_logo != null) logo = await _upload(_logo!, 'logo');
      if (_banner != null) banner = await _upload(_banner!, 'banner');
      String? nz(TextEditingController c) => c.text.trim().isEmpty ? null : c.text.trim();
      final data = {
        'name': name,
        'description': nz(_desc),
        'phone': nz(_phone),
        'whatsapp': nz(_wa),
        'email': nz(_email),
        'address': nz(_addr),
        'city': nz(_city),
        'logo_path': logo,
        'banner_path': banner,
      };
      final Map<String, dynamic> row;
      if (_shop == null) {
        row = await sb.from('shops').insert({...data, 'owner_id': uid}).select().single();
      } else {
        row = await sb.from('shops').update(data).eq('id', _shop!['id']).select().single();
      }
      if (!mounted) return;
      setState(() {
        _shop = row;
        _editing = false;
        _logo = null;
        _banner = null;
      });
      snack(context, 'Boutique enregistrée.');
      if (widget.startEditing && mounted) Navigator.of(context).pop();
    });
    if (mounted) setState(() => _busy = false);
  }

  Widget _field(TextEditingController c, String label, {int lines = 1, TextInputType? type}) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: TextField(controller: c, maxLines: lines, keyboardType: type, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
      );

  Widget _imagePick(String label, File? f, String? path, bool logo) {
    final url = storageUrl('shop-assets', path);
    final Widget inner = f != null
        ? Image.file(f, fit: BoxFit.cover)
        : (url != null ? Image.network(url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image)) : Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const Icon(Icons.add_a_photo_outlined), Text(label)])));
    return InkWell(
      onTap: () => _pick(logo),
      child: Container(height: logo ? 100 : 130, width: logo ? 100 : double.infinity, decoration: softBox(), clipBehavior: Clip.antiAlias, child: inner),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Center(child: CircularProgressIndicator());
    if (_err != null) return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [errorView(_err), FilledButton(onPressed: _load, child: const Text('Réessayer'))]));
    if (_editing) {
      return ListView(padding: const EdgeInsets.all(12), children: [
        Text(_shop == null ? 'Créer ma boutique' : 'Modifier ma boutique', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
        const SizedBox(height: 10),
        _imagePick('Bannière', _banner, _shop?['banner_path'] as String?, false),
        const SizedBox(height: 10),
        Row(children: [_imagePick('Logo', _logo, _shop?['logo_path'] as String?, true)]),
        const SizedBox(height: 12),
        _field(_name, 'Nom de la boutique *'),
        _field(_desc, 'Description', lines: 3),
        _field(_city, 'Ville'),
        _field(_addr, 'Adresse'),
        _field(_phone, 'Téléphone professionnel', type: TextInputType.phone),
        _field(_wa, 'WhatsApp (avec indicatif, ex. +223…)', type: TextInputType.phone),
        _field(_email, 'E-mail professionnel', type: TextInputType.emailAddress),
        FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? '…' : 'Enregistrer')),
        if (_shop != null) TextButton(onPressed: () => setState(() => _editing = false), child: const Text('Annuler')),
      ]);
    }
    final s = _shop!;
    final slug = '${s['slug']}';
    final banner = storageUrl('shop-assets', s['banner_path'] as String?);
    final logo = storageUrl('shop-assets', s['logo_path'] as String?);
    return ListView(padding: const EdgeInsets.all(12), children: [
      ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: SizedBox(height: 140, width: double.infinity, child: banner == null ? const ColoredBox(color: Color(0xFFEFF3EE), child: Icon(Icons.storefront, size: 48)) : Image.network(banner, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.broken_image))),
      ),
      const SizedBox(height: 10),
      Row(children: [
        CircleAvatar(radius: 30, backgroundColor: const Color(0xFFEFF3EE), backgroundImage: logo == null ? null : NetworkImage(logo), child: logo == null ? const Icon(Icons.store) : null),
        const SizedBox(width: 12),
        Expanded(child: Text('${s['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800))),
      ]),
      if ('${s['description'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('${s['description']}')),
      const SizedBox(height: 6),
      for (final e in [['Ville', s['city']], ['Adresse', s['address']], ['Téléphone', s['phone']], ['WhatsApp', s['whatsapp']], ['E-mail', s['email']]])
        if (e[1] != null && '${e[1]}'.isNotEmpty) Text('${e[0]} : ${e[1]}'),
      if (s['status'] == 'suspended') const Padding(padding: EdgeInsets.only(top: 8), child: Text('Boutique suspendue par l\'administration.', style: TextStyle(color: maliRed, fontWeight: FontWeight.w700))),
      if ('${s['moderation_note'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text('Message de l\'administration : ${s['moderation_note']}', style: const TextStyle(color: maliRed))),
      const SizedBox(height: 12),
      FilledButton.icon(
        onPressed: () async {
          await Navigator.push(context, MaterialPageRoute(builder: (_) => const ShopDesignEditor()));
          if (mounted) _load();
        },
        icon: const Icon(Icons.palette_outlined),
        label: const Text('Personnaliser le design de ma boutique'),
      ),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => setState(() => _editing = true), icon: const Icon(Icons.edit), label: const Text('Modifier logo, bannière, coordonnées')),
      const SizedBox(height: 8),
      OutlinedButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopPage(slug: slug))), icon: const Icon(Icons.visibility_outlined), label: const Text('Voir comme un client')),
      const SizedBox(height: 8),
      Row(children: [
        Expanded(child: OutlinedButton.icon(onPressed: () => copyLink(context, shopLink(slug)), icon: const Icon(Icons.link), label: const Text('COPIER LE LIEN DE MA BOUTIQUE', textAlign: TextAlign.center, style: TextStyle(fontSize: 11)))),
        const SizedBox(width: 8),
        Expanded(child: FilledButton.icon(onPressed: () => shareLink(context, 'Découvrez ma boutique « ${s['name']} » sur MAYA : ${shopLink(slug)}', subject: '${s['name']}'), icon: const Icon(Icons.share), label: const Text('PARTAGER MA BOUTIQUE', textAlign: TextAlign.center, style: TextStyle(fontSize: 11)))),
      ]),
    ]);
  }
}

// ======== Vitrine d'une boutique (vue client) ========
class ShopPage extends StatefulWidget {
  final String slug;
  const ShopPage({super.key, required this.slug});
  @override
  State<ShopPage> createState() => _ShopPageState();
}

class _ShopPageState extends State<ShopPage> {
  late Future<dynamic> _f = sb.rpc('public_shop', params: {'p_slug': widget.slug});

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Boutique'), actions: [
          IconButton(tooltip: 'Copier le lien', icon: const Icon(Icons.link), onPressed: () => copyLink(context, shopLink(widget.slug))),
          IconButton(tooltip: 'Partager', icon: const Icon(Icons.share), onPressed: () => shareLink(context, 'Découvrez cette boutique sur MAYA : ${shopLink(widget.slug)}')),
        ]),
        body: FutureBuilder<dynamic>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (snap.data == null) return const Center(child: Text('Boutique introuvable ou indisponible.'));
            final data = Map<String, dynamic>.from(snap.data as Map);
            final s = Map<String, dynamic>.from(data['shop'] as Map);
            final products = [for (final p in (data['products'] as List)) Map<String, dynamic>.from(p as Map)];
            return ShopView(
              shop: s,
              design: ShopDesign.fromJson(data['design']),
              products: products,
              onProductTap: (p) => Navigator.push(context, MaterialPageRoute(builder: (_) => ProductDetailPage(productId: '${p['id']}'))),
            );
          },
        ),
      );
}

// ======== Fiche produit (galerie, vidéo, contact vendeur, partage) ========
class ProductDetailPage extends StatefulWidget {
  final String productId;
  const ProductDetailPage({super.key, required this.productId});
  @override
  State<ProductDetailPage> createState() => _ProductDetailPageState();
}

class _ProductDetailPageState extends State<ProductDetailPage> {
  late Future<Map<String, dynamic>?> _f = _load();

  Future<Map<String, dynamic>?> _load() async {
    final p = await sb.from('products').select().eq('id', widget.productId).maybeSingle();
    if (p == null) return null;
    final rows = await sb.from('product_media').select('kind, path, is_primary, position').eq('product_id', widget.productId).order('is_primary', ascending: false).order('position');
    var media = [for (final r in rows) Map<String, dynamic>.from(r)];
    final legacy = p['image_path'] as String?;
    if (media.isEmpty && legacy != null && legacy.isNotEmpty) media = [{'kind': 'image', 'path': legacy}];
    Map<String, dynamic>? shop;
    if (p['created_by'] != null) {
      final r = await sb.from('shops').select('slug, name, logo_path, city').eq('owner_id', p['created_by']).eq('status', 'active').maybeSingle();
      shop = r == null ? null : Map<String, dynamic>.from(r);
    }
    return {'product': Map<String, dynamic>.from(p), 'media': media, 'shop': shop};
  }

  Future<void> _contact(Map<String, dynamic> p) async {
    // Écrire à un vendeur exige un compte (la fonction serveur refuse aussi tout appel sans connexion).
    if (!await requireAuth(context, reason: 'Connectez-vous ou créez un compte pour contacter ce vendeur.')) return;
    if (!mounted) return;
    await guarded(context, () async {
      final id = await sb.rpc('start_conversation', params: {'p_type': 'product', 'p_ref': p['id']});
      if (!mounted) return;
      Navigator.push(context, MaterialPageRoute(builder: (_) => ChatScreen(conversationId: '$id', title: '${p['name']}')));
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Produit'), actions: [Padding(padding: const EdgeInsets.only(right: 10), child: Center(child: FavoriteButton(productId: widget.productId, size: 36)))]),
        body: FutureBuilder<Map<String, dynamic>?>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (snap.connectionState != ConnectionState.done) return const Center(child: CircularProgressIndicator());
            if (snap.data == null) return const Center(child: Text('Produit introuvable ou indisponible.'));
            final p = snap.data!['product'] as Map<String, dynamic>;
            final media = List<Map<String, dynamic>>.from(snap.data!['media'] as List);
            final shop = snap.data!['shop'] as Map<String, dynamic>?;
            final price = n(p['price']), promo = p['promo_price'] == null ? null : n(p['promo_price']);
            final shown = promo ?? price;
            final inStock = n(p['stock']) > 0;
            final mine = sb.auth.currentUser != null && p['created_by'] == sb.auth.currentUser!.id;
            final link = productLink('${p['id']}');
            return ListView(children: [
              MediaGallery(media: media),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text('${p['name']}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 6),
                  Row(children: [
                    Text(money(shown), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800, color: brandDark)),
                    if (promo != null) Padding(padding: const EdgeInsets.only(left: 8), child: Text(money(price), style: const TextStyle(decoration: TextDecoration.lineThrough, color: Colors.black54))),
                    Text('  / ${p['unit'] ?? 'pièce'}'),
                  ]),
                  const SizedBox(height: 6),
                  Text(inStock ? 'Disponible · stock ${n(p['stock'])}' : 'Rupture de stock', style: TextStyle(fontWeight: FontWeight.w700, color: inStock ? maliGreen : maliRed)),
                  if ('${p['description'] ?? ''}'.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text('${p['description']}')),
                  if (shop != null)
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(backgroundImage: storageUrl('shop-assets', shop['logo_path'] as String?) == null ? null : NetworkImage(storageUrl('shop-assets', shop['logo_path'] as String?)!), child: shop['logo_path'] == null ? const Icon(Icons.store) : null),
                      title: Text('${shop['name']}', style: const TextStyle(fontWeight: FontWeight.w700)),
                      subtitle: Text('${shop['city'] ?? 'Voir la boutique'}'),
                      trailing: const Icon(Icons.chevron_right),
                      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ShopPage(slug: '${shop['slug']}'))),
                    ),
                  const SizedBox(height: 8),
                  if (!mine && p['created_by'] != null) FilledButton.icon(onPressed: () => _contact(p), icon: const Icon(Icons.forum_outlined), label: const Text('Contacter le vendeur')),
                  const SizedBox(height: 8),
                  if (!mine) OutlinedButton.icon(onPressed: inStock ? () => messageAdmin(context, 'Je souhaite commander : ${p['name']} (${money(shown)}).') : null, icon: const Icon(Icons.shopping_cart_outlined), label: const Text('Commander')),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: () => copyLink(context, link), icon: const Icon(Icons.link), label: const Text('COPIER LE LIEN DU PRODUIT', textAlign: TextAlign.center, style: TextStyle(fontSize: 11)))),
                    const SizedBox(width: 8),
                    Expanded(child: FilledButton.icon(onPressed: () => shareLink(context, '${p['name']} — ${money(shown)}${shop != null ? ' · ${shop['name']}' : ''}\n$link', subject: '${p['name']}'), icon: const Icon(Icons.share), label: const Text('PARTAGER LE PRODUIT', textAlign: TextAlign.center, style: TextStyle(fontSize: 11)))),
                  ]),
                ]),
              ),
            ]);
          },
        ),
      );
}
