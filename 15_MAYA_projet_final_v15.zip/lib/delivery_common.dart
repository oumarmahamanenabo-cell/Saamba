import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:geolocator/geolocator.dart';
import 'package:latlong2/latlong.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';

// ======== MAYA DELIVERY CONNECT : éléments communs (statuts, carte, GPS, contacts) ========

/// Statuts « actifs » : le livreur peut partager sa position uniquement pendant ces statuts (règle aussi appliquée par le serveur).
const deliveryActiveStatuses = ['carrier_confirmed', 'picked_up', 'in_progress', 'near_client', 'arrived', 'incident'];
const deliveryFinalStatuses = ['delivered', 'not_received', 'cancelled'];

/// Les 15 statuts de livraison (libellés identiques à ceux du serveur).
const deliveryStatusLabels = <String, String>{
  'preparing': 'Commande en préparation',
  'requested': 'Livraison demandée',
  'searching': 'Recherche d\'un transporteur',
  'carrier_selected': 'Transporteur sélectionné',
  'awaiting_acceptance': 'En attente d\'acceptation',
  'carrier_confirmed': 'Transporteur confirmé',
  'own_courier_assigned': 'Livreur personnel désigné',
  'picked_up': 'Colis récupéré',
  'in_progress': 'Livraison en cours',
  'near_client': 'Livreur proche du client',
  'arrived': 'Livreur arrivé à destination',
  'delivered': 'Colis livré',
  'not_received': 'Livraison signalée comme non reçue',
  'cancelled': 'Livraison annulée',
  'incident': 'Incident de livraison',
};

const deliveryIncidentKinds = <String, String>{
  'client_absent': 'Client absent',
  'wrong_address': 'Adresse incorrecte',
  'phone_unreachable': 'Téléphone injoignable',
  'vehicle_breakdown': 'Véhicule en panne',
  'package_damaged': 'Colis endommagé',
  'delivery_impossible': 'Livraison impossible',
  'delay': 'Retard (cause à préciser)',
  'other': 'Autre problème',
};

String deliveryLabel(String? s) => deliveryStatusLabels[s] ?? (s ?? '');

Color deliveryColor(String? s) {
  switch (s) {
    case 'delivered':
      return brand;
    case 'cancelled':
      return Colors.grey;
    case 'not_received':
    case 'incident':
      return Colors.red;
    case 'carrier_confirmed':
    case 'own_courier_assigned':
      return Colors.teal;
    case 'picked_up':
    case 'in_progress':
    case 'near_client':
    case 'arrived':
      return gold;
    default:
      return Colors.blueGrey;
  }
}

class DeliveryStatusChip extends StatelessWidget {
  final String status;
  const DeliveryStatusChip(this.status, {super.key});
  @override
  Widget build(BuildContext context) {
    final c = deliveryColor(status);
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: c.withOpacity(0.12), borderRadius: BorderRadius.circular(20), border: Border.all(color: c)),
      child: Text(deliveryLabel(status), style: TextStyle(color: c, fontSize: 12, fontWeight: FontWeight.w700)),
    );
  }
}

// ------------------------------------------------------------------ Géolocalisation

/// Demande l'autorisation de géolocalisation puis lit la position actuelle.
/// Affiche toujours d'abord une explication : aucune position n'est lue sans consentement explicite.
/// Retourne null si l'utilisateur refuse ou si le GPS est indisponible (un message est alors affiché).
Future<Position?> askAndGetPosition(BuildContext context, {required String purpose}) async {
  final agree = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('Utiliser ma position ?'),
      content: Text('$purpose\n\nVotre position n\'est lue qu\'après votre accord et n\'est partagée qu\'avec les personnes de cette livraison. '
          'Vous pouvez retirer ou arrêter le partage à tout moment.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Non')),
        FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Autoriser')),
      ],
    ),
  );
  if (agree != true) return null;
  return _readPosition(context);
}

Future<bool> ensureLocationPermission(BuildContext context) async {
  try {
    if (!await Geolocator.isLocationServiceEnabled()) {
      if (context.mounted) snack(context, 'Le GPS du téléphone est désactivé. Activez la localisation puis réessayez.');
      return false;
    }
    var p = await Geolocator.checkPermission();
    if (p == LocationPermission.denied) p = await Geolocator.requestPermission();
    if (p == LocationPermission.denied || p == LocationPermission.deniedForever) {
      if (context.mounted) {
        snack(context, p == LocationPermission.deniedForever
            ? 'Localisation refusée : autorisez-la dans les réglages du téléphone (Applications > MAYA > Autorisations).'
            : 'Localisation refusée.');
      }
      return false;
    }
    return true;
  } catch (e) {
    if (context.mounted) snack(context, 'Localisation indisponible : $e');
    return false;
  }
}

Future<Position?> _readPosition(BuildContext context) async {
  if (!await ensureLocationPermission(context)) return null;
  try {
    return await Geolocator.getCurrentPosition(locationSettings: const LocationSettings(accuracy: LocationAccuracy.high, timeLimit: Duration(seconds: 20)));
  } catch (e) {
    if (context.mounted) snack(context, 'Impossible d\'obtenir votre position pour le moment. Réessayez à l\'extérieur ou saisissez une adresse.');
    return null;
  }
}

double distanceMeters(LatLng a, LatLng b) {
  const r = 6371000.0;
  double rad(double d) => d * math.pi / 180;
  final dLat = rad(b.latitude - a.latitude);
  final dLng = rad(b.longitude - a.longitude);
  final h = math.sin(dLat / 2) * math.sin(dLat / 2) + math.cos(rad(a.latitude)) * math.cos(rad(b.latitude)) * math.sin(dLng / 2) * math.sin(dLng / 2);
  return 2 * r * math.asin(math.min(1, math.sqrt(h)));
}

String distanceText(double m) => m < 1000 ? '${m.round()} m' : '${(m / 1000).toStringAsFixed(1)} km';

LatLng? latLngOf(dynamic lat, dynamic lng) {
  if (lat is! num || lng is! num) return null;
  return LatLng(lat.toDouble(), lng.toDouble());
}

String ago(dynamic iso) {
  if (iso == null) return '';
  final d = DateTime.tryParse('$iso');
  if (d == null) return '';
  final s = DateTime.now().difference(d.toLocal()).inSeconds;
  if (s < 60) return 'il y a ${s < 0 ? 0 : s} s';
  if (s < 3600) return 'il y a ${s ~/ 60} min';
  if (s < 86400) return 'il y a ${s ~/ 3600} h';
  return dt(iso);
}

// ------------------------------------------------------------------ Carte

/// Carte OpenStreetMap (flutter_map). Aucune position n'est inventée : seuls les points réellement fournis sont affichés.
class DeliveryMap extends StatelessWidget {
  final LatLng? pickup, dropoff, courier;
  final double height;
  final void Function(LatLng)? onTap;
  final LatLng? picked;
  const DeliveryMap({super.key, this.pickup, this.dropoff, this.courier, this.height = 260, this.onTap, this.picked});

  @override
  Widget build(BuildContext context) {
    final pts = <LatLng>[
      if (pickup != null) pickup!,
      if (dropoff != null) dropoff!,
      if (courier != null) courier!,
      if (picked != null) picked!,
    ];
    final center = pts.isEmpty
        ? const LatLng(12.6392, -8.0029) // Bamako, vue par défaut quand aucun point n'est connu
        : LatLng(pts.map((p) => p.latitude).reduce((a, b) => a + b) / pts.length, pts.map((p) => p.longitude).reduce((a, b) => a + b) / pts.length);
    double zoom = 12;
    if (pts.length >= 2) {
      var maxD = 0.0;
      for (final a in pts) {
        for (final b in pts) {
          maxD = math.max(maxD, distanceMeters(a, b));
        }
      }
      zoom = maxD < 500 ? 16 : maxD < 2000 ? 14 : maxD < 8000 ? 12.5 : maxD < 30000 ? 11 : maxD < 100000 ? 9 : 7;
    } else if (pts.length == 1) {
      zoom = 15;
    }
    Marker mk(LatLng p, IconData icon, Color color, String label) => Marker(
          point: p,
          width: 70,
          height: 56,
          child: Column(children: [
            Icon(icon, color: color, size: 32),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 4),
              decoration: BoxDecoration(color: Colors.white.withOpacity(0.9), borderRadius: BorderRadius.circular(6)),
              child: Text(label, style: const TextStyle(fontSize: 9.5, fontWeight: FontWeight.bold), maxLines: 1, overflow: TextOverflow.ellipsis),
            ),
          ]),
        );
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: SizedBox(
        height: height,
        child: FlutterMap(
          key: ValueKey('${center.latitude},${center.longitude},$zoom,${picked?.latitude}'),
          options: MapOptions(
            initialCenter: center,
            initialZoom: zoom,
            onTap: onTap == null ? null : (_, p) => onTap!(p),
            interactionOptions: const InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
          ),
          children: [
            TileLayer(urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png', userAgentPackageName: 'com.saamba'),
            MarkerLayer(markers: [
              if (pickup != null) mk(pickup!, Icons.store, brand, 'Récupération'),
              if (dropoff != null) mk(dropoff!, Icons.home, maliRed, 'Livraison'),
              if (courier != null) mk(courier!, Icons.two_wheeler, gold, 'Livreur'),
              if (picked != null) mk(picked!, Icons.place, Colors.blue, 'Choisi'),
            ]),
            const RichAttributionWidget(attributions: [TextSourceAttribution('© OpenStreetMap contributors')]),
          ],
        ),
      ),
    );
  }
}

/// Sélecteur de lieu : carte où l'on déplace un repère, + bouton « Ma position ».
Future<LatLng?> pickOnMap(BuildContext context, {LatLng? start, String title = 'Choisir sur la carte'}) {
  return Navigator.push<LatLng>(context, MaterialPageRoute(builder: (_) => _PickOnMap(start: start, title: title)));
}

class _PickOnMap extends StatefulWidget {
  final LatLng? start;
  final String title;
  const _PickOnMap({this.start, required this.title});
  @override
  State<_PickOnMap> createState() => _PickOnMapState();
}

class _PickOnMapState extends State<_PickOnMap> {
  LatLng? _p;
  @override
  void initState() {
    super.initState();
    _p = widget.start;
  }

  Future<void> _me() async {
    final pos = await askAndGetPosition(context, purpose: 'MAYA va lire votre position actuelle pour placer le repère.');
    if (pos != null && mounted) setState(() => _p = LatLng(pos.latitude, pos.longitude));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Column(children: [
          const Padding(padding: EdgeInsets.all(10), child: Text('Touchez la carte pour déplacer le repère à l\'endroit exact.', style: TextStyle(fontSize: 12.5))),
          Expanded(child: Padding(padding: const EdgeInsets.symmetric(horizontal: 10), child: DeliveryMap(picked: _p, height: double.infinity, onTap: (p) => setState(() => _p = p)))),
          Padding(
            padding: const EdgeInsets.all(10),
            child: Row(children: [
              Expanded(child: OutlinedButton.icon(icon: const Icon(Icons.my_location), label: const Text('Ma position'), onPressed: _me)),
              const SizedBox(width: 8),
              Expanded(child: FilledButton(onPressed: _p == null ? null : () => Navigator.pop(context, _p), child: const Text('Valider ce lieu'))),
            ]),
          ),
        ]),
      );
}

// ------------------------------------------------------------------ Contacts

String cleanPhone(String p) => p.replaceAll(RegExp(r'[^0-9+]'), '');

Future<void> callPhone(BuildContext context, String? phone) async {
  if (phone == null || cleanPhone(phone).length < 6) {
    snack(context, 'Numéro indisponible.');
    return;
  }
  final ok = await launchUrl(Uri.parse('tel:${cleanPhone(phone)}'));
  if (!ok && context.mounted) snack(context, 'Impossible d\'ouvrir le composeur du téléphone.');
}

Future<void> openSms(BuildContext context, String phone, String body) async {
  final ok = await launchUrl(Uri(scheme: 'sms', path: cleanPhone(phone), queryParameters: {'body': body}));
  if (!ok && context.mounted) snack(context, 'Impossible d\'ouvrir les SMS. Copiez le message puis envoyez-le manuellement.');
}

Future<void> openWhatsApp(BuildContext context, String phone, String body) async {
  var d = phone.replaceAll(RegExp(r'\D'), '');
  if (d.length == 8) d = '223$d';
  final ok = await launchUrl(Uri.parse('https://wa.me/$d?text=${Uri.encodeComponent(body)}'), mode: LaunchMode.externalApplication);
  if (!ok && context.mounted) snack(context, 'Impossible d\'ouvrir WhatsApp.');
}

Future<void> copyText(BuildContext context, String text) async {
  await Clipboard.setData(ClipboardData(text: text));
  if (context.mounted) snack(context, 'Copié.');
}

class ContactRow extends StatelessWidget {
  final IconData icon;
  final String role;
  final String? name, phone, extra;
  const ContactRow({super.key, required this.icon, required this.role, this.name, this.phone, this.extra});
  @override
  Widget build(BuildContext context) => ListTile(
        contentPadding: EdgeInsets.zero,
        dense: true,
        leading: CircleAvatar(backgroundColor: brand.withOpacity(0.1), child: Icon(icon, color: brand, size: 20)),
        title: Text('$role : ${name == null || name!.isEmpty ? '—' : name}', style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text([if (phone != null && phone!.isNotEmpty) phone!, if (extra != null && extra!.isNotEmpty) extra!].join(' · ')),
        trailing: phone == null || phone!.isEmpty ? null : IconButton(tooltip: 'Appeler', icon: const Icon(Icons.call, color: brand), onPressed: () => callPhone(context, phone)),
      );
}

Future<DateTime?> pickDateTime(BuildContext context, {DateTime? initial}) async {
  final now = DateTime.now();
  final d = await showDatePicker(context: context, initialDate: initial ?? now, firstDate: now, lastDate: now.add(const Duration(days: 60)));
  if (d == null || !context.mounted) return null;
  final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(initial ?? now.add(const Duration(hours: 2))));
  if (t == null) return null;
  return DateTime(d.year, d.month, d.day, t.hour, t.minute);
}
