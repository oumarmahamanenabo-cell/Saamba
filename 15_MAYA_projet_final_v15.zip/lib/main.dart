import 'dart:async';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'admin.dart';
import 'chat.dart';
import 'client.dart';
import 'common.dart';
import 'config.dart';
import 'guest.dart';
import 'landing.dart';
import 'auth.dart';
import 'seller_apply.dart';
import 'orders.dart';
import 'shop.dart';
import 'wallet.dart';
import 'suppliers.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Supabase.initialize(url: supabaseUrl, anonKey: supabaseKey);
  runApp(const SaambaApp());
}

class SaambaApp extends StatelessWidget {
  const SaambaApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'MAYA',
        debugShowCheckedModeBanner: false,
        theme: saambaTheme(),
        home: const Gate(),
      );
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  Future<Map<String, dynamic>?>? _profile;
  StreamSubscription<AuthState>? _sub;
  bool _splash = true;

  @override
  void initState() {
    super.initState();
    _load();
    _sub = sb.auth.onAuthStateChange.listen((_) => _refresh());
    roleRefresh.addListener(_refresh);
    Future.delayed(const Duration(milliseconds: 1600), () {
      if (mounted) setState(() => _splash = false);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    roleRefresh.removeListener(_refresh);
    super.dispose();
  }

  void _refresh() {
    if (mounted) setState(_load);
  }

  void _load() {
    _profile = sb.auth.currentUser == null
        ? Future<Map<String, dynamic>?>.value(null)
        : sb.from('profiles').select().eq('id', uid).maybeSingle();
  }

  @override
  Widget build(BuildContext context) {
    if (_splash) return const SplashView();
    // Visiteur : la marketplace est librement consultable ; le compte n'est demandé que pour agir.
    if (sb.auth.currentUser == null) return const ClientShell(guest: true);
    return FutureBuilder<Map<String, dynamic>?>(
      future: _profile,
      builder: (context, snap) {
        if (snap.connectionState != ConnectionState.done) return const SplashView();
        final p = snap.data;
        if (p == null || p['active'] != true) {
          return Scaffold(
            body: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  const SaambaLogo(size: 120),
                  const SizedBox(height: 16),
                  const Text('Compte indisponible ou désactivé.', textAlign: TextAlign.center),
                  TextButton(onPressed: () => sb.auth.signOut(), child: const Text('Se déconnecter')),
                ]),
              ),
            ),
          );
        }
        switch (p['role']) {
          case 'admin':
            return const AdminShell();
          case 'supplier':
            return const SupplierShell();
          case 'seller':
            return const SellerShell();
          default:
            return const ClientShell();
        }
      },
    );
  }
}

class ClientShell extends StatefulWidget {
  /// Visiteur non connecté : consultation libre, actions réservées aux membres bloquées par une fenêtre « compte requis ».
  final bool guest;
  const ClientShell({super.key, this.guest = false});
  @override
  State<ClientShell> createState() => _ClientShellState();
}

class _ClientShellState extends State<ClientShell> {
  int _i = 0;

  static const _gatedTabs = <int, String>{
    2: 'Connectez-vous ou créez un compte pour enregistrer vos produits favoris.',
    3: 'Connectez-vous ou créez un compte pour passer commande et suivre vos commandes.',
  };

  Future<void> _go(int v) async {
    if (widget.guest && _gatedTabs.containsKey(v)) {
      await requireAuth(context, reason: _gatedTabs[v]!);
      return;
    }
    if (mounted) setState(() => _i = v);
  }

  Future<void> _chat() async {
    if (widget.guest) {
      await requireAuth(context, reason: 'Connectez-vous ou créez un compte pour écrire à MAYA ou à un vendeur.');
      return;
    }
    if (!mounted) return;
    Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Messages avec MAYA')), body: const _ClientChat())));
  }

  void _invoices() => Navigator.push(
      context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Mes factures')), body: const InvoicesScreen())));

  void _openAuth(bool register) =>
      Navigator.push<bool>(context, MaterialPageRoute(builder: (_) => AuthScreen(initialRegister: register)));

  static const _dest = <(IconData, IconData, String)>[
    (Icons.home_outlined, Icons.home, 'Accueil'),
    (Icons.grid_view_outlined, Icons.grid_view, 'Catégories'),
    (Icons.favorite_border, Icons.favorite, 'Favoris'),
    (Icons.assignment_outlined, Icons.assignment, 'Commandes'),
    (Icons.person_outline, Icons.person, 'Mon compte'),
  ];

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      if (widget.guest) LandingScreen(onGo: _go, onContact: _chat) else ShopHome(onGo: _go, onContact: _chat),
      const CategoriesScreen(),
      if (widget.guest) const SizedBox.shrink() else const FavoritesScreen(),
      if (widget.guest) const SizedBox.shrink() else const OrdersScreen(admin: false),
      if (widget.guest) const GuestAccount() else AccountHub(onMessages: _chat, onInvoices: _invoices, profile: const ProfileScreen()),
    ];
    final width = MediaQuery.of(context).size.width;
    final wide = width >= 900;
    final compact = width < 480;
    final landing = widget.guest && _i == 0; // la page d'accueil visiteur a son propre en-tête, pleine largeur
    final body = landing ? pages[_i] : Align(alignment: Alignment.topCenter, child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 1100), child: pages[_i]));
    return Scaffold(
      appBar: landing ? null : AppBar(
        title: const SaambaTitle(),
        bottom: const MaliStripe(),
        actions: widget.guest
            ? [
                if (compact) ...[
                  IconButton(tooltip: 'Se connecter', icon: const Icon(Icons.login), onPressed: () => _openAuth(false)),
                  IconButton(tooltip: 'Devenir vendeur', icon: const Icon(Icons.storefront, color: gold), onPressed: () => startSellerFlow(context)),
                ] else ...[
                  TextButton(onPressed: () => _openAuth(false), child: const Text('Se connecter', style: TextStyle(color: Colors.white))),
                  TextButton(onPressed: () => _openAuth(true), child: const Text('Créer un compte', style: TextStyle(color: Colors.white))),
                  Padding(
                    padding: const EdgeInsets.only(right: 8, left: 4),
                    child: FilledButton(
                      style: FilledButton.styleFrom(backgroundColor: gold, foregroundColor: Colors.white, minimumSize: const Size(0, 38), padding: const EdgeInsets.symmetric(horizontal: 14)),
                      onPressed: () => startSellerFlow(context),
                      child: const Text('Devenir vendeur'),
                    ),
                  ),
                ],
              ]
            : const [NotifBell()],
      ),
      body: wide && !landing
          ? Row(children: [
              NavigationRail(
                selectedIndex: _i,
                onDestinationSelected: _go,
                labelType: NavigationRailLabelType.all,
                backgroundColor: Colors.white,
                indicatorColor: const Color(0x33FF7A00),
                destinations: [for (final d in _dest) NavigationRailDestination(icon: Icon(d.$1), selectedIcon: Icon(d.$2), label: Text(d.$3))],
              ),
              const VerticalDivider(width: 1),
              Expanded(child: body),
            ])
          : body,
      bottomNavigationBar: wide
          ? null
          : NavigationBar(
              selectedIndex: _i,
              onDestinationSelected: _go,
              destinations: [for (final d in _dest) NavigationDestination(icon: Icon(d.$1), selectedIcon: Icon(d.$2), label: d.$3)],
            ),
    );
  }
}

class _ClientChat extends StatelessWidget {
  const _ClientChat();
  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>>(
        future: sb.from('conversations').select('id').eq('client_id', uid).single(),
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          return ChatScreen(conversationId: snap.data!['id'] as String, title: 'MAYA', embedded: true);
        },
      );
}
