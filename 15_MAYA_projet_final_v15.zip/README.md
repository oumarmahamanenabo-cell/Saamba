# MAYA – application Android (Flutter + Supabase)

Achetez • Vendez • Livrez. Trois espaces : client, administration, grossiste.

## Obtenir l'APK avec GitHub (sans ordinateur)
1. Créez un dépôt GitHub et envoyez-y **le contenu de ce zip à la racine** (pubspec.yaml doit être à la racine).
2. Onglet **Actions** → « Build APK MAYA » → **Run workflow** (il se lance aussi à chaque push sur `main`).
3. À la fin (≈ 8 à 12 min), ouvrez l'exécution → **Artifacts → MAYA-apk** → téléchargez `MAYA.apk` et installez-le.

Le workflow génère lui-même le dossier `android/`, ajoute les permissions (micro, caméra, internet, appels), le nom « MAYA », l'icône du logo, puis compile.

## Backend Supabase (déjà configuré)
Le projet Supabase utilisé est celui de `lib/config.dart` (référence `juaidyvcngqizxvnsxke`, projet nommé « SAAMBA » dans Supabase : renommez-le « MAYA » dans Project Settings > General).
Tables, règles RLS, fonctions, stockage et notifications internes sont en place.

À faire une seule fois dans le tableau de bord Supabase :
- Authentication > Providers > Email : désactiver « Confirm email » (inscription par e-mail ; les anciens comptes créés avec un numéro restent connectables en saisissant leur numéro à la place de l'e-mail).
- Premier administrateur : créez son compte dans l'app, puis dans le SQL Editor :
  `update public.profiles set role = 'admin' where id = (select id from auth.users where email = '223XXXXXXXX@saamba.app');`
  (remplacez par le numéro saisi à l'inscription, chiffres seulement).

## Contenu de l'application
- Client : accueil, messagerie (texte, vocal, photo, vidéo, document), commandes, factures PDF, paiements, livraisons, appel transporteur Orange/Malitel, confirmation de réception / colis non reçu, notifications.
- Administration : tableau de bord, conversations, commandes (lignes, frais, réduction), factures, liens de paiement, expéditions, signalements, grossistes (fiches, invitations, demandes avec pièces jointes, saisie manuelle des réponses, comparaison des prix avec anciens prix, archives, notes privées, marges).
- Grossiste invité : demandes reçues, réponses avec prix, disponibilités et pièces jointes, historique de ses propres échanges.

## Non inclus (à configurer plus tard)
- Prestataire de paiement : son webhook doit appeler `public.confirm_payment(ref, montant, id_evenement, payload)` avec la clé service_role.
- Notifications push FCM (google-services.json + Edge Function) : les notifications sont déjà créées dans la table `notifications` et affichées dans l'app.
- Sélection forcée de la SIM : Android ne l'autorise pas pour une app ; l'app ouvre le composeur avec une explication.

## Note technique
L'identifiant interne `@saamba.app` (adresse technique des comptes) et le nom de paquet `com.saamba` sont conservés volontairement : les renommer casserait les comptes existants.

## Vérification des partenaires (nouveau)
1. Exécutez `supabase/migrations/20261115_partner_verification.sql` dans le SQL Editor de Supabase (additif, idempotent).
2. Dans l'app admin : onglet Grossistes > Vérification. Traitez les grossistes existants (ils sont « EN ATTENTE » par défaut), ajoutez les transporteurs et leurs justificatifs (bucket privé `partner-docs`).
3. Une fois les grossistes actifs approuvés, activez l'obligation : `update public.partner_settings set value='true' where key='enforce_verification';`
4. La règle « aucun transporteur non vérifié ne reçoit de mission » est active dès la migration (colonne `delivery_details.carrier_id`).

## Accueil client (maquette) et portefeuille vendeur (nouveau)
- Accueil client refait d'après la maquette (bannière, accès rapides, catégories, meilleures offres) ; navigation : Accueil, Catégories, Favoris, Commandes, Mon compte.
- Rôle `seller` : l'admin nomme un vendeur (icône portefeuille > Vendeurs) puis rattache chaque produit d'une commande à son vendeur (icône boutique sur la ligne produit).
- Séquestre : à la confirmation du paiement, les gains sont crédités « bloqués ». Ils deviennent retirables uniquement quand LE CLIENT appuie sur « COLIS REÇU » (un changement de statut par l'admin ne libère rien). Retrait via Orange Money / Moov Money / Wave, payé manuellement par l'admin (Retraits).
- Litige : « COLIS NON REÇU » ou « incomplet / endommagé » ouvre un signalement chez l'admin et garde les fonds bloqués ; l'admin peut annuler les fonds du vendeur si le client a raison.
- Le client est averti à l'expédition (notification) et avant de confirmer (message + boîte de confirmation).
- Commission vendeur : `update public.partner_settings set value='5' where key='seller_commission_pct';` (en %, 0 par défaut).
- Migrations déjà appliquées sur le projet Supabase : `supabase/migrations/*.sql`.

## Produits des vendeurs (nouveau)
- Le vendeur publie lui-même ses produits (photo, prix, promo, stock, unité) dans l'onglet « Produits ». Toute création ou modification passe « EN ATTENTE » : l'admin valide dans Vendeurs et retraits > Produits.
- Vendeur de confiance : interrupteur « Publication automatique » dans Vendeurs et retraits > Vendeurs. Le serveur empêche un vendeur de s'approuver lui-même.
- Photos : bucket public `product-images` (écriture réservée au dossier du vendeur).

## Inscription par e-mail (nouveau)
- Inscription : nom complet, ville, numéro de téléphone malien (+223 + 8 chiffres) et adresse e-mail, tous obligatoires, plus mot de passe (6 caractères minimum).
- Exécutez `supabase/migrations/20261115e_profile_city.sql` dans le SQL Editor pour enregistrer la ville dans `profiles.city`.
- Pas de confirmation par e-mail (« Confirm email » désactivé dans Supabase).

## Expédition renseignée par le vendeur (nouveau)
- Exécutez `supabase/migrations/20261115f_seller_shipping.sql` dans le SQL Editor (après la migration 20261115e).
- Espace vendeur > onglet « Commandes » : pour chaque commande payée contenant ses produits, le vendeur renseigne le transporteur (vérifié, ou saisie manuelle signalée « non vérifié »), le téléphone du transporteur, son propre contact malien, le lieu et la date d'arrivée du colis.
- Le client voit ces informations dans sa commande (avec les boutons d'appel Orange / Malitel) ; l'administration aussi et reçoit une notification. Le statut de la commande reste changé par l'administration.

## MAYA Seller Hunter — prospection de vendeurs (nouveau, réservé à l'administration)
- Exécutez `supabase/migrations/20261115g_seller_hunter.sql` dans le SQL Editor (additif, idempotent). Il crée les tables `seller_prospects`, `seller_prospect_sources`, `seller_campaigns`, `seller_invitations`, `seller_invitation_events`, `seller_consents`, `seller_unsubscribes`, `seller_search_jobs`, `seller_search_results`, `seller_hunter_logs`, plus `seller_categories` et `seller_message_templates` (messages en français, anglais, portugais, arabe).
- Accès : icône « loupe » dans la barre de l'espace administrateur. Sécurité réelle côté serveur : RLS `public.is_admin()` sur toutes les tables, aucun accès pour les autres rôles.
- Onglets : Vue générale, Recherche (ajout manuel et import CSV), Prospects (filtres, sélection 50/100/500/tous, fiche, statuts), Campagnes, Invitations (ouverture WhatsApp/e-mail préremplie, copie du lien, suivi), Recrutés, Statistiques, Paramètres (catégories, modèles, désinscriptions).
- Aucun envoi automatique : l'administrateur prépare, confirme, puis envoie lui-même chaque message. Les prospects désinscrits sont écartés (aussi côté serveur).
- Pas encore inclus : découverte automatique (Google Places, recherches programmées : fonction serveur + clé API), page web publique `join-seller/<jeton>` et rattachement automatique du formulaire vendeur, export Excel/CSV, carte de l'Afrique.


## Boutiques, médias, partage (nouveau — 16/11/2026)
- Migration `supabase/migrations/20261116_shops_media_public_security.sql` : déjà appliquée sur le projet Supabase (tables `shops`, `product_media`, buckets `shop-assets` et `product-videos`, fonctions publiques `public_product` / `public_shop`, durcissement des fonctions).
- Vendeur : onglet **Boutique** (nom, logo, bannière, description, coordonnées, « voir comme un client », copier/partager le lien). Formulaire produit : jusqu'à 10 photos (sélection multiple, réduction automatique), 2 vidéos (30 Mo, 45 s max), ordre, photo principale. Menu produit : copier/partager le lien, rupture de stock.
- Client : toucher un produit ouvre la fiche (galerie, lecteur vidéo, contacter le vendeur, commander, partager) ; la boutique est consultable depuis la fiche.
- Tout changement d'un produit par un vendeur non « de confiance » le remet « EN ATTENTE » (règle existante du serveur).
- Liens de partage : `shareBaseUrl` dans `lib/config.dart` (par défaut `https://maya.app`). Hébergez le dossier `public_page/` (index.html + 404.html, ex. GitHub Pages ou Netlify) sur ce domaine : `/product/<id>` et `/boutique/<slug>` (ancien format `/shop/<slug>` toujours accepté) s'affichent sans compte. Limite : l'aperçu enrichi (photo/prix) dans WhatsApp/Facebook demande un rendu côté serveur, non fourni ici.
- Non fait : ouverture directe des liens dans l'application installée (liens profonds Android).


## Personnalisation des boutiques (nouveau — 17/11/2026)
- **Exécutez `supabase/migrations/20261117_shop_customization.sql`** dans le SQL Editor (additif, idempotent, après 20261116). Il ajoute à `shops` : `design_draft` (brouillon), `design` (publié), `published_at`, `moderation_note`, `moderated_at`, la table `shop_moderation_log`, la validation serveur du design, la fonction `publish_shop_design()` et `admin_moderate_shop()`, et met à jour `public_shop()` (mêmes champs + design publié).
- Vendeur : onglet **Boutique > Personnaliser le design de ma boutique**. Trois onglets : Modèle (6 modèles : Classique, Mode, Alimentation, Électronique, Cosmétiques, Grossiste), Identité (couleurs, police, style, slogan, accès logo/bannière/coordonnées), Organisation (disposition grille/compacte/liste/grande vitrine, ordre et affichage des sections Vedettes/Promotions/Nouveautés/Catalogue, produits en vedette, catégories personnalisées). Aperçu en direct, **Enregistrer** (brouillon), **Prévisualiser**, **Publier**.
- Les visiteurs ne voient que la version publiée. Logo, bannière, description et coordonnées restent enregistrés immédiatement (comportement existant).
- Sécurité : un vendeur ne peut écrire que le brouillon de SA boutique (RLS existante + trigger `shops_design_guard`) ; seule `publish_shop_design()` copie le brouillon vers la version publiée ; le contenu du design est validé côté serveur (couleurs hexadécimales, polices/dispositions autorisées, limites de taille).
- Administration : **Vendeurs et retraits > Boutiques** : liste, recherche, aperçu de la version publiée ou du brouillon, suspension/réactivation avec motif, réinitialisation du design, historique (`shop_moderation_log`).
- Lien public : `<shareBaseUrl>/boutique/<slug>` (le slug est généré automatiquement, ex. `ma-boutique-a1b2c`).


## Accès public et comptes obligatoires (nouveau — 18/11/2026)
- **Migration `supabase/migrations/20261118_public_access_accounts.sql` : déjà appliquée sur le projet Supabase** (idempotente, à rejouer telle quelle si besoin).
- **Visiteur (sans compte)** : l'application s'ouvre directement sur la marketplace. Il consulte librement l'accueil, les catégories, toutes les boutiques actives (annuaire « Nos boutiques »), leurs profils publics, tous les produits validés (photos, vidéos, prix, promotions), les offres, les nouveautés et la page « À propos de MAYA ». Aucune inscription n'est demandée pour découvrir.
- **Compte requis** pour : commander, ajouter aux favoris, contacter un vendeur ou écrire à MAYA (texte, photo, vidéo, vocal), panier / commandes / historique, notifications. Un visiteur qui touche l'une de ces actions voit une fenêtre « Rejoignez MAYA » : **Se connecter** / **Créer un compte** / Plus tard. Boutons « Se connecter », « Créer un compte » et **« Devenir vendeur »** visibles en haut de l'accueil (versions icônes sur petit écran) et sur l'accueil (bandeau orange).
- **Devenir vendeur** (compte obligatoire) : compte → écran « Devenir vendeur » (nom de boutique, activité, catégorie, ville, téléphone, WhatsApp, adresse) → documents de vérification (pièce d'identité obligatoire, justificatif d'activité facultatif, bucket privé `seller-docs`) → demande en attente. L'administrateur la traite dans **Vendeurs et retraits > Demandes** (ouvrir les documents, Valider ou Refuser avec motif). À la validation : le compte passe vendeur et la boutique est créée ; le demandeur est notifié. Tant que ce n'est pas validé, il ne peut rien publier.
- **Séparation des rôles, appliquée côté serveur (RLS)** :
  - *Visiteur (rôle `anon`)* : lecture seule de `categories`, `products` (validés, hors boutiques suspendues), `product_media`, et des colonnes publiques de `shops` (pas d'e-mail, téléphone, brouillon ni notes de modération). Tous les autres droits `anon` ont été retirés de toutes les tables. Les fonctions de conversation, commande, favoris, demande vendeur refusent tout appel sans connexion.
  - *Client connecté* : achats, messages, favoris, commandes. *Vendeur validé* (`role = seller`, actif, boutique non suspendue) : seul à pouvoir créer/modifier des produits (et toujours soumis à validation). *Administrateur* : supervision complète.
- **Coordonnées directes** : `public_shop()` ne renvoie téléphone et WhatsApp qu'aux comptes connectés (contacter un vendeur passe par un compte). La page web publique `public_page/` n'affiche donc plus ces boutons aux visiteurs anonymes.
- **Écrans** : navigation en barre de navigation (téléphone) ou rail latéral (écran ≥ 900 px), contenu centré (1100 px max), grilles adaptatives.
- Tests réalisés sur la base : visiteur = lecture publique seulement (15 tables sensibles refusées, favoris/demande/conversation refusés) ; client = ne peut ni publier ni changer son rôle ; demande vendeur → validation admin → rôle vendeur + boutique créée (transaction annulée après test).


## MAYA DELIVERY CONNECT — livraison intelligente (nouveau — 19/11/2026)
- **Migrations** (déjà appliquées sur le projet Supabase) : `delivery_connect_tables`, `delivery_connect_core`, `delivery_connect_tracking` (présentes uniquement dans la base : leurs fichiers SQL ne sont pas dans ce zip), puis `20261119_delivery_client_confirmation_sync.sql` (la confirmation « COLIS REÇU / NON REÇU » du client met désormais à jour la mission) et `20261119b_courier_photos.sql` (bucket privé `courier-photos`).
- **Vendeur** : Commandes > « LIVRAISON MAYA » → deux onglets : *Transporteur MAYA* (recherche par zone, choix manuel ou proposition automatique, refus/absence de réponse = proposition automatique d'un autre transporteur) et *Mon livreur* (formulaire, carnet de livreurs, invitation code + PIN à envoyer par SMS/WhatsApp depuis son téléphone). Icônes de la barre : « Mes livraisons » et « Mes livreurs » (carnet, historique).
- **Transporteur** : Compte > Espace transporteur MAYA (inscription, vérification par l'admin, disponibilité, demandes à accepter/refuser, missions). **Livreur invité** : Compte > Rejoindre une livraison (code + PIN, compte requis) ; il n'accède qu'à sa mission.
- **Client** : Commande > « SUIVRE MON COLIS » : carte, statut, heure estimée, dernière mise à jour GPS, contact du livreur, partage de sa position ou adresse, COLIS REÇU / NON REÇU.
- **Conversation à trois** (vendeur, client, livreur) créée à l'acceptation, via la messagerie existante (texte, vocal, photo, vidéo, documents).
- **Admin** : icône camion > toutes les livraisons (type distingué : transporteur partenaire / livreur personnel), incidents, litiges, suspension de livreurs.
- **GPS** : lecture avec accord explicite, uniquement pendant la mission, arrêt automatique à la fin ou à l'annulation. Le suivi fonctionne **tant que MAYA reste ouverte à l'écran** (pas de suivi en arrière-plan).
- **Carte** : OpenStreetMap via `flutter_map` (gratuit, sans clé ; pour un usage intensif, prévoir un fournisseur de tuiles payant : MapTiler, Stadia, Mapbox…). Aucun tracé de route n'est affiché : MAYA ne dispose pas de service d'itinéraire.
- **Notifications** : dans l'application (table `notifications`). SMS et notifications push : non configurés (voir « Non inclus »).
- Le retard et l'expiration des demandes sont traités à l'ouverture des écrans de suivi (pas de tâche planifiée) ; pour un traitement permanent, activer `pg_cron` et planifier `_dm_process_expired()` et `_dm_check_delays()`.

## Page d'accueil MAYA (maquette violet/jaune)

`lib/landing.dart` reproduit la maquette pour les **visiteurs non connectés** (onglet Accueil) : en-tête avec recherche, héros, « Comment acheter sur MAYA ? » (8 étapes cliquables), engagements et garanties, Pourquoi MAYA / Pour les vendeurs, FAQ, contact, pied de page. Responsive : mobile (< 640 px), tablette, ordinateur (≥ 1000 px).
Les utilisateurs connectés gardent l'accueil existant (boutiques, produits, comptes inchangés). « Explorer » ouvre l'accueil existant.

À renseigner dans `lib/config.dart` (vides = message « bientôt disponible », aucun faux lien) : `supportWhatsapp`, `supportPhone`, `supportEmail`, `socialFacebook`, `socialYoutube`, `socialTiktok`.

Notes :
- Les photos (`assets/landing/*.png`) sont des découpes basse résolution de la maquette : à remplacer par les originaux (mêmes noms).
- Le logo est un wordmark Flutter (panier jaune + MAYA) ; fournir les fichiers du logo violet pour les logos d'application.
- L'étape 4 de la maquette (« Ajoutez au panier ») est reformulée selon le fonctionnement réel (messagerie + proposition de commande), car l'application n'a pas de panier.
- Conditions d'utilisation / Confidentialité : textes génériques à faire valider juridiquement.
- Code non compilé ici (pas de SDK Flutter) : lancer `flutter analyze` avant publication.
