-- MAYA : boutiques, médias produits, pages publiques, sécurité (déjà appliquée sur le projet SAAMBA/MAYA le 16/11/2026).
-- Additif. Ne modifie aucune donnée existante. Regroupe les migrations maya_shops_media_public_security et maya_shops_fixups.

create table if not exists public.shops (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references public.profiles(id) on delete cascade,
  slug text not null unique,
  name text not null check (char_length(btrim(name)) between 2 and 80),
  description text, logo_path text, banner_path text,
  phone text, whatsapp text, email text, address text, city text,
  status text not null default 'active' check (status in ('active','suspended')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create or replace function public.shops_before_write() returns trigger
language plpgsql security definer set search_path = '' as $$
declare base text;
begin
  if tg_op = 'INSERT' then
    if not public.is_admin() then new.status := 'active'; end if;
    if new.slug is null or new.slug = '' then
      base := regexp_replace(translate(lower(new.name), 'àâäéèêëîïôöùûüçÀÂÄÉÈÊËÎÏÔÖÙÛÜÇ', 'aaaeeeeiioouuucaaaeeeeiioouuuc'), '[^a-zA-Z0-9]+', '-', 'g');
      base := btrim(lower(base), '-');
      if base = '' then base := 'boutique'; end if;
      new.slug := left(base, 40) || '-' || substr(md5(random()::text || clock_timestamp()::text), 1, 5);
    end if;
  else
    if not public.is_admin() then new.owner_id := old.owner_id; new.slug := old.slug; new.status := old.status; end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
revoke all on function public.shops_before_write() from public, anon, authenticated;
drop trigger if exists shops_before_write_trg on public.shops;
create trigger shops_before_write_trg before insert or update on public.shops for each row execute function public.shops_before_write();
alter table public.shops enable row level security;
revoke all on public.shops from anon;
grant select, insert, update, delete on public.shops to authenticated;
drop policy if exists shops_owner_select on public.shops; drop policy if exists shops_owner_insert on public.shops;
drop policy if exists shops_owner_update on public.shops; drop policy if exists shops_admin_all on public.shops;
create policy shops_owner_select on public.shops for select to authenticated using (owner_id = auth.uid() or status = 'active');
create policy shops_owner_insert on public.shops for insert to authenticated with check (owner_id = auth.uid() and public.is_seller());
create policy shops_owner_update on public.shops for update to authenticated using (owner_id = auth.uid() and public.is_seller()) with check (owner_id = auth.uid());
create policy shops_admin_all on public.shops for all to authenticated using (public.is_admin()) with check (public.is_admin());

alter table public.products add column if not exists shop_id uuid references public.shops(id) on delete set null;
create index if not exists products_shop_idx on public.products(shop_id);
create or replace function public.products_set_shop() returns trigger
language plpgsql security definer set search_path = '' as $$
begin select s.id into new.shop_id from public.shops s where s.owner_id = new.created_by; return new; end $$;
revoke all on function public.products_set_shop() from public, anon, authenticated;
drop trigger if exists products_shop_trg on public.products;
create trigger products_shop_trg before insert or update of created_by on public.products for each row execute function public.products_set_shop();

create table if not exists public.product_media (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  owner_id uuid not null references public.profiles(id) on delete cascade,
  kind text not null check (kind in ('image','video')),
  path text not null,
  position int not null default 0,
  is_primary boolean not null default false,
  size_bytes bigint,
  created_at timestamptz not null default now(),
  check (position(owner_id::text || '/' in path) = 1)
);
create index if not exists product_media_product_idx on public.product_media(product_id, position);
create or replace function public.product_media_limits() returns trigger
language plpgsql security definer set search_path = '' as $$
declare n int;
begin
  select count(*) into n from public.product_media where product_id = new.product_id and kind = new.kind;
  if new.kind = 'image' and n >= 10 then raise exception 'Maximum 10 photos par produit'; end if;
  if new.kind = 'video' and n >= 2 then raise exception 'Maximum 2 vidéos par produit'; end if;
  return new;
end $$;
revoke all on function public.product_media_limits() from public, anon, authenticated;
drop trigger if exists product_media_limits_trg on public.product_media;
create trigger product_media_limits_trg before insert on public.product_media for each row execute function public.product_media_limits();
create or replace function public.product_media_sync() returns trigger
language plpgsql security definer set search_path = '' as $$
declare pid uuid := coalesce(new.product_id, old.product_id); imgs text[];
begin
  select coalesce(array_agg(path order by is_primary desc, position, created_at), '{}') into imgs from public.product_media where product_id = pid and kind = 'image';
  update public.products set images = imgs, image_path = imgs[1] where id = pid;
  return null;
end $$;
revoke all on function public.product_media_sync() from public, anon, authenticated;
drop trigger if exists product_media_sync_trg on public.product_media;
create trigger product_media_sync_trg after insert or update or delete on public.product_media for each row execute function public.product_media_sync();
alter table public.product_media enable row level security;
revoke all on public.product_media from anon;
grant select, insert, update, delete on public.product_media to authenticated;
drop policy if exists pm_select on public.product_media; drop policy if exists pm_seller_write on public.product_media; drop policy if exists pm_admin_all on public.product_media;
create policy pm_select on public.product_media for select to authenticated using (exists (select 1 from public.products p where p.id = product_media.product_id));
create policy pm_seller_write on public.product_media for all to authenticated
  using (owner_id = auth.uid() and public.is_seller())
  with check (owner_id = auth.uid() and public.is_seller() and exists (select 1 from public.products p where p.id = product_media.product_id and p.created_by = auth.uid()));
create policy pm_admin_all on public.product_media for all to authenticated using (public.is_admin()) with check (public.is_admin());
create or replace function public.reorder_product_media(p_product uuid, p_ids uuid[]) returns void
language plpgsql security invoker set search_path = '' as $$
begin update public.product_media m set position = x.ord from unnest(p_ids) with ordinality as x(id, ord) where m.id = x.id and m.product_id = p_product; end $$;
create or replace function public.set_primary_media(p_media uuid) returns void
language plpgsql security invoker set search_path = '' as $$
declare pid uuid;
begin
  select product_id into pid from public.product_media where id = p_media and kind = 'image';
  if pid is null then raise exception 'Image introuvable'; end if;
  update public.product_media set is_primary = (id = p_media) where product_id = pid and kind = 'image';
end $$;
revoke all on function public.reorder_product_media(uuid, uuid[]) from public, anon;
revoke all on function public.set_primary_media(uuid) from public, anon;
grant execute on function public.reorder_product_media(uuid, uuid[]) to authenticated;
grant execute on function public.set_primary_media(uuid) to authenticated;

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types) values
 ('shop-assets', 'shop-assets', true, 5242880, array['image/jpeg','image/png','image/webp']),
 ('product-videos', 'product-videos', true, 31457280, array['video/mp4','video/webm','video/quicktime'])
on conflict (id) do nothing;
do $$
declare b text;
begin
  foreach b in array array['shop-assets','product-videos'] loop
    execute format('drop policy if exists %I on storage.objects', b || '_seller_insert');
    execute format('drop policy if exists %I on storage.objects', b || '_seller_update');
    execute format('drop policy if exists %I on storage.objects', b || '_seller_delete');
    execute format('drop policy if exists %I on storage.objects', b || '_admin_all');
    execute format('create policy %I on storage.objects for insert to authenticated with check (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text and public.is_seller())', b || '_seller_insert', b);
    execute format('create policy %I on storage.objects for update to authenticated using (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text and public.is_seller())', b || '_seller_update', b);
    execute format('create policy %I on storage.objects for delete to authenticated using (bucket_id = %L and (storage.foldername(name))[1] = auth.uid()::text and public.is_seller())', b || '_seller_delete', b);
    execute format('create policy %I on storage.objects for all to authenticated using (bucket_id = %L and public.is_admin()) with check (bucket_id = %L and public.is_admin())', b || '_admin_all', b, b);
  end loop;
end $$;

create or replace function public.public_product(p_id uuid) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'product', to_jsonb(p) - 'created_by' - 'shop_id',
    'media', coalesce((select jsonb_agg(jsonb_build_object('id', m.id, 'kind', m.kind, 'path', m.path, 'is_primary', m.is_primary) order by m.is_primary desc, m.position, m.created_at) from public.product_media m where m.product_id = p.id), '[]'::jsonb),
    'shop', (select jsonb_build_object('slug', s.slug, 'name', s.name, 'logo_path', s.logo_path, 'city', s.city) from public.shops s where s.owner_id = p.created_by and s.status = 'active'))
  from public.products p
  where p.id = p_id and p.status = 'approved' and not exists (select 1 from public.shops s where s.owner_id = p.created_by and s.status = 'suspended');
$$;
create or replace function public.public_shop(p_slug text) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'shop', jsonb_build_object('id', s.id, 'slug', s.slug, 'name', s.name, 'description', s.description, 'logo_path', s.logo_path, 'banner_path', s.banner_path, 'city', s.city, 'phone', s.phone, 'whatsapp', s.whatsapp, 'address', s.address, 'owner_id', s.owner_id),
    'products', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.name, 'price', p.price, 'promo_price', p.promo_price, 'unit', p.unit, 'image_path', p.image_path) order by p.created_at desc)
                            from (select * from public.products where created_by = s.owner_id and status = 'approved' order by created_at desc limit 100) p), '[]'::jsonb))
  from public.shops s where s.slug = p_slug and s.status = 'active';
$$;
revoke all on function public.public_product(uuid) from public;
revoke all on function public.public_shop(text) from public;
grant execute on function public.public_product(uuid) to anon, authenticated;
grant execute on function public.public_shop(text) to anon, authenticated;

revoke all on function public.copy_signup_city() from public, anon, authenticated;
revoke all on function public.trg_check_carrier_verified() from public, anon, authenticated;
revoke all on function public.trg_check_supplier_verified() from public, anon, authenticated;
revoke all on function public.trg_product_status_guard() from public, anon, authenticated;
revoke all on function public.trg_seller_ledger() from public, anon, authenticated;
revoke all on function public.trg_warn_client_reception() from public, anon, authenticated;
drop policy if exists mda_admin_select on public.message_deleted_archive;
create policy mda_admin_select on public.message_deleted_archive for select to authenticated using (public.is_admin());
