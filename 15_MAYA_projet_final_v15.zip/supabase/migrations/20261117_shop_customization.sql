-- MAYA : personnalisation avancée des boutiques (design, catégories, vedettes, sections, modération).
-- 100 % additif et idempotent : ne supprime ni ne modifie aucune donnée existante.
-- À exécuter dans Supabase > SQL Editor (après 20261116_shops_media_public_security.sql).
--
-- Principe : tout le design vit dans deux colonnes JSON de public.shops
--   design_draft : brouillon modifié par le vendeur (bouton « Enregistrer »)
--   design       : version publiée, seule visible des visiteurs (bouton « Publier »)
-- Les catégories personnalisées, produits en vedette, ordre des sections, couleurs, police,
-- disposition et modèle sont dans ce JSON : tout se publie d'un seul bloc, sans toucher à `products`
-- (donc sans remettre un produit « EN ATTENTE »).

alter table public.shops add column if not exists design jsonb;
alter table public.shops add column if not exists design_draft jsonb;
alter table public.shops add column if not exists published_at timestamptz;
alter table public.shops add column if not exists moderation_note text;
alter table public.shops add column if not exists moderated_at timestamptz;

-- ---------- Validation du design (côté serveur, quoi que fasse le client) ----------
create or replace function public.shop_design_check(d jsonb) returns void
language plpgsql immutable set search_path = '' as $$
declare k text; v jsonb; c jsonb; hex text := '^#[0-9A-Fa-f]{6}$';
begin
  if d is null then return; end if;
  if jsonb_typeof(d) <> 'object' then raise exception 'Design invalide'; end if;
  if octet_length(d::text) > 60000 then raise exception 'Design trop volumineux'; end if;
  for k in select jsonb_object_keys(d) loop
    if k not in ('template','primary','secondary','font','layout','radius','sections','categories','featured','tagline') then
      raise exception 'Champ de design inconnu : %', k;
    end if;
  end loop;
  if d ? 'template'  and (jsonb_typeof(d->'template')  <> 'string' or d->>'template'  not in ('classic','fashion','food','electronics','beauty','wholesale')) then raise exception 'Modèle inconnu'; end if;
  if d ? 'font'      and (jsonb_typeof(d->'font')      <> 'string' or d->>'font'      not in ('modern','elegant','technical','condensed')) then raise exception 'Police inconnue'; end if;
  if d ? 'layout'    and (jsonb_typeof(d->'layout')    <> 'string' or d->>'layout'    not in ('grid2','grid3','list','large')) then raise exception 'Disposition inconnue'; end if;
  if d ? 'radius'    and (jsonb_typeof(d->'radius')    <> 'string' or d->>'radius'    not in ('sharp','soft','round')) then raise exception 'Style inconnu'; end if;
  if d ? 'primary'   and (jsonb_typeof(d->'primary')   <> 'string' or d->>'primary'   !~ hex) then raise exception 'Couleur principale invalide'; end if;
  if d ? 'secondary' and (jsonb_typeof(d->'secondary') <> 'string' or d->>'secondary' !~ hex) then raise exception 'Couleur secondaire invalide'; end if;
  if d ? 'tagline'   and (jsonb_typeof(d->'tagline')   <> 'string' or char_length(d->>'tagline') > 120) then raise exception 'Slogan trop long (120 caractères max)'; end if;
  if d ? 'sections' then
    if jsonb_typeof(d->'sections') <> 'array' or jsonb_array_length(d->'sections') > 8 then raise exception 'Sections invalides'; end if;
    for v in select * from jsonb_array_elements(d->'sections') loop
      if jsonb_typeof(v) <> 'object' or coalesce(v->>'id','') not in ('featured','promos','new','catalog') or coalesce(jsonb_typeof(v->'on'),'') <> 'boolean' then raise exception 'Section invalide'; end if;
    end loop;
  end if;
  if d ? 'featured' then
    if jsonb_typeof(d->'featured') <> 'array' or jsonb_array_length(d->'featured') > 12 then raise exception 'Maximum 12 produits en vedette'; end if;
    for v in select * from jsonb_array_elements(d->'featured') loop
      if jsonb_typeof(v) <> 'string' or (v #>> '{}') !~ '^[0-9a-fA-F-]{36}$' then raise exception 'Produit en vedette invalide'; end if;
    end loop;
  end if;
  if d ? 'categories' then
    if jsonb_typeof(d->'categories') <> 'array' or jsonb_array_length(d->'categories') > 20 then raise exception 'Maximum 20 catégories'; end if;
    for c in select * from jsonb_array_elements(d->'categories') loop
      if jsonb_typeof(c) <> 'object' or coalesce(jsonb_typeof(c->'name'),'') <> 'string' or coalesce(char_length(btrim(c->>'name')),0) not between 1 and 40 then raise exception 'Nom de catégorie invalide (1 à 40 caractères)'; end if;
      if coalesce(jsonb_typeof(c->'products'),'') <> 'array' or jsonb_array_length(c->'products') > 300 then raise exception 'Produits de catégorie invalides'; end if;
      for v in select * from jsonb_array_elements(c->'products') loop
        if jsonb_typeof(v) <> 'string' or (v #>> '{}') !~ '^[0-9a-fA-F-]{36}$' then raise exception 'Produit de catégorie invalide'; end if;
      end loop;
    end loop;
  end if;
end $$;
revoke all on function public.shop_design_check(jsonb) from public, anon, authenticated;

-- ---------- Garde : le vendeur n'écrit que son brouillon ----------
-- (s'exécute après shops_before_write_trg, qui protège déjà owner_id, slug et status)
create or replace function public.shops_design_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then
    if tg_op = 'INSERT' then
      new.design := null; new.published_at := null; new.moderation_note := null; new.moderated_at := null;
    else
      new.moderation_note := old.moderation_note;
      new.moderated_at := old.moderated_at;
      if coalesce(current_setting('maya.design_publish', true), '') <> 'on' then
        new.design := old.design;
        new.published_at := old.published_at;
      end if;
    end if;
  end if;
  perform public.shop_design_check(new.design_draft);
  perform public.shop_design_check(new.design);
  return new;
end $$;
revoke all on function public.shops_design_guard() from public, anon, authenticated;
drop trigger if exists shops_design_guard_trg on public.shops;
create trigger shops_design_guard_trg before insert or update on public.shops for each row execute function public.shops_design_guard();

-- ---------- Publier (le vendeur copie SON brouillon vers la version visible) ----------
create or replace function public.publish_shop_design() returns void
language plpgsql security definer set search_path = '' as $$
declare s public.shops;
begin
  if not public.is_seller() then raise exception 'Réservé aux vendeurs'; end if;
  select * into s from public.shops where owner_id = auth.uid();
  if s.id is null then raise exception 'Créez d''abord votre boutique'; end if;
  if s.status <> 'active' then raise exception 'Boutique suspendue par l''administration : publication impossible'; end if;
  if s.design_draft is null then raise exception 'Rien à publier : enregistrez d''abord votre design'; end if;
  perform set_config('maya.design_publish', 'on', true);
  update public.shops set design = design_draft, published_at = now() where id = s.id;
  perform set_config('maya.design_publish', 'off', true);
end $$;
revoke all on function public.publish_shop_design() from public, anon;
grant execute on function public.publish_shop_design() to authenticated;

-- ---------- Modération administrateur ----------
create table if not exists public.shop_moderation_log (
  id uuid primary key default gen_random_uuid(),
  shop_id uuid not null references public.shops(id) on delete cascade,
  admin_id uuid references public.profiles(id) on delete set null,
  action text not null check (action in ('suspend','activate','reset_design','note')),
  note text,
  created_at timestamptz not null default now()
);
create index if not exists shop_moderation_log_shop_idx on public.shop_moderation_log(shop_id, created_at desc);
alter table public.shop_moderation_log enable row level security;
revoke all on public.shop_moderation_log from anon;
grant select on public.shop_moderation_log to authenticated;
drop policy if exists sml_admin_select on public.shop_moderation_log;
create policy sml_admin_select on public.shop_moderation_log for select to authenticated using (public.is_admin());

create or replace function public.admin_moderate_shop(p_shop uuid, p_action text, p_note text default null) returns void
language plpgsql security definer set search_path = '' as $$
begin
  if not public.is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  if p_action not in ('suspend','activate','reset_design','note') then raise exception 'Action inconnue'; end if;
  if p_action in ('suspend','reset_design') and coalesce(btrim(p_note), '') = '' then raise exception 'Un motif est obligatoire'; end if;
  if not exists (select 1 from public.shops where id = p_shop) then raise exception 'Boutique introuvable'; end if;
  update public.shops set
    status = case p_action when 'suspend' then 'suspended' when 'activate' then 'active' else status end,
    design = case when p_action = 'reset_design' then null else design end,
    design_draft = case when p_action = 'reset_design' then null else design_draft end,
    published_at = case when p_action = 'reset_design' then null else published_at end,
    moderation_note = case when p_action = 'activate' then null else coalesce(nullif(btrim(p_note), ''), moderation_note) end,
    moderated_at = now()
  where id = p_shop;
  insert into public.shop_moderation_log (shop_id, admin_id, action, note) values (p_shop, auth.uid(), p_action, nullif(btrim(p_note), ''));
end $$;
revoke all on function public.admin_moderate_shop(uuid, text, text) from public, anon;
grant execute on function public.admin_moderate_shop(uuid, text, text) to authenticated;

-- ---------- Page publique : mêmes champs qu'avant + design publié + dates/stock pour « Nouveautés » ----------
create or replace function public.public_shop(p_slug text) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'shop', jsonb_build_object('id', s.id, 'slug', s.slug, 'name', s.name, 'description', s.description, 'logo_path', s.logo_path, 'banner_path', s.banner_path, 'city', s.city, 'phone', s.phone, 'whatsapp', s.whatsapp, 'address', s.address, 'owner_id', s.owner_id),
    'design', s.design,
    'products', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.name, 'price', p.price, 'promo_price', p.promo_price, 'unit', p.unit, 'image_path', p.image_path, 'stock', p.stock, 'created_at', p.created_at) order by p.created_at desc)
                            from (select * from public.products where created_by = s.owner_id and status = 'approved' order by created_at desc limit 200) p), '[]'::jsonb))
  from public.shops s where s.slug = p_slug and s.status = 'active';
$$;
revoke all on function public.public_shop(text) from public;
grant execute on function public.public_shop(text) to anon, authenticated;
