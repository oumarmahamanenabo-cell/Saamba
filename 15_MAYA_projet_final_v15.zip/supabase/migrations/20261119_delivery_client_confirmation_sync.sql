-- MAYA DELIVERY CONNECT — complément (19/11/2026), additif et idempotent.
-- Prérequis : migrations delivery_connect_tables / core / tracking (déjà appliquées sur le projet Supabase).
--
-- Constat d'audit : confirm_delivery() (COLIS REÇU / COLIS NON REÇU) mettait à jour la commande et le litige,
-- mais jamais la mission de livraison : elle restait « Colis livré » à vie, received_confirmed_at n'était jamais
-- renseigné et le statut « Livraison signalée comme non reçue » n'était jamais atteint.
-- Correctif : un déclencheur sur delivery_confirmations synchronise la mission, sans toucher à confirm_delivery().

create or replace function public.delivery_sync_client_confirmation() returns trigger
language plpgsql security definer set search_path = '' as $$
declare
  m public.delivery_missions;
  v_num text;
begin
  select number into v_num from public.orders where id = new.order_id;
  select * into m from public.delivery_missions
   where order_id = new.order_id and status not in ('cancelled', 'not_received')
   order by created_at desc limit 1;
  if not found then return new; end if;

  if new.kind::text = 'received' then
    if m.status <> 'delivered' then
      perform public._dm_set_status(m.id, 'delivered', 'Réception confirmée par le client');
    end if;
    update public.delivery_missions
       set received_confirmed_at = coalesce(received_confirmed_at, now()), gps_enabled = false, updated_at = now()
     where id = m.id;
    delete from public.delivery_live where mission_id = m.id;
    perform public._dm_event(m.id, 'note', null, 'Réception confirmée par le client');
    perform public._dm_notify(m.id, 'Colis reçu',
      'Le client a confirmé la réception de la commande ' || v_num || '. Livraison terminée.', array['seller', 'courier']);
  elsif new.kind::text = 'not_received' then
    perform public._dm_set_status(m.id, 'not_received',
      coalesce(nullif(btrim(new.note), ''), 'Colis non reçu signalé par le client'));
    perform public._dm_notify(m.id, 'Colis non reçu',
      'Le client signale ne pas avoir reçu la commande ' || v_num || '. Un litige est ouvert.', array['seller', 'courier', 'admin']);
  end if;
  return new;
end $$;

drop trigger if exists delivery_confirmation_sync on public.delivery_confirmations;
create trigger delivery_confirmation_sync
  after insert on public.delivery_confirmations
  for each row execute function public.delivery_sync_client_confirmation();

revoke all on function public.delivery_sync_client_confirmation() from public, anon, authenticated;

-- Tables accessibles uniquement par les fonctions serveur : politique explicite « aucun accès direct ».
drop policy if exists dinv_no_direct_access on public.delivery_invites;
create policy dinv_no_direct_access on public.delivery_invites for all to authenticated using (false) with check (false);
drop policy if exists dblock_no_direct_access on public.delivery_courier_blocks;
create policy dblock_no_direct_access on public.delivery_courier_blocks for all to authenticated using (false) with check (false);
