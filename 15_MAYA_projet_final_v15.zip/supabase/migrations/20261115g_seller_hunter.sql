-- MAYA SELLER HUNTER : module de prospection de vendeurs (réservé aux administrateurs)
-- Additif et idempotent. À exécuter une fois dans le SQL Editor du projet MAYA.
-- Aucune table existante (commandes, paiements, livraisons, grossistes, vendeurs) n'est modifiée.

create extension if not exists pg_trgm with schema extensions;

create or replace function public.seller_touch_updated_at() returns trigger
language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end $$;

-- Catégories (extensibles par l'administrateur)
create table if not exists public.seller_categories (
  slug text primary key,
  label_fr text not null,
  sort_order int not null default 100,
  active boolean not null default true,
  created_at timestamptz not null default now()
);
insert into public.seller_categories(slug,label_fr,sort_order) values
 ('vetements_chaussures','Vêtements et chaussures',1),
 ('cosmetiques_beaute','Cosmétiques et beauté',2),
 ('telephones_accessoires','Téléphones et accessoires',3),
 ('informatique_electronique','Informatique et électronique',4),
 ('electromenager','Électroménager',5),
 ('meubles_decoration','Meubles et décoration',6),
 ('alimentation_agricole','Alimentation et produits agricoles',7),
 ('produits_locaux_artisanat','Produits locaux et artisanat',8),
 ('materiaux_construction','Matériaux de construction',9),
 ('pieces_auto','Pièces détachées automobiles',10),
 ('bijoux_accessoires','Bijoux et accessoires',11),
 ('produits_enfants','Produits pour enfants',12),
 ('grossistes_fournisseurs','Grossistes et fournisseurs',13),
 ('fabricants_distributeurs','Fabricants et distributeurs',14),
 ('autres','Autres commerces',15)
on conflict (slug) do nothing;

-- Prospects
create table if not exists public.seller_prospects (
  id uuid primary key default gen_random_uuid(),
  shop_name text not null,
  owner_name text,
  logo_url text,
  country text,
  country_code char(2),
  region text,
  city text,
  address text,
  category text references public.seller_categories(slug),
  description text,
  products text[] not null default '{}',
  business_type text check (business_type in ('wholesaler','retailer','manufacturer','distributor','other')),
  social_links jsonb not null default '{}'::jsonb,
  website text,
  whatsapp text,
  email text,
  discovery_source text,
  discovered_at timestamptz not null default now(),
  last_verified_at timestamptz,
  confidence_score int not null default 0 check (confidence_score between 0 and 100),
  priority text not null default 'to_check' check (priority in ('high','medium','to_check')),
  score_reasons jsonb not null default '[]'::jsonb,
  status text not null default 'nouveau' check (status in (
    'nouveau','a_verifier','verifie','a_inviter','invitation_preparee','invitation_envoyee',
    'invitation_recue','a_repondu','interesse','inscription_commencee','inscription_terminee',
    'en_attente_verification','vendeur_valide','refuse','desinscrit')),
  dedupe_key text,
  linked_user_id uuid references public.profiles(id) on delete set null,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists seller_prospects_dedupe_uq on public.seller_prospects(dedupe_key) where dedupe_key is not null;
create index if not exists seller_prospects_country_idx on public.seller_prospects(country_code, city);
create index if not exists seller_prospects_category_idx on public.seller_prospects(category);
create index if not exists seller_prospects_status_idx on public.seller_prospects(status);
create index if not exists seller_prospects_priority_idx on public.seller_prospects(priority, confidence_score desc);
create index if not exists seller_prospects_name_trgm on public.seller_prospects using gin (shop_name extensions.gin_trgm_ops);
drop trigger if exists seller_prospects_touch on public.seller_prospects;
create trigger seller_prospects_touch before update on public.seller_prospects for each row execute function public.seller_touch_updated_at();

create table if not exists public.seller_prospect_sources (
  id uuid primary key default gen_random_uuid(),
  prospect_id uuid not null references public.seller_prospects(id) on delete cascade,
  source_type text not null,
  source_url text,
  external_id text,
  raw jsonb not null default '{}'::jsonb,
  discovered_at timestamptz not null default now()
);
create index if not exists seller_prospect_sources_prospect_idx on public.seller_prospect_sources(prospect_id);
create unique index if not exists seller_prospect_sources_ext_uq on public.seller_prospect_sources(source_type, external_id) where external_id is not null;

-- Modèles de messages
create table if not exists public.seller_message_templates (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  language text not null check (language in ('fr','en','pt','ar')),
  channel text not null default 'any' check (channel in ('any','whatsapp','email','instagram','facebook')),
  subject text,
  body text not null,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (name, language, channel)
);
drop trigger if exists seller_templates_touch on public.seller_message_templates;
create trigger seller_templates_touch before update on public.seller_message_templates for each row execute function public.seller_touch_updated_at();

-- Campagnes
create table if not exists public.seller_campaigns (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  description text,
  channel text not null default 'whatsapp' check (channel in ('whatsapp','email','instagram','facebook','link')),
  language text not null default 'fr' check (language in ('fr','en','pt','ar')),
  template_id uuid references public.seller_message_templates(id) on delete set null,
  filters jsonb not null default '{}'::jsonb,
  status text not null default 'draft' check (status in ('draft','prepared','confirmed','running','done','cancelled')),
  confirmed_by uuid references public.profiles(id) on delete set null,
  confirmed_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
drop trigger if exists seller_campaigns_touch on public.seller_campaigns;
create trigger seller_campaigns_touch before update on public.seller_campaigns for each row execute function public.seller_touch_updated_at();

-- Invitations
create table if not exists public.seller_invitations (
  id uuid primary key default gen_random_uuid(),
  prospect_id uuid not null references public.seller_prospects(id) on delete cascade,
  campaign_id uuid references public.seller_campaigns(id) on delete set null,
  channel text not null check (channel in ('whatsapp','email','instagram','facebook','link')),
  language text not null default 'fr' check (language in ('fr','en','pt','ar')),
  message text,
  join_token text not null unique default replace(gen_random_uuid()::text || gen_random_uuid()::text, '-', ''),
  status text not null default 'prepared' check (status in ('prepared','sent','delivered','replied','clicked','registering','registered','failed','cancelled')),
  prepared_at timestamptz not null default now(),
  sent_at timestamptz,
  replied_at timestamptz,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists seller_invitations_prospect_idx on public.seller_invitations(prospect_id);
create index if not exists seller_invitations_campaign_idx on public.seller_invitations(campaign_id, status);
drop trigger if exists seller_invitations_touch on public.seller_invitations;
create trigger seller_invitations_touch before update on public.seller_invitations for each row execute function public.seller_touch_updated_at();

create table if not exists public.seller_invitation_events (
  id bigint generated always as identity primary key,
  invitation_id uuid not null references public.seller_invitations(id) on delete cascade,
  event_type text not null,
  data jsonb not null default '{}'::jsonb,
  actor_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now()
);
create index if not exists seller_invitation_events_inv_idx on public.seller_invitation_events(invitation_id, created_at);

-- Consentements et désinscriptions
create table if not exists public.seller_consents (
  id uuid primary key default gen_random_uuid(),
  prospect_id uuid not null references public.seller_prospects(id) on delete cascade,
  channel text not null,
  granted boolean not null default true,
  basis text,
  recorded_by uuid references public.profiles(id) on delete set null,
  recorded_at timestamptz not null default now()
);
create index if not exists seller_consents_prospect_idx on public.seller_consents(prospect_id, channel);

-- contact_value : chiffres seuls pour WhatsApp, adresse en minuscules pour l'e-mail
create table if not exists public.seller_unsubscribes (
  id uuid primary key default gen_random_uuid(),
  prospect_id uuid references public.seller_prospects(id) on delete set null,
  channel text not null,
  contact_value text not null,
  reason text,
  created_at timestamptz not null default now(),
  unique (channel, contact_value)
);

-- Recherches programmées et résultats (réservé à une future fonction serveur)
create table if not exists public.seller_search_jobs (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  countries text[] not null default '{}',
  all_africa boolean not null default false,
  filters jsonb not null default '{}'::jsonb,
  sources text[] not null default '{}',
  schedule text not null default 'once' check (schedule in ('once','daily','weekly','monthly')),
  next_run_at timestamptz,
  last_run_at timestamptz,
  status text not null default 'queued' check (status in ('queued','running','done','failed','paused')),
  attempts int not null default 0,
  error text,
  created_by uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists seller_search_jobs_due_idx on public.seller_search_jobs(next_run_at) where status in ('queued','done');
drop trigger if exists seller_search_jobs_touch on public.seller_search_jobs;
create trigger seller_search_jobs_touch before update on public.seller_search_jobs for each row execute function public.seller_touch_updated_at();

create table if not exists public.seller_search_results (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.seller_search_jobs(id) on delete cascade,
  prospect_id uuid references public.seller_prospects(id) on delete set null,
  raw jsonb not null default '{}'::jsonb,
  status text not null default 'new' check (status in ('new','duplicate','imported','rejected')),
  created_at timestamptz not null default now()
);
create index if not exists seller_search_results_job_idx on public.seller_search_results(job_id, status);

create table if not exists public.seller_hunter_logs (
  id bigint generated always as identity primary key,
  actor_id uuid references public.profiles(id) on delete set null,
  action text not null,
  entity text,
  entity_id text,
  level text not null default 'info' check (level in ('info','warn','error')),
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);
create index if not exists seller_hunter_logs_created_idx on public.seller_hunter_logs(created_at desc);

-- RLS : administrateurs uniquement (rôle anonyme sans aucun accès)
do $$
declare t text;
begin
  foreach t in array array['seller_categories','seller_prospects','seller_prospect_sources','seller_message_templates',
    'seller_campaigns','seller_invitations','seller_invitation_events','seller_consents','seller_unsubscribes',
    'seller_search_jobs','seller_search_results','seller_hunter_logs'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('revoke all on public.%I from anon', t);
    execute format('drop policy if exists %I on public.%I', t || '_admin_all', t);
    execute format('create policy %I on public.%I for all to authenticated using (public.is_admin()) with check (public.is_admin())', t || '_admin_all', t);
  end loop;
end $$;

-- Journal d'audit (si la fonction audit_row existe dans ce projet)
do $$
declare t text;
begin
  if to_regprocedure('public.audit_row()') is not null then
    foreach t in array array['seller_prospects','seller_campaigns','seller_invitations','seller_search_jobs'] loop
      execute format('drop trigger if exists %I on public.%I', t || '_audit', t);
      execute format('create trigger %I after insert or update or delete on public.%I for each row execute function public.audit_row()', t || '_audit', t);
    end loop;
  end if;
end $$;

-- Interdit d'inviter un prospect désinscrit ou dont le contact est dans la liste de désinscription
create or replace function public.seller_invitation_guard() returns trigger
language plpgsql security definer set search_path = '' as $$
declare p public.seller_prospects;
begin
  select * into p from public.seller_prospects where id = new.prospect_id;
  if p.status = 'desinscrit' then
    raise exception 'Prospect désinscrit : invitation interdite';
  end if;
  if exists (select 1 from public.seller_unsubscribes u
             where u.channel = new.channel
               and u.contact_value in (regexp_replace(coalesce(p.whatsapp,''), '\D', '', 'g'), lower(coalesce(p.email,'')))
               and u.contact_value <> '') then
    raise exception 'Contact présent dans la liste de désinscription';
  end if;
  return new;
end $$;
drop trigger if exists seller_invitations_guard on public.seller_invitations;
create trigger seller_invitations_guard before insert on public.seller_invitations for each row execute function public.seller_invitation_guard();

-- Notification administrateur aux étapes clés du recrutement
create or replace function public.seller_prospect_notify() returns trigger
language plpgsql security definer set search_path = '' as $$
begin
  if new.status is distinct from old.status and new.status in
     ('a_repondu','interesse','inscription_commencee','inscription_terminee','vendeur_valide') then
    perform public.notify_admins('seller_hunter', 'MAYA Seller Hunter',
      new.shop_name || ' : ' || new.status,
      jsonb_build_object('prospect_id', new.id, 'status', new.status));
  end if;
  return new;
end $$;
drop trigger if exists seller_prospects_notify on public.seller_prospects;
create trigger seller_prospects_notify after update on public.seller_prospects for each row execute function public.seller_prospect_notify();

-- Page publique d'inscription (à brancher plus tard) : accès par jeton, données minimales
create or replace function public.seller_join_lookup(p_token text) returns jsonb
language plpgsql security definer set search_path = '' as $$
declare i public.seller_invitations; p public.seller_prospects;
begin
  select * into i from public.seller_invitations where join_token = p_token and status <> 'cancelled';
  if not found then return null; end if;
  select * into p from public.seller_prospects where id = i.prospect_id;
  if p.status = 'desinscrit' then return null; end if;
  insert into public.seller_invitation_events(invitation_id, event_type) values (i.id, 'link_clicked');
  update public.seller_invitations set status = 'clicked' where id = i.id and status in ('prepared','sent','delivered');
  return jsonb_build_object('invitation_id', i.id, 'shop_name', p.shop_name, 'country', p.country, 'language', i.language);
end $$;
revoke all on function public.seller_join_lookup(text) from public;
grant execute on function public.seller_join_lookup(text) to anon, authenticated;

-- Modèles d'invitation (français, anglais, portugais, arabe)
insert into public.seller_message_templates(name, language, channel, subject, body) values
('invitation_standard','fr','any','Invitation à rejoindre MAYA',
$t$Bonjour {{shop_name}} !

Nous avons découvert votre boutique et souhaitons vous inviter à rejoindre MAYA, une marketplace africaine qui permet aux commerçants de présenter leurs produits, toucher de nouveaux clients et développer leurs activités.

L'inscription vendeur est accessible ici :
{{join_link}}

Nous serions ravis de vous compter parmi nos partenaires.
L'équipe MAYA.$t$),
('invitation_standard','en','any','Invitation to join MAYA',
$t$Hello {{shop_name}}!

We discovered your shop and would like to invite you to join MAYA, an African marketplace that helps merchants showcase their products, reach new customers and grow their business.

Seller registration is available here:
{{join_link}}

We would be delighted to have you as a partner.
The MAYA team.$t$),
('invitation_standard','pt','any','Convite para aderir à MAYA',
$t$Olá {{shop_name}}!

Descobrimos a sua loja e gostaríamos de o(a) convidar a aderir à MAYA, um marketplace africano que permite aos comerciantes apresentar os seus produtos, alcançar novos clientes e desenvolver o seu negócio.

O registo de vendedor está disponível aqui:
{{join_link}}

Teremos todo o gosto em tê-lo(a) como parceiro(a).
A equipa MAYA.$t$),
('invitation_standard','ar','any','دعوة للانضمام إلى MAYA',
$t$مرحباً {{shop_name}}!

اكتشفنا متجركم ونود دعوتكم للانضمام إلى MAYA، سوق إلكترونية إفريقية تتيح للتجار عرض منتجاتهم والوصول إلى عملاء جدد وتنمية أعمالهم.

رابط التسجيل كبائع:
{{join_link}}

يسعدنا انضمامكم إلى شركائنا.
فريق MAYA.$t$)
on conflict (name, language, channel) do nothing;
