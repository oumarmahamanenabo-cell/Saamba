-- MAYA : accès public (visiteurs) en lecture seule + compte obligatoire pour toute action commerciale.
-- Additif et idempotent. À exécuter après 20261117_shop_customization.sql.

-- ============================================================
-- 1. Boutique suspendue : fonction utilitaire (contourne la RLS de shops, sans rien exposer)
-- ============================================================
create or replace function public.owner_shop_suspended(p_owner uuid) returns boolean
language sql stable security definer set search_path = '' as $$
  select p_owner is not null and exists (select 1 from public.shops s where s.owner_id = p_owner and s.status = 'suspended');
$$;
revoke all on function public.owner_shop_suspended(uuid) from public;
grant execute on function public.owner_shop_suspended(uuid) to anon, authenticated;

-- ============================================================
-- 2. Droits des visiteurs (rôle anon) : on retire tout, puis on ouvre uniquement la consultation publique
-- ============================================================
do $$
declare r record;
begin
  for r in select c.relname from pg_class c join pg_namespace n on n.oid = c.relnamespace
           where n.nspname = 'public' and c.relkind in ('r','v','m','p') loop
    execute format('revoke all on public.%I from anon', r.relname);
  end loop;
end $$;
alter default privileges in schema public revoke all on tables from anon;
alter default privileges in schema public revoke all on sequences from anon;

-- Catégories actives
grant select on public.categories to anon;
drop policy if exists cat_anon_select on public.categories;
create policy cat_anon_select on public.categories for select to anon using (active);

-- Produits validés (hors boutiques suspendues)
grant select on public.products to anon;
drop policy if exists prod_anon_select on public.products;
create policy prod_anon_select on public.products for select to anon
  using (status = 'approved' and not public.owner_shop_suspended(created_by));

-- Photos et vidéos des produits visibles
grant select on public.product_media to anon;
drop policy if exists pm_anon_select on public.product_media;
create policy pm_anon_select on public.product_media for select to anon
  using (exists (select 1 from public.products p where p.id = product_media.product_id));

-- Boutiques actives : colonnes publiques seulement (ni e-mail, ni téléphone, ni brouillon, ni notes de modération)
grant select (id, slug, name, description, logo_path, banner_path, city, status, design, owner_id, published_at, created_at) on public.shops to anon;
drop policy if exists shops_anon_select on public.shops;
create policy shops_anon_select on public.shops for select to anon using (status = 'active');

-- Les clients connectés ne voient pas non plus les produits d'une boutique suspendue
drop policy if exists prod_select on public.products;
create policy prod_select on public.products for select to authenticated
  using ((status = 'approved' and not public.owner_shop_suspended(created_by)) or public.is_admin());

-- ============================================================
-- 3. Pages publiques : coordonnées directes (téléphone, WhatsApp) réservées aux comptes connectés
--    (contacter un vendeur = compte obligatoire)
-- ============================================================
create or replace function public.public_shop(p_slug text) returns jsonb
language sql stable security definer set search_path = '' as $$
  select jsonb_build_object(
    'shop', jsonb_build_object('id', s.id, 'slug', s.slug, 'name', s.name, 'description', s.description, 'logo_path', s.logo_path, 'banner_path', s.banner_path, 'city', s.city,
      'phone', case when auth.uid() is not null then s.phone end,
      'whatsapp', case when auth.uid() is not null then s.whatsapp end,
      'address', s.address, 'owner_id', s.owner_id),
    'design', s.design,
    'products', coalesce((select jsonb_agg(jsonb_build_object('id', p.id, 'name', p.name, 'price', p.price, 'promo_price', p.promo_price, 'unit', p.unit, 'image_path', p.image_path, 'stock', p.stock, 'created_at', p.created_at) order by p.created_at desc)
                            from (select * from public.products where created_by = s.owner_id and status = 'approved' order by created_at desc limit 200) p), '[]'::jsonb))
  from public.shops s where s.slug = p_slug and s.status = 'active';
$$;
revoke all on function public.public_shop(text) from public;
grant execute on function public.public_shop(text) to anon, authenticated;

-- ============================================================
-- 4. Vendeur non autorisé / suspendu : aucune publication
-- ============================================================
drop policy if exists prod_seller_insert on public.products;
create policy prod_seller_insert on public.products for insert to authenticated
  with check (created_by = auth.uid() and public.is_seller() and not public.owner_shop_suspended(auth.uid()));
drop policy if exists prod_seller_update on public.products;
create policy prod_seller_update on public.products for update to authenticated
  using (created_by = auth.uid() and public.is_seller() and not public.owner_shop_suspended(auth.uid()))
  with check (created_by = auth.uid() and not public.owner_shop_suspended(auth.uid()));
drop policy if exists prod_seller_delete on public.products;
create policy prod_seller_delete on public.products for delete to authenticated
  using (created_by = auth.uid() and public.is_seller());
drop policy if exists prod_seller_select on public.products;
create policy prod_seller_select on public.products for select to authenticated using (created_by = auth.uid());

-- ============================================================
-- 5. Demandes pour devenir vendeur (compte -> profil vendeur -> boutique -> documents -> validation admin)
-- ============================================================
create table if not exists public.seller_applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  shop_name text not null check (char_length(btrim(shop_name)) between 2 and 80),
  activity text not null check (char_length(btrim(activity)) between 3 and 1000),
  category text check (category is null or char_length(category) <= 80),
  city text not null check (char_length(btrim(city)) between 2 and 80),
  phone text not null check (char_length(btrim(phone)) between 6 and 30),
  whatsapp text check (whatsapp is null or char_length(whatsapp) <= 30),
  address text check (address is null or char_length(address) <= 200),
  doc_paths jsonb not null default '[]'::jsonb,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_note text,
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);
create unique index if not exists seller_applications_one_pending on public.seller_applications(user_id) where status = 'pending';
create index if not exists seller_applications_status_idx on public.seller_applications(status, created_at desc);
alter table public.seller_applications enable row level security;
revoke all on public.seller_applications from anon;
revoke all on public.seller_applications from authenticated;
grant select on public.seller_applications to authenticated;
drop policy if exists sapp_select on public.seller_applications;
create policy sapp_select on public.seller_applications for select to authenticated using (user_id = auth.uid() or public.is_admin());

-- Documents de vérification : bucket privé (le dossier = identifiant de l'utilisateur)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('seller-docs', 'seller-docs', false, 8388608, array['image/jpeg','image/png','image/webp','application/pdf'])
on conflict (id) do nothing;
drop policy if exists seller_docs_insert on storage.objects;
create policy seller_docs_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'seller-docs' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists seller_docs_select on storage.objects;
create policy seller_docs_select on storage.objects for select to authenticated
  using (bucket_id = 'seller-docs' and ((storage.foldername(name))[1] = auth.uid()::text or public.is_admin()));
drop policy if exists seller_docs_admin on storage.objects;
create policy seller_docs_admin on storage.objects for all to authenticated
  using (bucket_id = 'seller-docs' and public.is_admin()) with check (bucket_id = 'seller-docs' and public.is_admin());

create or replace function public.submit_seller_application(
  p_shop_name text, p_activity text, p_category text, p_city text, p_phone text, p_whatsapp text, p_address text, p_docs jsonb
) returns uuid
language plpgsql security definer set search_path = '' as $$
declare
  v_me uuid := auth.uid(); v_role text; v_id uuid; d jsonb; v_has_identity boolean := false; v_admin uuid;
begin
  if v_me is null then raise exception 'Connexion requise'; end if;
  select role::text into v_role from public.profiles where id = v_me and active;
  if v_role is null then raise exception 'Compte indisponible'; end if;
  if v_role <> 'client' then raise exception 'Votre compte dispose déjà d''un espace dédié.'; end if;
  if exists (select 1 from public.seller_applications where user_id = v_me and status = 'pending') then
    raise exception 'Vous avez déjà une demande en cours d''examen.';
  end if;
  if p_docs is null or jsonb_typeof(p_docs) <> 'array' or jsonb_array_length(p_docs) = 0 or jsonb_array_length(p_docs) > 6 then
    raise exception 'Ajoutez vos documents de vérification (1 à 6 fichiers).';
  end if;
  for d in select * from jsonb_array_elements(p_docs) loop
    if coalesce(d->>'path', '') not like (v_me::text || '/%') or position('..' in d->>'path') > 0 then
      raise exception 'Document invalide';
    end if;
    if coalesce(d->>'kind', '') not in ('identity', 'business', 'other') then raise exception 'Type de document invalide'; end if;
    if d->>'kind' = 'identity' then v_has_identity := true; end if;
  end loop;
  if not v_has_identity then raise exception 'Une pièce d''identité est obligatoire.'; end if;
  insert into public.seller_applications(user_id, shop_name, activity, category, city, phone, whatsapp, address, doc_paths)
  values (v_me, btrim(p_shop_name), btrim(p_activity), nullif(btrim(coalesce(p_category, '')), ''), btrim(p_city), btrim(p_phone),
          nullif(btrim(coalesce(p_whatsapp, '')), ''), nullif(btrim(coalesce(p_address, '')), ''), p_docs)
  returning id into v_id;
  for v_admin in select id from public.profiles where role = 'admin' and active loop
    insert into public.notifications(user_id, type, title, body, data)
    values (v_admin, 'seller_application', 'Nouvelle demande vendeur', btrim(p_shop_name) || ' · ' || btrim(p_city), jsonb_build_object('application_id', v_id));
  end loop;
  return v_id;
end $$;
revoke all on function public.submit_seller_application(text, text, text, text, text, text, text, jsonb) from public, anon;
grant execute on function public.submit_seller_application(text, text, text, text, text, text, text, jsonb) to authenticated;

create or replace function public.admin_review_seller_application(p_id uuid, p_approve boolean, p_note text default null)
returns void
language plpgsql security definer set search_path = '' as $$
declare a public.seller_applications;
begin
  if not public.is_admin() then raise exception 'Réservé aux administrateurs'; end if;
  select * into a from public.seller_applications where id = p_id for update;
  if not found then raise exception 'Demande introuvable'; end if;
  if a.status <> 'pending' then raise exception 'Cette demande a déjà été traitée.'; end if;
  if p_approve then
    update public.profiles set role = 'seller' where id = a.user_id and role = 'client';
    if not found then raise exception 'Seul un compte client actif peut devenir vendeur.'; end if;
    insert into public.shops(owner_id, name, description, city, phone, whatsapp, address)
    values (a.user_id, a.shop_name, a.activity, a.city, a.phone, a.whatsapp, a.address)
    on conflict (owner_id) do nothing;
  elsif coalesce(btrim(p_note), '') = '' then
    raise exception 'Indiquez le motif du refus.';
  end if;
  update public.seller_applications
     set status = case when p_approve then 'approved' else 'rejected' end, admin_note = nullif(btrim(coalesce(p_note, '')), ''),
         reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_id;
  insert into public.notifications(user_id, type, title, body, data)
  values (a.user_id, 'seller_application',
          case when p_approve then 'Demande vendeur acceptée' else 'Demande vendeur refusée' end,
          case when p_approve then 'Bienvenue ! Redémarrez l''application pour accéder à votre espace vendeur et publier vos produits.'
               else 'Motif : ' || btrim(p_note) end,
          jsonb_build_object('application_id', a.id));
end $$;
revoke all on function public.admin_review_seller_application(uuid, boolean, text) from public, anon;
grant execute on function public.admin_review_seller_application(uuid, boolean, text) to authenticated;
