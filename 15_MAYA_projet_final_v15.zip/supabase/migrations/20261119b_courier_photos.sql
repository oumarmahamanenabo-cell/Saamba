-- MAYA DELIVERY CONNECT — photo facultative du livreur (19/11/2026), additif et idempotent.
-- Bucket PRIVÉ : le vendeur écrit dans son dossier ; seuls les participants de la mission (vendeur, client, livreur, admin) la lisent.

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('courier-photos', 'courier-photos', false, 2097152, array['image/jpeg', 'image/png', 'image/webp'])
on conflict (id) do nothing;

create or replace function public.courier_photo_visible(p_path text) returns boolean
language sql stable security definer set search_path = '' as $$
  select auth.uid() is not null and (
    (storage.foldername(p_path))[1] = auth.uid()::text
    or public.is_admin()
    or exists (select 1 from public.delivery_missions m
               where m.courier_photo_path = p_path and public._dm_is_participant(m.id))
  );
$$;
revoke all on function public.courier_photo_visible(text) from public, anon;
grant execute on function public.courier_photo_visible(text) to authenticated;

drop policy if exists courier_photos_select on storage.objects;
create policy courier_photos_select on storage.objects for select to authenticated
  using (bucket_id = 'courier-photos' and public.courier_photo_visible(name));

drop policy if exists courier_photos_insert on storage.objects;
create policy courier_photos_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'courier-photos' and (storage.foldername(name))[1] = auth.uid()::text and public.is_seller());

drop policy if exists courier_photos_delete on storage.objects;
create policy courier_photos_delete on storage.objects for delete to authenticated
  using (bucket_id = 'courier-photos' and (storage.foldername(name))[1] = auth.uid()::text);
