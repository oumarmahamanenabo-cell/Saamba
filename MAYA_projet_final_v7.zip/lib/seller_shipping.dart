import 'package:flutter/material.dart';
import 'common.dart';

// ======== Espace vendeur : commandes à expédier (transporteur, contacts, lieu d'arrivée) ========
const _editableStatuses = ['paid', 'preparing', 'ready_to_ship', 'handed_to_carrier', 'in_transit', 'arrived', 'reception_pending'];

class SellerOrdersScreen extends StatefulWidget {
  const SellerOrdersScreen({super.key});
  @override
  State<SellerOrdersScreen> createState() => _SellerOrdersScreenState();
}

class _SellerOrdersScreenState extends State<SellerOrdersScreen> {
  late Future<List<Map<String, dynamic>>> _f = _load();

  Future<List<Map<String, dynamic>>> _load() async {
    final r = await sb.rpc('seller_my_orders');
    return List<Map<String, dynamic>>.from((r as List).map((e) => Map<String, dynamic>.from(e as Map)));
  }

  void _reload() => setState(() => _f = _load());

  Future<void> _edit(Map<String, dynamic> order) async {
    List<Map<String, dynamic>> carriers = [];
    try {
      final r = await sb.rpc('list_verified_carriers');
      carriers = List<Map<String, dynamic>>.from((r as List).map((e) => Map<String, dynamic>.from(e as Map)));
    } catch (_) {}
    String myPhone = '+223 ';
    try {
      final p = await sb.from('profiles').select('phone').eq('id', uid).maybeSingle();
      if ((p?['phone'] as String?)?.isNotEmpty == true) myPhone = p!['phone'] as String;
    } catch (_) {}
    if (!mounted) return;
    final sh = order['shipment'] as Map<String, dynamic>?;
    final name = TextEditingController(text: sh?['carrier_name'] as String?);
    final cPhone = TextEditingController(text: sh?['carrier_phone'] as String?);
    final myPhoneC = TextEditingController(text: sh?['seller_phone'] as String? ?? myPhone);
    final place = TextEditingController(text: sh?['arrival_place'] as String? ?? (order['client_city'] as String?) ?? '');
    final notes = TextEditingController(text: sh?['notes'] as String?);
    String carrierId = (sh?['carrier_id'] as String?) ?? '';
    if (carrierId.isNotEmpty && !carriers.any((c) => c['id'] == carrierId)) carrierId = '';
    DateTime? arrival = sh?['expected_arrival_date'] == null ? null : DateTime.parse(sh!['expected_arrival_date'] as String);
    String? err;
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text('Expédition ${order['number']}'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
              if (carriers.isNotEmpty)
                DropdownButtonFormField<String>(
                  value: carrierId,
                  isExpanded: true,
                  decoration: const InputDecoration(labelText: 'Transporteur'),
                  items: [
                    const DropdownMenuItem(value: '', child: Text('Autre transporteur (saisie manuelle)')),
                    for (final c in carriers)
                      DropdownMenuItem(value: c['id'] as String, child: Text('${c['name']}${c['city'] != null ? ' · ${c['city']}' : ''} (vérifié)', overflow: TextOverflow.ellipsis)),
                  ],
                  onChanged: (v) => setS(() {
                    carrierId = v ?? '';
                    final c = carriers.where((x) => x['id'] == carrierId).toList();
                    if (c.isNotEmpty) {
                      name.text = c.first['name'] as String? ?? '';
                      cPhone.text = c.first['phone'] as String? ?? '';
                    }
                  }),
                ),
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom du transporteur *')),
              TextField(controller: cPhone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone du transporteur *')),
              TextField(controller: myPhoneC, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Votre numéro de contact (+223…) *')),
              TextField(controller: place, decoration: const InputDecoration(labelText: 'Ville / lieu d\'arrivée du colis *')),
              TextField(controller: notes, decoration: const InputDecoration(labelText: 'Informations complémentaires')),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () async {
                  final d = await showDatePicker(
                      context: ctx, initialDate: arrival ?? DateTime.now(), firstDate: DateTime.now().subtract(const Duration(days: 30)), lastDate: DateTime.now().add(const Duration(days: 365)));
                  if (d != null) setS(() => arrival = d);
                },
                child: Text(arrival == null ? 'Date d\'arrivée prévue' : 'Arrivée prévue : ${dOnly(arrival!.toIso8601String())}'),
              ),
              if (carrierId.isEmpty)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text('Un transporteur saisi manuellement est signalé « non vérifié » au client et à l\'administration.', style: TextStyle(fontSize: 11.5, color: Colors.deepOrange)),
                ),
              if (err != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(err!, style: const TextStyle(color: Colors.red))),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            FilledButton(
              onPressed: () {
                final digits = myPhoneC.text.replaceAll(RegExp(r'\D'), '');
                if (name.text.trim().isEmpty) {
                  setS(() => err = 'Le nom du transporteur est obligatoire.');
                } else if (cPhone.text.replaceAll(RegExp(r'\D'), '').length < 8) {
                  setS(() => err = 'Le téléphone du transporteur est obligatoire.');
                } else if (!RegExp(r'^(223)?\d{8}$').hasMatch(digits)) {
                  setS(() => err = 'Votre contact doit être un numéro malien (+223 suivi de 8 chiffres).');
                } else if (place.text.trim().length < 2) {
                  setS(() => err = 'Le lieu d\'arrivée du colis est obligatoire.');
                } else {
                  Navigator.pop(ctx, true);
                }
              },
              child: const Text('Enregistrer'),
            ),
          ],
        ),
      ),
    );
    if (ok != true || !mounted) return;
    await guarded(context, () async {
      await sb.rpc('seller_save_shipping', params: {
        'p_order': order['order_id'],
        'p_carrier_id': carrierId.isEmpty ? null : carrierId,
        'p_carrier_name': name.text.trim(),
        'p_carrier_phone': cPhone.text.trim(),
        'p_seller_phone': myPhoneC.text.trim(),
        'p_arrival_place': place.text.trim(),
        'p_arrival_date': arrival?.toIso8601String().substring(0, 10),
        'p_notes': notes.text.trim(),
      });
      if (mounted) snack(context, 'Expédition enregistrée. Le client et l\'administration sont prévenus.');
      _reload();
    });
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<List<Map<String, dynamic>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final list = snap.data!;
          if (list.isEmpty) {
            return const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Aucune commande payée pour vos produits pour le moment.', textAlign: TextAlign.center)));
          }
          return RefreshIndicator(
            onRefresh: () async => _reload(),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              const Padding(
                padding: EdgeInsets.only(bottom: 8),
                child: Text('Pour chaque commande payée, indiquez le transporteur, vos contacts et le lieu d\'arrivée du colis.', style: TextStyle(fontSize: 12.5)),
              ),
              for (final o in list) _card(o),
            ]),
          );
        },
      );

  Widget _card(Map<String, dynamic> o) {
    final sh = o['shipment'] as Map<String, dynamic>?;
    final status = o['status'] as String;
    final canEdit = _editableStatuses.contains(status);
    final items = List<Map<String, dynamic>>.from((o['items'] as List).map((e) => Map<String, dynamic>.from(e as Map)));
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(o['number'] as String, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
            Chip(label: Text(orderStatusLabels[status] ?? status, style: const TextStyle(fontSize: 11))),
          ]),
          Text('Client : ${o['client_name'] ?? ''}${o['client_city'] != null ? ' · ${o['client_city']}' : ''}'),
          if (o['client_phone'] != null) Text('Contact client : ${o['client_phone']}'),
          const SizedBox(height: 4),
          for (final it in items) Text('• ${it['name']} × ${n(it['quantity'])} ${it['unit'] ?? ''}', style: const TextStyle(fontSize: 12.5)),
          const Divider(),
          if (sh == null)
            const Text('⚠ Informations d\'expédition à fournir', style: TextStyle(color: Colors.deepOrange, fontWeight: FontWeight.bold))
          else ...[
            Text('Transporteur : ${sh['carrier_name']}${sh['carrier_verified'] == true ? ' (vérifié)' : ' (non vérifié)'}'),
            Text('Téléphone du transporteur : ${sh['carrier_phone']}'),
            Text('Votre contact : ${sh['seller_phone']}'),
            Text('Arrivée : ${sh['arrival_place']}'),
            if (sh['expected_arrival_date'] != null) Text('Date prévue : ${dOnly(sh['expected_arrival_date'])}'),
            if ((sh['notes'] as String?)?.isNotEmpty == true) Text('Infos : ${sh['notes']}'),
          ],
          if (canEdit)
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                icon: const Icon(Icons.local_shipping_outlined),
                label: Text(sh == null ? 'Renseigner l\'expédition' : 'Modifier'),
                onPressed: () => _edit(o),
              ),
            ),
        ]),
      ),
    );
  }
}
