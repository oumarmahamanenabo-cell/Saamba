-- Ville du client, saisie à l'inscription (métadonnée city). Additif et idempotent.
alter table public.profiles add column if not exists city text;

create or replace function public.copy_signup_city()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.profiles
     set city = nullif(trim(new.raw_user_meta_data->>'city'), '')
   where id = new.id;
  return new;
end;
$$;

-- Nom en "zz_" : se déclenche après le trigger qui crée la ligne du profil.
drop trigger if exists zz_copy_signup_city on auth.users;
create trigger zz_copy_signup_city
  after insert on auth.users
  for each row execute function public.copy_signup_city();

-- Reprise des comptes existants qui auraient déjà une ville en métadonnée.
update public.profiles p
   set city = nullif(trim(u.raw_user_meta_data->>'city'), '')
  from auth.users u
 where u.id = p.id and p.city is null and u.raw_user_meta_data ? 'city';
