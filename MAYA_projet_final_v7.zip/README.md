# MAYA – application Android (Flutter + Supabase)

Achetez • Vendez • Livrez. Trois espaces : client, administration, grossiste.

## Obtenir l'APK avec GitHub (sans ordinateur)
1. Créez un dépôt GitHub et envoyez-y **le contenu de ce zip à la racine** (pubspec.yaml doit être à la racine).
2. Onglet **Actions** → « Build APK MAYA » → **Run workflow** (il se lance aussi à chaque push sur `main`).
3. À la fin (≈ 8 à 12 min), ouvrez l'exécution → **Artifacts → MAYA-apk** → téléchargez `MAYA.apk` et installez-le.

Le workflow génère lui-même le dossier `android/`, ajoute les permissions (micro, caméra, internet, appels), le nom « MAYA », l'icône du logo, puis compile.

## Backend Supabase (déjà configuré)
Le projet Supabase utilisé est celui de `lib/config.dart` (référence `juaidyvcngqizxvnsxke`, projet nommé « SAAMBA » dans Supabase : renommez-le « MAYA » dans Project Settings > General).
Tables, règles RLS, fonctions, stockage et notifications internes sont en place.

À faire une seule fois dans le tableau de bord Supabase :
- Authentication > Providers > Email : désactiver « Confirm email » (inscription par e-mail ; les anciens comptes créés avec un numéro restent connectables en saisissant leur numéro à la place de l'e-mail).
- Premier administrateur : créez son compte dans l'app, puis dans le SQL Editor :
  `update public.profiles set role = 'admin' where id = (select id from auth.users where email = '223XXXXXXXX@saamba.app');`
  (remplacez par le numéro saisi à l'inscription, chiffres seulement).

## Contenu de l'application
- Client : accueil, messagerie (texte, vocal, photo, vidéo, document), commandes, factures PDF, paiements, livraisons, appel transporteur Orange/Malitel, confirmation de réception / colis non reçu, notifications.
- Administration : tableau de bord, conversations, commandes (lignes, frais, réduction), factures, liens de paiement, expéditions, signalements, grossistes (fiches, invitations, demandes avec pièces jointes, saisie manuelle des réponses, comparaison des prix avec anciens prix, archives, notes privées, marges).
- Grossiste invité : demandes reçues, réponses avec prix, disponibilités et pièces jointes, historique de ses propres échanges.

## Non inclus (à configurer plus tard)
- Prestataire de paiement : son webhook doit appeler `public.confirm_payment(ref, montant, id_evenement, payload)` avec la clé service_role.
- Notifications push FCM (google-services.json + Edge Function) : les notifications sont déjà créées dans la table `notifications` et affichées dans l'app.
- Sélection forcée de la SIM : Android ne l'autorise pas pour une app ; l'app ouvre le composeur avec une explication.

## Note technique
L'identifiant interne `@saamba.app` (adresse technique des comptes) et le nom de paquet `com.saamba` sont conservés volontairement : les renommer casserait les comptes existants.

## Vérification des partenaires (nouveau)
1. Exécutez `supabase/migrations/20261115_partner_verification.sql` dans le SQL Editor de Supabase (additif, idempotent).
2. Dans l'app admin : onglet Grossistes > Vérification. Traitez les grossistes existants (ils sont « EN ATTENTE » par défaut), ajoutez les transporteurs et leurs justificatifs (bucket privé `partner-docs`).
3. Une fois les grossistes actifs approuvés, activez l'obligation : `update public.partner_settings set value='true' where key='enforce_verification';`
4. La règle « aucun transporteur non vérifié ne reçoit de mission » est active dès la migration (colonne `delivery_details.carrier_id`).

## Accueil client (maquette) et portefeuille vendeur (nouveau)
- Accueil client refait d'après la maquette (bannière, accès rapides, catégories, meilleures offres) ; navigation : Accueil, Catégories, Favoris, Commandes, Mon compte.
- Rôle `seller` : l'admin nomme un vendeur (icône portefeuille > Vendeurs) puis rattache chaque produit d'une commande à son vendeur (icône boutique sur la ligne produit).
- Séquestre : à la confirmation du paiement, les gains sont crédités « bloqués ». Ils deviennent retirables uniquement quand LE CLIENT appuie sur « COLIS REÇU » (un changement de statut par l'admin ne libère rien). Retrait via Orange Money / Moov Money / Wave, payé manuellement par l'admin (Retraits).
- Litige : « COLIS NON REÇU » ou « incomplet / endommagé » ouvre un signalement chez l'admin et garde les fonds bloqués ; l'admin peut annuler les fonds du vendeur si le client a raison.
- Le client est averti à l'expédition (notification) et avant de confirmer (message + boîte de confirmation).
- Commission vendeur : `update public.partner_settings set value='5' where key='seller_commission_pct';` (en %, 0 par défaut).
- Migrations déjà appliquées sur le projet Supabase : `supabase/migrations/*.sql`.

## Produits des vendeurs (nouveau)
- Le vendeur publie lui-même ses produits (photo, prix, promo, stock, unité) dans l'onglet « Produits ». Toute création ou modification passe « EN ATTENTE » : l'admin valide dans Vendeurs et retraits > Produits.
- Vendeur de confiance : interrupteur « Publication automatique » dans Vendeurs et retraits > Vendeurs. Le serveur empêche un vendeur de s'approuver lui-même.
- Photos : bucket public `product-images` (écriture réservée au dossier du vendeur).

## Inscription par e-mail (nouveau)
- Inscription : nom complet, ville, numéro de téléphone malien (+223 + 8 chiffres) et adresse e-mail, tous obligatoires, plus mot de passe (6 caractères minimum).
- Exécutez `supabase/migrations/20261115e_profile_city.sql` dans le SQL Editor pour enregistrer la ville dans `profiles.city`.
- Pas de confirmation par e-mail (« Confirm email » désactivé dans Supabase).

## Expédition renseignée par le vendeur (nouveau)
- Exécutez `supabase/migrations/20261115f_seller_shipping.sql` dans le SQL Editor (après la migration 20261115e).
- Espace vendeur > onglet « Commandes » : pour chaque commande payée contenant ses produits, le vendeur renseigne le transporteur (vérifié, ou saisie manuelle signalée « non vérifié »), le téléphone du transporteur, son propre contact malien, le lieu et la date d'arrivée du colis.
- Le client voit ces informations dans sa commande (avec les boutons d'appel Orange / Malitel) ; l'administration aussi et reçoit une notification. Le statut de la commande reste changé par l'administration.
