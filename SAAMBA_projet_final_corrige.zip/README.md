# SAAMBA – application Android (Flutter + Supabase)

Commander · Échanger · Recevoir. Trois espaces : client, administration, grossiste.

## Obtenir l'APK avec GitHub (sans ordinateur)
1. Créez un dépôt GitHub et envoyez-y **le contenu de ce zip à la racine** (pubspec.yaml doit être à la racine).
2. Onglet **Actions** → « Build APK SAAMBA » → **Run workflow** (il se lance aussi à chaque push sur `main`).
3. À la fin (≈ 8 à 12 min), ouvrez l'exécution → **Artifacts → SAAMBA-apk** → téléchargez `SAAMBA.apk` et installez-le.

Le workflow génère lui-même le dossier `android/`, ajoute les permissions (micro, caméra, internet, appels), le nom « SAAMBA », l'icône du logo, puis compile.

## Backend Supabase (déjà configuré)
Le projet Supabase utilisé est celui de `lib/config.dart` (référence `ihsnuvmbnyxqakyovtao`, nommé actuellement « medilink-west-africa » : vous pouvez le renommer « SAAMBA » dans Project Settings > General).
Tables, règles RLS, fonctions, stockage et notifications internes sont en place.

À faire une seule fois dans le tableau de bord Supabase :
- Authentication > Providers > Email : désactiver « Confirm email » (les comptes utilisent `numéro@saamba.app`).
- Premier administrateur : créez son compte dans l'app, puis dans le SQL Editor :
  `update public.profiles set role = 'admin' where id = (select id from auth.users where email = '223XXXXXXXX@saamba.app');`
  (remplacez par le numéro saisi à l'inscription, chiffres seulement).

## Contenu de l'application
- Client : accueil, messagerie (texte, vocal, photo, vidéo, document), commandes, factures PDF, paiements, livraisons, appel transporteur Orange/Malitel, confirmation de réception / colis non reçu, notifications.
- Administration : tableau de bord, conversations, commandes (lignes, frais, réduction), factures, liens de paiement, expéditions, signalements, grossistes (fiches, invitations, demandes avec pièces jointes, saisie manuelle des réponses, comparaison des prix avec anciens prix, archives, notes privées, marges).
- Grossiste invité : demandes reçues, réponses avec prix, disponibilités et pièces jointes, historique de ses propres échanges.

## Non inclus (à configurer plus tard)
- Prestataire de paiement : son webhook doit appeler `public.confirm_payment(ref, montant, id_evenement, payload)` avec la clé service_role.
- Notifications push FCM (google-services.json + Edge Function) : les notifications sont déjà créées dans la table `notifications` et affichées dans l'app.
- Sélection forcée de la SIM : Android ne l'autorise pas pour une app ; l'app ouvre le composeur avec une explication.
