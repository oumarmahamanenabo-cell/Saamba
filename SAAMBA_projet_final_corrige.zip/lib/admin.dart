import 'package:flutter/material.dart';
import 'chat.dart';
import 'common.dart';
import 'orders.dart';
import 'suppliers.dart';

class AdminShell extends StatefulWidget {
  const AdminShell({super.key});
  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  int _i = 0;
  final _ordersKey = GlobalKey<OrdersScreenState>();

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const DashboardScreen(),
      const AdminConversations(),
      Scaffold(
        body: OrdersScreen(key: _ordersKey, admin: true),
        floatingActionButton: FloatingActionButton.extended(
          icon: const Icon(Icons.add),
          label: const Text('Commande'),
          onPressed: () async {
            await Navigator.push(context, MaterialPageRoute(builder: (_) => const OrderForm()));
            _ordersKey.currentState?.reload();
          },
        ),
      ),
      const SuppliersHome(),
      const ProfileScreen(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const SaambaTitle(suffix: 'Admin'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_none),
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => Scaffold(appBar: AppBar(title: const Text('Notifications')), body: const NotificationsScreen()))),
          ),
        ],
      ),
      body: pages[_i],
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Tableau'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), label: 'Messages'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Commandes'),
          NavigationDestination(icon: Icon(Icons.local_shipping_outlined), label: 'Grossistes'),
          NavigationDestination(icon: Icon(Icons.person_outline), label: 'Compte'),
        ],
      ),
    );
  }
}

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late Future<dynamic> _f = sb.rpc('admin_dashboard');
  @override
  Widget build(BuildContext context) => FutureBuilder<dynamic>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final d = Map<String, dynamic>.from(snap.data as Map);
          Widget card(String label, dynamic v, {Color? color}) => Card(
                color: color,
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    Text('$v', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                    Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                  ]),
                ),
              );
          final top = (d['top_products'] as List?) ?? [];
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = sb.rpc('admin_dashboard')),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              GridView.count(
                crossAxisCount: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.15,
                children: [
                  card('Clients', d['clients']),
                  card('Nouveaux messages', d['unread_messages']),
                  card('En attente', d['orders_pending']),
                  card('Payées', d['orders_paid']),
                  card('En préparation', d['orders_preparing']),
                  card('Expédiées', d['orders_shipped']),
                  card('Reçues', d['orders_received']),
                  card('Colis non reçus', d['not_received_open'], color: n(d['not_received_open']) > 0 ? Colors.red.shade100 : null),
                  card('Demandes grossistes', d['supplier_requests_pending']),
                ],
              ),
              Section('Finances', [
                Text('Encaissé : ${money(d['revenue_paid'])}'),
                Text('Ventes : ${money(d['sales'])}'),
                Text('Coûts d\'achat : ${money(d['purchase_cost'])}'),
                Text('Marge brute estimée : ${money(d['gross_margin'])}', style: const TextStyle(fontWeight: FontWeight.bold)),
                const Text('Visible uniquement par l\'administration.', style: TextStyle(fontSize: 11)),
              ]),
              Section('Produits les plus commandés', [
                if (top.isEmpty) const Text('Pas encore de données.'),
                for (final t in top) Text('${t['name']} — ${n(t['qty'])}'),
              ]),
              Section('Grossistes', [Text('Réponses reçues (7 jours) : ${d['supplier_responses_recent']}')]),
            ]),
          );
        },
      );
}

class AdminConversations extends StatefulWidget {
  const AdminConversations({super.key});
  @override
  State<AdminConversations> createState() => _AdminConversationsState();
}

class _AdminConversationsState extends State<AdminConversations> {
  String _q = '';
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async => List<Map<String, dynamic>>.from(await sb
      .from('conversations')
      .select('id, client_id, last_message_at, profiles(full_name, phone)')
      .order('last_message_at', ascending: false, nullsFirst: false));

  @override
  Widget build(BuildContext context) => Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher un client', border: OutlineInputBorder(), isDense: true),
            onChanged: (v) => setState(() => _q = v.toLowerCase()),
          ),
        ),
        Expanded(
          child: FutureBuilder<List<Map<String, dynamic>>>(
            future: _f,
            builder: (context, snap) {
              if (snap.hasError) return errorView(snap.error);
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!.where((c) {
                final p = (c['profiles'] as Map?) ?? {};
                return '${p['full_name']} ${p['phone']}'.toLowerCase().contains(_q);
              }).toList();
              return RefreshIndicator(
                onRefresh: () async => setState(() => _f = _load()),
                child: ListView.separated(
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final c = list[i];
                    final p = (c['profiles'] as Map?) ?? {};
                    final name = (p['full_name'] as String?)?.isNotEmpty == true ? p['full_name'] as String : '${p['phone'] ?? 'Client'}';
                    return ListTile(
                      leading: CircleAvatar(child: Text(name.isEmpty ? '?' : name[0].toUpperCase())),
                      title: Text(name),
                      subtitle: Text(c['last_message_at'] == null ? 'Aucun message' : dt(c['last_message_at'])),
                      onTap: () async {
                        await Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (_) => ChatScreen(
                              conversationId: c['id'] as String,
                              title: name,
                              actions: [
                                IconButton(
                                  tooltip: 'Créer une commande',
                                  icon: const Icon(Icons.add_shopping_cart),
                                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => OrderForm(clientId: c['client_id'] as String, conversationId: c['id'] as String))),
                                ),
                              ],
                            ),
                          ),
                        );
                        setState(() => _f = _load());
                      },
                    );
                  },
                ),
              );
            },
          ),
        ),
      ]);
}

class _Line {
  final name = TextEditingController();
  final price = TextEditingController();
  final qty = TextEditingController(text: '1');
  final unit = TextEditingController(text: 'unité');
}

class OrderForm extends StatefulWidget {
  final String? clientId;
  final String? conversationId;
  const OrderForm({super.key, this.clientId, this.conversationId});
  @override
  State<OrderForm> createState() => _OrderFormState();
}

class _OrderFormState extends State<OrderForm> {
  String? _client;
  List<Map<String, dynamic>> _clients = [];
  final List<_Line> _lines = [_Line()];
  final _ship = TextEditingController(text: '0'), _other = TextEditingController(text: '0'), _disc = TextEditingController(text: '0');
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _client = widget.clientId;
    sb.from('profiles').select('id, full_name, phone').eq('role', 'client').order('full_name').then((r) {
      if (mounted) setState(() => _clients = List<Map<String, dynamic>>.from(r));
    });
  }

  num get _sub => _lines.fold<num>(0, (s, l) => s + n(l.price.text) * n(l.qty.text));
  num get _total => _sub + n(_ship.text) + n(_other.text) - n(_disc.text);

  Future<void> _save() async {
    if (_client == null) return snack(context, 'Choisissez un client.');
    final valid = _lines.where((l) => l.name.text.trim().isNotEmpty && n(l.qty.text) > 0).toList();
    if (valid.isEmpty) return snack(context, 'Ajoutez au moins un produit.');
    setState(() => _busy = true);
    await guarded(context, () async {
      final o = await sb.from('orders').insert({
        'client_id': _client,
        'conversation_id': widget.conversationId,
        'shipping_fee': n(_ship.text),
        'other_fees': n(_other.text),
        'discount': n(_disc.text),
        'created_by': uid,
      }).select('id').single();
      await sb.from('order_items').insert([
        for (var i = 0; i < valid.length; i++)
          {
            'order_id': o['id'],
            'position': i,
            'name': valid[i].name.text.trim(),
            'unit_price': n(valid[i].price.text),
            'quantity': n(valid[i].qty.text),
            'unit': valid[i].unit.text.trim().isEmpty ? 'unité' : valid[i].unit.text.trim(),
          }
      ]);
      if (!mounted) return;
      Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => OrderDetailScreen(orderId: o['id'] as String, admin: true)));
    });
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Nouvelle commande')),
        body: ListView(padding: const EdgeInsets.all(12), children: [
          DropdownButtonFormField<String>(
            value: _client,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'Client', border: OutlineInputBorder()),
            items: [
              for (final c in _clients)
                DropdownMenuItem(value: c['id'] as String, child: Text('${(c['full_name'] as String?)?.isNotEmpty == true ? c['full_name'] : c['phone'] ?? 'Client'}')),
            ],
            onChanged: widget.clientId != null ? null : (v) => setState(() => _client = v),
          ),
          const SizedBox(height: 12),
          for (var i = 0; i < _lines.length; i++)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(8),
                child: Column(children: [
                  Row(children: [
                    Expanded(child: TextField(controller: _lines[i].name, decoration: InputDecoration(labelText: 'Produit ${i + 1}'))),
                    if (_lines.length > 1) IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => setState(() => _lines.removeAt(i))),
                  ]),
                  Row(children: [
                    Expanded(child: TextField(controller: _lines[i].price, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Prix unitaire'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].qty, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Quantité'))),
                    const SizedBox(width: 8),
                    Expanded(child: TextField(controller: _lines[i].unit, decoration: const InputDecoration(labelText: 'Unité'))),
                  ]),
                  Align(alignment: Alignment.centerRight, child: Text('Ligne : ${money(n(_lines[i].price.text) * n(_lines[i].qty.text))}')),
                ]),
              ),
            ),
          TextButton.icon(onPressed: () => setState(() => _lines.add(_Line())), icon: const Icon(Icons.add), label: const Text('Ajouter un produit')),
          Row(children: [
            Expanded(child: TextField(controller: _ship, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Transport'))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: _other, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Autres frais'))),
            const SizedBox(width: 8),
            Expanded(child: TextField(controller: _disc, keyboardType: TextInputType.number, onChanged: (_) => setState(() {}), decoration: const InputDecoration(labelText: 'Réduction'))),
          ]),
          const SizedBox(height: 12),
          Text('Sous-total : ${money(_sub)}'),
          Text('TOTAL À PAYER : ${money(_total)}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          FilledButton(onPressed: _busy ? null : _save, child: Text(_busy ? '…' : 'Créer la commande')),
        ]),
      );
}
