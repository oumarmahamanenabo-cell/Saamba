import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';
import 'orders.dart';

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});
  @override
  Widget build(BuildContext context) =>
      Scaffold(appBar: AppBar(title: const Text('Notifications')), body: const NotificationsScreen());
}

class DeliveriesPage extends StatelessWidget {
  const DeliveriesPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Mes livraisons')),
        body: const OrdersScreen(admin: false, initialFilter: 'shipping'),
      );
}

/// Accueil du client : résumé et accès rapides.
class ClientHome extends StatefulWidget {
  final void Function(int tab) onGo;
  const ClientHome({super.key, required this.onGo});
  @override
  State<ClientHome> createState() => _ClientHomeState();
}

class _ClientHomeState extends State<ClientHome> {
  late Future<List<List<Map<String, dynamic>>>> _f = _load();

  Future<List<List<Map<String, dynamic>>>> _load() async {
    final o = await sb.from('orders').select('id, number, status').order('created_at', ascending: false).limit(200);
    final nt = await sb.from('notifications').select('id, read_at').eq('user_id', uid).limit(200);
    return [List<Map<String, dynamic>>.from(o), List<Map<String, dynamic>>.from(nt)];
  }

  Widget _tile(IconData icon, String label, String value, VoidCallback onTap, {Color? color}) => Card(
        color: color,
        child: InkWell(
          onTap: onTap,
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              Icon(icon, color: brand),
              const SizedBox(height: 4),
              Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
            ]),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) => FutureBuilder<List<List<Map<String, dynamic>>>>(
        future: _f,
        builder: (context, snap) {
          if (snap.hasError) return errorView(snap.error);
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final orders = snap.data![0];
          final notifs = snap.data![1];
          final toPay = orders.where((o) => const ['invoice_sent', 'payment_pending'].contains(o['status'])).length;
          final shipping = orders.where((o) => const ['handed_to_carrier', 'in_transit', 'arrived', 'reception_pending'].contains(o['status'])).length;
          final unread = notifs.where((x) => x['read_at'] == null).length;
          return RefreshIndicator(
            onRefresh: () async => setState(() => _f = _load()),
            child: ListView(padding: const EdgeInsets.all(12), children: [
              const Center(child: SaambaLogo(size: 110)),
              const SizedBox(height: 8),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                childAspectRatio: 1.5,
                children: [
                  _tile(Icons.payments_outlined, 'À payer', '$toPay', () => widget.onGo(2), color: toPay > 0 ? const Color(0xFFFFF3CD) : null),
                  _tile(Icons.local_shipping_outlined, 'Colis en route', '$shipping',
                      () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DeliveriesPage())),
                      color: shipping > 0 ? const Color(0xFFE3F2FD) : null),
                  _tile(Icons.inventory_2_outlined, 'Mes commandes', '${orders.length}', () => widget.onGo(2)),
                  _tile(Icons.notifications_none, 'Alertes non lues', '$unread',
                      () => Navigator.push(context, MaterialPageRoute(builder: (_) => const NotificationsPage()))),
                ],
              ),
              const SizedBox(height: 8),
              FilledButton.icon(
                  onPressed: () => widget.onGo(1), icon: const Icon(Icons.chat), label: const Text('Écrire à SAAMBA (texte, vocal, photo)')),
              const SizedBox(height: 8),
              OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PaymentsScreen())),
                  icon: const Icon(Icons.credit_card),
                  label: const Text('Mes paiements')),
              OutlinedButton.icon(
                  onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DeliveriesPage())),
                  icon: const Icon(Icons.local_shipping),
                  label: const Text('Mes livraisons')),
              OutlinedButton.icon(
                  onPressed: () => widget.onGo(3), icon: const Icon(Icons.receipt_long), label: const Text('Mes factures')),
            ]),
          );
        },
      );
}

class PaymentsScreen extends StatefulWidget {
  const PaymentsScreen({super.key});
  @override
  State<PaymentsScreen> createState() => _PaymentsScreenState();
}

class _PaymentsScreenState extends State<PaymentsScreen> {
  late Future<List<Map<String, dynamic>>> _f = _load();
  Future<List<Map<String, dynamic>>> _load() async => List<Map<String, dynamic>>.from(
      await sb.from('payments').select('*, orders(number)').order('created_at', ascending: false));

  Future<void> _pay(String link) async {
    final u = Uri.tryParse(link);
    if (u == null || u.scheme != 'https') {
      snack(context, 'Lien de paiement invalide. Contactez SAAMBA.');
      return;
    }
    await launchUrl(u, mode: LaunchMode.externalApplication);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('Mes paiements')),
        body: FutureBuilder<List<Map<String, dynamic>>>(
          future: _f,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            if (!snap.hasData) return const Center(child: CircularProgressIndicator());
            if (snap.data!.isEmpty) return const Center(child: Text('Aucun paiement.'));
            return RefreshIndicator(
              onRefresh: () async => setState(() => _f = _load()),
              child: ListView.separated(
                itemCount: snap.data!.length,
                separatorBuilder: (_, __) => const Divider(height: 1),
                itemBuilder: (_, i) {
                  final p = snap.data![i];
                  final st = p['status'] as String;
                  final link = (p['payment_link'] as String?) ?? '';
                  return ListTile(
                    leading: Icon(st == 'paid' ? Icons.check_circle : Icons.hourglass_bottom, color: st == 'paid' ? Colors.green : null),
                    title: Text('${money(p['amount'], p['currency'] as String)} · ${paymentStatusLabels[st] ?? st}'),
                    subtitle: Text('Commande ${(p['orders'] as Map?)?['number'] ?? ''} · ${dt(p['paid_at'] ?? p['created_at'])}'),
                    trailing: st == 'pending' && link.isNotEmpty ? FilledButton(onPressed: () => _pay(link), child: const Text('Payer')) : null,
                  );
                },
              ),
            );
          },
        ),
      );
}
