import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

final SupabaseClient sb = Supabase.instance.client;
String get uid => sb.auth.currentUser!.id;
final ValueNotifier<int> roleRefresh = ValueNotifier<int>(0);
const brand = Color(0xFF0B3C9E);
const brandDark = Color(0xFF0A2A78);
const gold = Color(0xFFF2B100);

ThemeData saambaTheme() {
  final cs = ColorScheme.fromSeed(seedColor: brand).copyWith(primary: brand, secondary: gold, tertiary: gold);
  return ThemeData(
    colorScheme: cs,
    useMaterial3: true,
    appBarTheme: const AppBarTheme(
      backgroundColor: brandDark,
      foregroundColor: Colors.white,
      iconTheme: IconThemeData(color: Colors.white),
      actionsIconTheme: IconThemeData(color: Colors.white),
    ),
    navigationBarTheme: NavigationBarThemeData(indicatorColor: const Color(0x59F2B100)),
    floatingActionButtonTheme: const FloatingActionButtonThemeData(backgroundColor: gold, foregroundColor: brandDark),
    inputDecorationTheme: const InputDecorationTheme(isDense: true),
  );
}

final _nf = NumberFormat('#,##0', 'fr_FR');
num n(dynamic v) => v is num ? v : (num.tryParse('$v') ?? 0);
String money(dynamic v, [String cur = 'XOF']) =>
    '${_nf.format(n(v)).replaceAll(RegExp('[\u202f\u00a0]'), ' ')} ${cur == 'XOF' ? 'FCFA' : cur}';
String dt(dynamic iso) => iso == null ? '' : DateFormat('dd/MM/yyyy HH:mm').format(DateTime.parse('$iso').toLocal());
String dOnly(dynamic iso) => iso == null ? '' : DateFormat('dd/MM/yyyy').format(DateTime.parse('$iso').toLocal());

const orderStatusLabels = <String, String>{
  'request_received': 'Demande reçue',
  'order_created': 'Commande créée',
  'invoice_sent': 'Facture envoyée',
  'payment_pending': 'Paiement en attente',
  'paid': 'Payée',
  'preparing': 'En préparation',
  'ready_to_ship': 'Prête à expédier',
  'handed_to_carrier': 'Remise au transporteur',
  'in_transit': 'En cours de transport',
  'arrived': 'Arrivée au lieu prévu',
  'reception_pending': 'Réception à confirmer',
  'received': 'Reçue par le client',
  'not_received_to_verify': 'NON REÇUE – À VÉRIFIER',
};

const paymentStatusLabels = <String, String>{
  'pending': 'En attente',
  'paid': 'Payé',
  'failed': 'Échoué',
  'cancelled': 'Annulé',
  'refunded': 'Remboursé',
};

String mimeFor(String name) {
  final e = name.toLowerCase().split('.').last;
  const m = {
    'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'png': 'image/png', 'webp': 'image/webp',
    'mp4': 'video/mp4', 'mov': 'video/quicktime', 'm4a': 'audio/mp4', 'pdf': 'application/pdf',
    'doc': 'application/msword', 'docx': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'xls': 'application/vnd.ms-excel', 'xlsx': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  };
  return m[e] ?? 'application/octet-stream';
}

void snack(BuildContext c, String m) =>
    ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));

Future<void> guarded(BuildContext c, Future<void> Function() f) async {
  try {
    await f();
  } on PostgrestException catch (e) {
    if (c.mounted) snack(c, e.message);
  } on AuthException catch (e) {
    if (c.mounted) snack(c, e.message);
  } catch (e) {
    if (c.mounted) snack(c, 'Erreur : $e');
  }
}

Future<String?> askText(BuildContext c, String title, {String hint = '', bool multiline = true}) {
  final ctrl = TextEditingController();
  return showDialog<String>(
    context: c,
    builder: (ctx) => AlertDialog(
      title: Text(title),
      content: TextField(controller: ctrl, autofocus: true, maxLines: multiline ? 3 : 1, decoration: InputDecoration(hintText: hint)),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(ctx, ctrl.text.trim()), child: const Text('OK')),
      ],
    ),
  );
}

Future<void> callCarrier(BuildContext context, String phone, String operator) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (c) => AlertDialog(
      title: Text('Appeler avec $operator'),
      content: Text('Votre téléphone va ouvrir l\'appel. Si vous avez deux cartes SIM, choisissez la SIM $operator dans le sélecteur Android. '
          'Si cette ligne n\'est pas disponible, utilisez la ligne disponible.'),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Annuler')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Appeler')),
      ],
    ),
  );
  if (ok == true) await launchUrl(Uri(scheme: 'tel', path: phone));
}

class CarrierButtons extends StatelessWidget {
  final String phone;
  const CarrierButtons({super.key, required this.phone});
  @override
  Widget build(BuildContext context) => Column(children: [
        SizedBox(width: double.infinity, child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFFFF7900)),
          icon: const Icon(Icons.call), label: const Text('APPELER AVEC ORANGE'),
          onPressed: () => callCarrier(context, phone, 'Orange'))),
        const SizedBox(height: 6),
        SizedBox(width: double.infinity, child: FilledButton.icon(
          style: FilledButton.styleFrom(backgroundColor: const Color(0xFF1565C0)),
          icon: const Icon(Icons.call), label: const Text('APPELER AVEC MALITEL'),
          onPressed: () => callCarrier(context, phone, 'Malitel'))),
      ]);
}

/// Logo officiel SAAMBA (image ronde). `size` = diamètre en pixels logiques.
class SaambaLogo extends StatelessWidget {
  final double size;
  const SaambaLogo({super.key, this.size = 34});
  @override
  Widget build(BuildContext context) => Image.asset('assets/logo.png', width: size, height: size, fit: BoxFit.contain);
}

/// Titre de barre d'application : logo + nom.
class SaambaTitle extends StatelessWidget {
  final String? suffix;
  const SaambaTitle({super.key, this.suffix});
  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        const SaambaLogo(size: 34),
        const SizedBox(width: 8),
        const Text('SAAMBA', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 1.5, color: Colors.white)),
        if (suffix != null) ...[
          const SizedBox(width: 8),
          Text(suffix!, style: const TextStyle(fontSize: 14, color: gold, fontWeight: FontWeight.w600)),
        ],
      ]);
}

/// Écran de démarrage.
class SplashView extends StatelessWidget {
  const SplashView({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        backgroundColor: brandDark,
        body: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            const SaambaLogo(size: 220),
            const SizedBox(height: 24),
            const SizedBox(width: 28, height: 28, child: CircularProgressIndicator(strokeWidth: 3, color: gold)),
          ]),
        ),
      );
}

class Section extends StatelessWidget {
  final String title;
  final List<Widget> children;
  const Section(this.title, this.children, {super.key});
  @override
  Widget build(BuildContext context) => Card(
        margin: const EdgeInsets.symmetric(vertical: 6),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            const SizedBox(height: 8),
            ...children,
          ]),
        ),
      );
}

Widget errorView(Object? e) => Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Erreur : $e', textAlign: TextAlign.center)));
