import 'dart:async';
import 'dart:io';
import 'package:audioplayers/audioplayers.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:record/record.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'package:url_launcher/url_launcher.dart';
import 'common.dart';

class _Pending {
  final String id = '${DateTime.now().microsecondsSinceEpoch}';
  final String kind;
  final String? body;
  final File? file;
  final String? mime;
  final String? name;
  bool failed = false;
  _Pending({required this.kind, this.body, this.file, this.mime, this.name});
  String path(String cid) {
    final nm = name ?? '';
    final dot = nm.lastIndexOf('.');
    return '$cid/$id.${dot > 0 ? nm.substring(dot + 1) : 'bin'}';
  }
}

class ChatScreen extends StatefulWidget {
  final String conversationId;
  final String title;
  final bool embedded;
  final List<Widget> actions;
  const ChatScreen({super.key, required this.conversationId, required this.title, this.embedded = false, this.actions = const []});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final _ctrl = TextEditingController();
  final _rec = AudioRecorder();
  final List<_Pending> _pending = [];
  bool _recording = false;
  String? _lastMarked;
  Timer? _retry;
  late final Stream<List<Map<String, dynamic>>> _stream = sb
      .from('messages')
      .stream(primaryKey: ['id'])
      .eq('conversation_id', widget.conversationId)
      .order('created_at', ascending: true);

  @override
  void initState() {
    super.initState();
    // Relance automatique des messages restés en échec (connexion instable).
    _retry = Timer.periodic(const Duration(seconds: 20), (_) {
      for (final p in List<_Pending>.of(_pending)) {
        if (p.failed) _deliver(p);
      }
    });
  }

  @override
  void dispose() {
    _retry?.cancel();
    _rec.dispose();
    _ctrl.dispose();
    super.dispose();
  }

  void _markRead(List<Map<String, dynamic>> msgs) {
    final others = msgs.where((m) => m['sender_id'] != uid && m['status'] != 'read').toList();
    if (others.isEmpty) return;
    final key = others.last['id'] as String;
    if (key == _lastMarked) return;
    _lastMarked = key;
    sb.rpc('mark_conversation_read', params: {'p_conversation_id': widget.conversationId}).then((_) {}).catchError((_) {});
  }

  void _enqueue(_Pending p) {
    setState(() => _pending.add(p));
    _deliver(p);
  }

  Future<void> _deliver(_Pending p) async {
    setState(() => p.failed = false);
    try {
      final cid = widget.conversationId;
      if (p.file != null) {
        await sb.storage.from('chat-media').upload(p.path(cid), p.file!,
            fileOptions: FileOptions(contentType: p.mime, upsert: true));
      }
      String mid;
      try {
        final m = await sb.from('messages').insert({
          'conversation_id': cid,
          'sender_id': uid,
          'kind': p.kind,
          'body': p.body,
          'client_msg_id': p.id,
        }).select('id').single();
        mid = m['id'] as String;
      } on PostgrestException catch (e) {
        if (e.code != '23505') rethrow;
        final m = await sb.from('messages').select('id').eq('conversation_id', cid).eq('sender_id', uid).eq('client_msg_id', p.id).single();
        mid = m['id'] as String;
      }
      if (p.file != null) {
        final ex = await sb.from('attachments').select('id').eq('message_id', mid).limit(1);
        if (ex.isEmpty) {
          await sb.from('attachments').insert({
            'message_id': mid,
            'storage_path': p.path(cid),
            'mime_type': p.mime,
            'size_bytes': await p.file!.length(),
            'original_name': p.name,
          });
        }
      }
      if (mounted) setState(() => _pending.remove(p));
    } catch (_) {
      if (mounted) setState(() => p.failed = true);
    }
  }

  void _sendText() {
    final t = _ctrl.text.trim();
    if (t.isEmpty) return;
    _ctrl.clear();
    setState(() {});
    _enqueue(_Pending(kind: 'text', body: t));
  }

  Future<void> _toggleRec() async {
    if (_recording) {
      final path = await _rec.stop();
      setState(() => _recording = false);
      if (path != null) _preview(path);
      return;
    }
    if (!await _rec.hasPermission()) {
      if (mounted) snack(context, 'Autorisez le micro pour envoyer un vocal.');
      return;
    }
    final dir = await getTemporaryDirectory();
    final path = '${dir.path}/${DateTime.now().millisecondsSinceEpoch}.m4a';
    await _rec.start(const RecordConfig(encoder: AudioEncoder.aacLc), path: path);
    setState(() => _recording = true);
  }

  Future<void> _preview(String path) async {
    final send = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Écouter avant d\'envoyer'),
        content: _VoicePlayer(source: DeviceFileSource(path)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Supprimer')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Envoyer')),
        ],
      ),
    );
    if (send == true) _enqueue(_Pending(kind: 'voice', file: File(path), mime: 'audio/mp4', name: 'vocal.m4a'));
  }

  Future<void> _attach() async {
    final c = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Wrap(children: [
          ListTile(leading: const Icon(Icons.photo), title: const Text('Photo / capture d\'écran'), onTap: () => Navigator.pop(ctx, 'photo')),
          ListTile(leading: const Icon(Icons.photo_camera), title: const Text('Appareil photo'), onTap: () => Navigator.pop(ctx, 'camera')),
          ListTile(leading: const Icon(Icons.videocam), title: const Text('Vidéo'), onTap: () => Navigator.pop(ctx, 'video')),
          ListTile(leading: const Icon(Icons.description), title: const Text('Document'), onTap: () => Navigator.pop(ctx, 'doc')),
        ]),
      ),
    );
    if (c == null) return;
    final picker = ImagePicker();
    if (c == 'photo' || c == 'camera') {
      final x = await picker.pickImage(
          source: c == 'photo' ? ImageSource.gallery : ImageSource.camera, imageQuality: 70, maxWidth: 1600);
      if (x != null) _enqueue(_Pending(kind: 'image', file: File(x.path), mime: mimeFor(x.name), name: x.name));
    } else if (c == 'video') {
      final x = await picker.pickVideo(source: ImageSource.gallery, maxDuration: const Duration(minutes: 2));
      if (x != null) _enqueue(_Pending(kind: 'video', file: File(x.path), mime: mimeFor(x.name), name: x.name));
    } else {
      final r = await FilePicker.platform.pickFiles();
      final f = r?.files.single;
      if (f?.path != null) _enqueue(_Pending(kind: 'document', file: File(f!.path!), mime: mimeFor(f.name), name: f.name));
    }
  }

  Widget _composer() => SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(4, 4, 4, 6),
          child: Row(children: [
            IconButton(icon: const Icon(Icons.attach_file), onPressed: _attach),
            Expanded(
              child: TextField(
                controller: _ctrl,
                minLines: 1,
                maxLines: 4,
                onChanged: (_) => setState(() {}),
                decoration: InputDecoration(
                  hintText: _recording ? 'Enregistrement… touchez pour terminer' : 'Message',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(24)),
                  isDense: true,
                ),
              ),
            ),
            const SizedBox(width: 4),
            _ctrl.text.trim().isEmpty
                ? IconButton.filled(
                    style: _recording ? IconButton.styleFrom(backgroundColor: Colors.red) : null,
                    icon: Icon(_recording ? Icons.stop : Icons.mic),
                    onPressed: _toggleRec)
                : IconButton.filled(icon: const Icon(Icons.send), onPressed: _sendText),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final body = Column(children: [
      Expanded(
        child: StreamBuilder<List<Map<String, dynamic>>>(
          stream: _stream,
          builder: (context, snap) {
            if (snap.hasError) return errorView(snap.error);
            final msgs = snap.data ?? [];
            if (snap.connectionState == ConnectionState.waiting && msgs.isEmpty) {
              return const Center(child: CircularProgressIndicator());
            }
            _markRead(msgs);
            final items = <Widget>[
              for (final m in msgs) _Bubble(key: ValueKey(m['id']), m: m, mine: m['sender_id'] == uid),
              for (final p in _pending) _PendingBubble(p: p, onRetry: () => _deliver(p)),
            ];
            return ListView(reverse: true, padding: const EdgeInsets.all(8), children: items.reversed.toList());
          },
        ),
      ),
      _composer(),
    ]);
    return widget.embedded ? body : Scaffold(appBar: AppBar(title: Text(widget.title), actions: widget.actions), body: body);
  }
}

class _Bubble extends StatelessWidget {
  final Map<String, dynamic> m;
  final bool mine;
  const _Bubble({super.key, required this.m, required this.mine});
  @override
  Widget build(BuildContext context) {
    final kind = m['kind'] as String;
    final status = m['status'] as String;
    final cs = Theme.of(context).colorScheme;
    final body = (m['body'] as String?) ?? '';
    return Align(
      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 3),
        padding: const EdgeInsets.all(10),
        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
        decoration: BoxDecoration(
            color: mine ? cs.primaryContainer : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(14)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (kind != 'text') _Attachment(messageId: m['id'] as String, kind: kind),
          if (body.isNotEmpty) Text(body),
          Row(mainAxisSize: MainAxisSize.min, children: [
            Text(DateFormat('HH:mm').format(DateTime.parse(m['created_at'] as String).toLocal()), style: const TextStyle(fontSize: 10)),
            if (mine) ...[
              const SizedBox(width: 4),
              Icon(status == 'sent' ? Icons.done : Icons.done_all, size: 14, color: status == 'read' ? Colors.blue : null),
            ],
          ]),
        ]),
      ),
    );
  }
}

class _PendingBubble extends StatelessWidget {
  final _Pending p;
  final VoidCallback onRetry;
  const _PendingBubble({required this.p, required this.onRetry});
  @override
  Widget build(BuildContext context) => Align(
        alignment: Alignment.centerRight,
        child: GestureDetector(
          onTap: p.failed ? onRetry : null,
          child: Container(
            margin: const EdgeInsets.symmetric(vertical: 3),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(color: Colors.grey.shade200, borderRadius: BorderRadius.circular(14)),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Flexible(child: Text(p.kind == 'text' ? (p.body ?? '') : '[${p.kind}] ${p.name ?? ''}')),
              const SizedBox(width: 8),
              p.failed
                  ? const Row(children: [Icon(Icons.error, size: 16, color: Colors.red), Text(' Échec – toucher pour réessayer', style: TextStyle(fontSize: 11))])
                  : const SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2)),
            ]),
          ),
        ),
      );
}

class _Attachment extends StatefulWidget {
  final String messageId;
  final String kind;
  const _Attachment({required this.messageId, required this.kind});
  @override
  State<_Attachment> createState() => _AttachmentState();
}

class _AttachmentState extends State<_Attachment> {
  late Future<Map<String, dynamic>?> _f = _load();
  Future<Map<String, dynamic>?> _load() async {
    for (var i = 0; i < 5; i++) {
      final r = await sb.from('attachments').select().eq('message_id', widget.messageId).limit(1);
      if (r.isNotEmpty) {
        final url = await sb.storage.from('chat-media').createSignedUrl(r.first['storage_path'] as String, 3600);
        return {...r.first, 'url': url};
      }
      await Future.delayed(const Duration(milliseconds: 700));
    }
    return null;
  }

  @override
  Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(
        future: _f,
        builder: (context, snap) {
          if (snap.connectionState != ConnectionState.done) {
            return const Padding(padding: EdgeInsets.all(8), child: SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2)));
          }
          final a = snap.data;
          if (a == null) {
            return TextButton(onPressed: () => setState(() => _f = _load()), child: const Text('Pièce jointe indisponible – réessayer'));
          }
          final url = a['url'] as String;
          switch (widget.kind) {
            case 'image':
              return GestureDetector(
                onTap: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
                child: ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(url, width: 220, fit: BoxFit.cover)),
              );
            case 'voice':
              return _VoicePlayer(source: UrlSource(url));
            default:
              return TextButton.icon(
                icon: Icon(widget.kind == 'video' ? Icons.play_circle : Icons.description),
                label: Text((a['original_name'] as String?) ?? 'Ouvrir le fichier'),
                onPressed: () => launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication),
              );
          }
        },
      );
}

class _VoicePlayer extends StatefulWidget {
  final Source source;
  const _VoicePlayer({required this.source});
  @override
  State<_VoicePlayer> createState() => _VoicePlayerState();
}

class _VoicePlayerState extends State<_VoicePlayer> {
  final _p = AudioPlayer();
  bool _playing = false;
  @override
  void initState() {
    super.initState();
    _p.onPlayerComplete.listen((_) {
      if (mounted) setState(() => _playing = false);
    });
  }

  @override
  void dispose() {
    _p.dispose();
    super.dispose();
  }

  Future<void> _toggle() async {
    if (_playing) {
      await _p.pause();
      setState(() => _playing = false);
    } else {
      await _p.play(widget.source);
      setState(() => _playing = true);
    }
  }

  @override
  Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [
        IconButton(icon: Icon(_playing ? Icons.pause_circle : Icons.play_circle, size: 38), onPressed: _toggle),
        const Text('Message vocal'),
      ]);
}
