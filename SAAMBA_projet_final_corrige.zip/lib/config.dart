const supabaseUrl = 'https://ihsnuvmbnyxqakyovtao.supabase.co';
const supabaseKey = 'sb_publishable_gJ0MGKGbdK8bAliQ7bWiug_CZXxUv8H';
